__version__ = "3.2.0"

__title__ = "abutionpy"
__description__ = "Abution Python Shell"
__uri__ = "http://www.thutmose.cn"
__doc__ = __description__ + " <" + __uri__ + ">"

__author__ = "byz"

__license__ = "Apache 2.0"
__copyright__ = "Crown Copyright (c) 2018-2025"
