#
# Copyright 2016-2019 Crown Copyright
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

"""
This module imports all the abution python classes (not including abution_connector).

Importing this abution.py file will provide you with all the abution components.

These components can then be accessed like:

g.GetKnowledge()
g.MoreThan()

or if you want a specific class from a specific module, for example if there
is an Operation and Predicate class with the same name, you can use the components like:

g.op.X()
g.pred.X()


Specifically the imports are done as follows:

from abutionpy.abution_core import *
from abutionpy.abution_predicates import *
from abutionpy.abution_functions import *
from abutionpy.abution_binaryoperators import *
from abutionpy.abution_operations import *
from abutionpy.abution_config import *
from abutionpy.abution_types import *

import abutionpy.abution_predicates as pred
import abutionpy.abution_functions as func
import abutionpy.abution_binaryoperators as bop
import abutionpy.abution_operations as op
import abutionpy.abution_config as conf
import abutionpy.abution_types as t
"""

from abutionpy.abution_core import *
from abutionpy.abution_predicates import *
from abutionpy.abution_functions import *
from abutionpy.abution_aggregator import *
from abutionpy.abution_operations import *
from abutionpy.abution_config import *
from abutionpy.abution_types import *

import abutionpy.abution_predicates as pred
import abutionpy.abution_functions as func
import abutionpy.abution_aggregator as bop
import abutionpy.abution_operations as op
import abutionpy.abution_config as conf
import abutionpy.abution_types as t

########################################################
# Backwards compatibility
########################################################

# g.And should default to pred.And rather than bop.And
from abutionpy.abution_predicates import And
# g.Or should default to pred.Or rather than bop.Or
from abutionpy.abution_predicates import Or
