#
# Copyright 2016-2024 Crown Copyright
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

"""
This module contains Python copies of Abution java classes
"""

from abutionpy.abution_core import *

class Aggregators:
    """聚合函数常量"""

    @staticmethod
    def VectorSimCrudAgent(graph_name=None, llm_service=None, threshold=0.8, enabled=False):
        """
        向量相似性CRUD代理LLM聚合函数
        Args:
            enabled (bool): 是否启用该功能
            llm_service (dict): 大语言模型服务配置
            threshold (float): 相似性阈值
            graph_name (str): 图数据库名称
        Returns:
            dict: 聚合函数配置
            示例：{
              "class": "cn.thutmose.abution.knowlion.VectorSimCrudAgent",
              "enabled": true,
              "llmService": {
                "text": {
                  "model_name": "qwen-plus",
                  "api_base": "",
                  "api_key": ""
                },
                "embed": {
                  "model_name": "text-embedding-v4",
                  "api_base": "",
                  "api_key": ""
                },
                "visual": {
                  "model_name": "",
                  "api_base": "",
                  "api_key": ""
                }
              },
              "threshold": 0.8,
              "graphName": "TestRareEarthPaper"
            }
        """
        return {
            "class": "cn.thutmose.abution.knowlion.VectorSimCrudAgent",
            "enabled": enabled,
            "llmService": llm_service,
            "threshold": threshold,
            "graphName": graph_name
        }

    @staticmethod
    def Last():
        """最后值聚合函数"""
        return {"class": "cn.thutmose.abution.jfunc.impl.binaryoperator.Last"}

    @staticmethod
    def Max():
        """最大值聚合函数"""
        return {"class": "cn.thutmose.abution.jfunc.impl.binaryoperator.Max"}

    @staticmethod
    def Sum():
        """求和聚合函数"""
        return {"class": "cn.thutmose.abution.jfunc.impl.binaryoperator.Sum"}

    @staticmethod
    def IsTrue():
        """求和聚合函数"""
        return {"class": "cn.thutmose.abution.jfunc.impl.binaryoperator.IsTrue"}

    @staticmethod
    def CollectionConcat():
        """集合连接聚合函数"""
        return {"class": "cn.thutmose.abution.jfunc.impl.binaryoperator.CollectionConcat"}

    @staticmethod
    def DistinctCountHllp():
        """HLLP基数统计聚合函数"""
        return {"class": "cn.thutmose.abution.graph.type.cardinality.aggregate.DistinctCountHllpAggregator"}

    @staticmethod
    def VertexSimVecMapAggregator():
        """顶点相似向量映射聚合函数"""
        return {"class": "cn.thutmose.abution.graph.type.impl.aggregate.VertexSimVecMapAggregator"}

    @staticmethod
    def VertexSimNeighborMapAggregator():
        """顶点相似邻居映射聚合函数"""
        return {"class": "cn.thutmose.abution.graph.type.impl.aggregate.VertexSimNeighborMapAggregator"}

    @staticmethod
    def FloatArrayAdd():
        """浮点数组加法聚合函数"""
        return {"class": "cn.thutmose.abution.jfunc.impl.binaryoperator.FloatArrayAdd"}

    @staticmethod
    def FloatArrayAddSub():
        """浮点数组加减聚合函数"""
        return {"class": "cn.thutmose.abution.graph.type.impl.aggregate.FloatArrayAddSub"}


    @staticmethod
    def CustomMap(binary_operator=None):
        """创建CustomMap聚合函数"""
        if binary_operator:
            return {
                "class": "cn.thutmose.abution.graph.type.impl.aggregate.CustomMapAggregator",
                "binaryOperator": binary_operator
            }
        return {
            "class": "cn.thutmose.abution.graph.type.impl.aggregate.CustomMapAggregator"
        }

    # BM25相关聚合函数
    @staticmethod
    def BM25Index():
        """BM25索引聚合函数"""
        return {"class": "cn.thutmose.abution.graph.type.bm25.aggregate.BM25IndexAggregator"}

    # 向量相关聚合函数
    @staticmethod
    def VectorIndexMerge():
        """向量索引合并聚合函数"""
        return {"class": "cn.thutmose.abution.graph.type.vector.aggregate.VectorIndexAggregator"}

    # 逻辑运算聚合函数
    @staticmethod
    def And():
        """AND聚合函数"""
        return {"class": "cn.thutmose.abution.jfunc.impl.binaryoperator.And"}

    @staticmethod
    def Or():
        """OR聚合函数"""
        return {"class": "cn.thutmose.abution.jfunc.impl.binaryoperator.Or"}

    # 数值运算聚合函数
    @staticmethod
    def Min():
        """最小值聚合函数"""
        return {"class": "cn.thutmose.abution.jfunc.impl.binaryoperator.Min"}

    @staticmethod
    def First():
        """第一个值聚合函数"""
        return {"class": "cn.thutmose.abution.jfunc.impl.binaryoperator.First"}

    @staticmethod
    def Product():
        """乘积聚合函数"""
        return {"class": "cn.thutmose.abution.jfunc.impl.binaryoperator.Product"}

    # 字符串聚合函数
    @staticmethod
    def StrConcat(separator=None):
        """字符串连接聚合函数"""
        if separator:
            return {
                "class": "cn.thutmose.abution.jfunc.impl.binaryoperator.StrConcat",
                "separator": separator
            }
        return {"class": "cn.thutmose.abution.jfunc.impl.binaryoperator.StrConcat"}

    @staticmethod
    def StrConcatDeduplicate(separator=None):
        """去重字符串连接聚合函数"""
        if separator:
            return {
                "class": "cn.thutmose.abution.jfunc.impl.binaryoperator.StrConcatDeduplicate",
                "separator": separator
            }
        return {"class": "cn.thutmose.abution.jfunc.impl.binaryoperator.StrConcatDeduplicate"}

    # 邻居相似度聚合函数
    @staticmethod
    def VertexNeighborsSimListAddSub():
        """顶点邻居相似度列表加减聚合函数"""
        return {"class": "cn.thutmose.abution.graph.type.impl.aggregate.VertexNeighborsSimListAddSub"}

    @staticmethod
    def FloatArrayConcat():
        """浮点数组连接聚合函数"""
        return {"class": "cn.thutmose.abution.jfunc.impl.binaryoperator.FloatArrayConcat"}

    # 集合操作聚合函数
    @staticmethod
    def CollectionIntersect():
        """集合交集聚合函数"""
        return {"class": "cn.thutmose.abution.jfunc.impl.binaryoperator.CollectionIntersect"}

    # 基数统计聚合函数
    @staticmethod
    def DistinctCountHll():
        """HLL基数统计聚合函数"""
        return {"class": "cn.thutmose.abution.graph.type.cardinality.aggregate.DistinctCountHllAggregator"}

    @staticmethod
    def DistinctCountPlus():
        """Plus基数统计聚合函数"""
        return {"class": "cn.thutmose.abution.graph.type.cardinality.aggregate.DistinctCountPlusAggregator"}

    @staticmethod
    def DistinctCountPlusRetain():
        """Plus基数统计保留聚合函数"""
        return {"class": "cn.thutmose.abution.graph.type.cardinality.aggregate.DistinctCountPlusRetainAggregator"}

    @staticmethod
    def DistinctCountThetas():
        """Thetas基数统计聚合函数"""
        return {"class": "cn.thutmose.abution.graph.type.cardinality.aggregate.DistinctCountThetasAggregator"}

    # 频率统计聚合函数
    @staticmethod
    def FreqBooleans():
        """布尔值频率统计聚合函数"""
        return {"class": "cn.thutmose.abution.graph.type.frequency.aggregate.FreqBooleansAggregator"}

    @staticmethod
    def FreqDoubles():
        """双精度浮点数频率统计聚合函数"""
        return {"class": "cn.thutmose.abution.graph.type.frequency.aggregate.FreqDoublesAggregator"}

    @staticmethod
    def FreqLongs():
        """长整型频率统计聚合函数"""
        return {"class": "cn.thutmose.abution.graph.type.frequency.aggregate.FreqLongsAggregator"}

    @staticmethod
    def FreqMap():
        """映射频率统计聚合函数"""
        return {"class": "cn.thutmose.abution.graph.type.frequency.aggregate.FreqMapAggregator"}

    @staticmethod
    def FreqStrings():
        """字符串频率统计聚合函数"""
        return {"class": "cn.thutmose.abution.graph.type.frequency.aggregate.FreqStringsAggregator"}

    # HashMap聚合函数
    @staticmethod
    def HashMapAggregator(topN=None):
        """HashMap聚合函数"""
        if topN:
            return {
                "class": "cn.thutmose.abution.graph.type.impl.aggregate.HashMapAggregator",
                "topN": topN
            }
        return {"class": "cn.thutmose.abution.graph.type.impl.aggregate.HashMapAggregator"}

    # 分位数聚合函数
    @staticmethod
    def QuantileDoubles():
        """双精度浮点数分位数聚合函数"""
        return {"class": "cn.thutmose.abution.graph.type.quantile.aggregate.QuantileDoublesAggregator"}

    @staticmethod
    def QuantileFloats():
        """浮点数分位数聚合函数"""
        return {"class": "cn.thutmose.abution.graph.type.quantile.aggregate.QuantileFloatsAggregator"}

    @staticmethod
    def QuantileStrings():
        """字符串分位数聚合函数"""
        return {"class": "cn.thutmose.abution.graph.type.quantile.aggregate.QuantileStringsAggregator"}

    # 采样聚合函数
    @staticmethod
    def ReservoirItemsSketch():
        """水库采样聚合函数"""
        return {"class": "cn.thutmose.abution.graph.type.sampling.aggregate.ReservoirItemsSketchAggregator"}

    @staticmethod
    def SamplingLongs():
        """长整型采样聚合函数"""
        return {"class": "cn.thutmose.abution.graph.type.sampling.aggregate.SamplingLongsAggregator"}

    @staticmethod
    def SamplingObjects():
        """对象采样聚合函数"""
        return {"class": "cn.thutmose.abution.graph.type.sampling.aggregate.SamplingObjectsAggregator"}

    @staticmethod
    def SamplingStrings():
        """字符串采样聚合函数"""
        return {"class": "cn.thutmose.abution.graph.type.sampling.aggregate.SamplingStringsAggregator"}

    # 时间序列聚合函数
    @staticmethod
    def TimeSeries():
        """时间序列聚合函数"""
        return {"class": "cn.thutmose.abution.graph.type.times.aggregate.TimeSeriesAggregator"}

    @staticmethod
    def TimestampSet():
        """时间戳集合聚合函数"""
        return {"class": "cn.thutmose.abution.graph.type.times.aggregate.TimestampSetAggregator"}

    @staticmethod
    def TimestampSetBounded():
        """有界时间戳集合聚合函数"""
        return {"class": "cn.thutmose.abution.graph.type.times.aggregate.TimestampSetBoundedAggregator"}

    # TopN聚合函数
    @staticmethod
    def TopNCounterByte():
        """字节型TopN计数聚合函数"""
        return {"class": "cn.thutmose.abution.graph.type.topn.aggregate.TopNCounterByteAggregator"}

    # 角色聚合函数
    @staticmethod
    def RoleAggregator():
        """角色聚合函数"""
        return {"class": "cn.thutmose.abution.jfunc.business.binaryoperator.RoleAggregator"}


class BinaryOperatorContext(ToJson, ToCodeString):
    CLASS = "abution.AggregatorContext"

    def __init__(self, selection=None, binary_operator=None):
        if isinstance(selection, list):
            self.selection = selection
        else:
            self.selection = [selection]
        self.binary_operator = binary_operator

    def to_json(self):
        function_json = {}
        if self.selection is not None:
            function_json["selection"] = self.selection
        if self.binary_operator is not None:
            function_json["binaryOperator"] = self.binary_operator.to_json()

        return function_json


# Import generated binary operator implementations from fishbowl
from abutionpy.generated_api.binaryoperators import *


def binary_operator_context_converter(obj):
    if "class" in obj:
        binary_operator = dict(obj)
    else:
        binary_operator = obj["binary_operator"]
        if isinstance(binary_operator, dict):
            binary_operator = dict(binary_operator)

    if not isinstance(binary_operator, BinaryOperator):
        binary_operator = JsonConverter.from_json(binary_operator)
        if not isinstance(binary_operator, BinaryOperator):
            class_name = binary_operator.get("class")
            binary_operator.pop("class", None)
            binary_operator = BinaryOperator(
                class_name=class_name,
                fields=binary_operator
            )

    return BinaryOperatorContext(
        selection=obj.get("selection"),
        binary_operator=binary_operator
    )


def binary_operator_converter(obj):
    if isinstance(obj, dict):
        binary_operator = dict(obj)
    else:
        binary_operator = obj

    if not isinstance(binary_operator, BinaryOperator):
        binary_operator = JsonConverter.from_json(binary_operator)
        if not isinstance(binary_operator, BinaryOperator):
            class_name = binary_operator.get("class")
            binary_operator.pop("class", None)
            binary_operator = BinaryOperator(
                class_name=class_name,
                fields=binary_operator
            )

    return binary_operator


def load_binaryoperator_json_map():
    for name, class_obj in inspect.getmembers(
            sys.modules[__name__], inspect.isclass):
        if hasattr(class_obj, "CLASS"):
            JsonConverter.GENERIC_JSON_CONVERTERS[class_obj.CLASS] = \
                lambda obj, class_obj=class_obj: class_obj(**obj)
            JsonConverter.CLASS_MAP[class_obj.CLASS] = class_obj
    JsonConverter.CUSTOM_JSON_CONVERTERS[
        BinaryOperatorContext.CLASS] = binary_operator_context_converter
    JsonConverter.CUSTOM_JSON_CONVERTERS[
        BinaryOperator.CLASS] = binary_operator_converter


load_binaryoperator_json_map()
