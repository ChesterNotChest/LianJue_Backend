#
# Copyright 2016-2024 Crown Copyright
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

"""
This module queries a Abution REST API
"""

import json
from typing import List

from abutionpy import abution as g
from abutionpy.abution_traversal import Graph
from abutionpy.client import UrllibClient, RequestsClient, PkiClient
from abutionpy.abution_core import ToJson, Knowledge
from abutionpy.abution_config import IsOperationSupported
from abutionpy.abution_operations import GqlChain
from gremlin_python.structure.io.graphsonV3d0 import GraphSONReader

CLIENT_CLASS_NAMES = {
    "urllib": UrllibClient,
    "requests": RequestsClient,
    "pki": PkiClient
}


class AbutionConnector:
    """
    This class handles the connection to a Abution server and handles operations.
    This class is initialised with a host to connect to.
    """

    def __init__(self, host, verbose=False, headers={}, client_class=UrllibClient, **kwargs):
        """
        This initialiser sets up a connection to the specified Abution server.

        The host (and port) of the Abution server, should be in the form: 'hostname:1234/service-name/version'.
        Note that spring-rest endpoints do not require the version.
        """

        if isinstance(client_class, str):
            if client_class not in CLIENT_CLASS_NAMES:
                options = "", "".join(CLIENT_CLASS_NAMES.keys())
                raise ValueError(
                    f"Unknown option for client_class: '{client_class}'. "
                    f"Available options are: '{options}'"
                )
            client_class = CLIENT_CLASS_NAMES[client_class]

        self.host = host
        self.client = client_class(host, verbose, headers, **kwargs)
        self.graphson_reader = GraphSONReader()

    def execute(self, operation, headers=None):
        """
        This method queries Abution with the single provided operation.
        """
        return self.execute_operation(operation, headers)

    def execute_operation(self, operation, headers=None):
        """
        This method queries Abution with the single provided operation.
        """
        return self.execute_operations([operation], headers)

    def execute_operations(self, operations, headers=None):
        """
        This method queries Abution with the provided array of operations.
        """
        return self.execute_operation_chain(GqlChain(operations), headers)

    def execute_operation_chain(self, operation_chain, headers=None):
        """
        This method queries Abution with the provided operation chain.
        """
        target = "/graph/operations/execute"

        op_chain_json_obj = ToJson.recursive_to_json(operation_chain)

        # Query Abution
        if self._verbose:
            print("\nQuery operations:\n" +
                  json.dumps(op_chain_json_obj, indent=4) + "\n")

        # Convert the query dictionary into JSON and post the query to Abution
        json_body = bytes(json.dumps(op_chain_json_obj), "ascii")

        # print(op_chain_json_obj)

        return self.client.perform_request(
            "POST",
            target,
            headers,
            json_body
        )

    def execute_gremlin(self, query: str, to_objects=True):
        """
        Execute a Gremlin Groovy query using the Abution endpoint.

        Args:
            query: The Gremlin query.
            to_objects: Should the result be converted to Python objects or left as raw GraphSON.

        Returns:
            The result of the query.
        """
        target = "/gremlin/execute"
        request_headers = {'accept': 'application/x-ndjson', 'Content-Type': 'text/plain'}

        result = self.client.perform_request(
            method="POST",
            target=target,
            body=str.encode(query),
            headers=request_headers
        )

        # Convert to python using gremlin-python's graphSON reader
        if to_objects:
            return self.graphson_reader.to_object(result)

        # Return just raw result
        return result

    def execute_cypher(self, query: str, to_objects=True):
        """
        Execute an Open Cypher query using the Abution endpoint.

        Args:
            query: The Open Cypher query.
            to_objects: Should the result be converted to Python objects or left as raw GraphSON.

        Returns:
            The result of the query.
        """
        target = "/gremlin/cypher/execute"
        request_headers = {'accept': 'application/x-ndjson', 'Content-Type': 'text/plain'}

        result = self.client.perform_request(
            method="POST",
            target=target,
            body=str.encode(query),
            headers=request_headers
        )

        # Convert to python using gremlin-python's graphSON reader
        if to_objects:
            return self.graphson_reader.to_object(result)

        # Return just raw result
        return result

    def execute_get(self, operation, headers=None, json_result=False):
        """
        This method queries Abution with a GET request to a specified endpoint.

        The operation parameter expects an input of the form: g.<OperationClass>, where <OperationClass> must inherit
        from the class 'abutionpy.abution_config.GetGraph'.

        The following are accepted inputs:
            g.GetFilterFunctions()
            g.GetTransformFunctions()
            g.GetClassFilterFunctions()
            g.GetKnowledgeGenerators()
            g.GetObjectGenerators()
            g.GetOperations()
            g.GetSerialisedFields()
            g.GetStoreTraits()

        Example:
            gc.execute_get(operation = g.GetOperations())

        """
        target = operation.get_url()

        return self.get(target, headers, json_result)

    def is_operation_supported(self, operation, headers=None, json_result=False):
        """
        This method queries the Abution API to provide details about operations
        Returns a JSON array containing details about the operation.

        The operation parameter expects an input of the form:
            g.IsOperationSupported(operation='cn.thutmose.abution.graph.operation.impl.get.GetKnowledge')

        or you can use:
            g.IsOperationSupported(operation=g.GetKnowledge().CLASS)

        Examples:
            gc.is_operation_supported(g.IsOperationSupported('cn.thutmose.abution.graph.operation.impl.get.GetKnowledge'))
            gc.is_operation_supported(g.GetKnowledge())
        """

        if isinstance(operation, IsOperationSupported):
            target = "/graph/operations/" + operation.get_operation()
        else:
            target = "/graph/operations/" + operation.CLASS

        return self.get(target, headers, json_result)

    def get(self, url, headers=None, json_result=False):
        return self.client.perform_request(
            "GET",
            url,
            headers,
            json_result=json_result
        )

    @property
    def _host(self):
        return self.client.base_url

    @property
    def _verbose(self):
        return self.client.verbose

    @property
    def _headers(self):
        return self.client.headers


    # 基本操作
    # -----------------------------------------------------------------------------------------------------------------
    def add_graph(self, graph_id, schema):
        headers = {
            "Content-Type": "application/json",
            "abution.graphId": graph_id
        }
        add_graph = g.AddGraph(
            schema=schema.schema_dict
        )
        self.execute_operation(add_graph, headers)

    def list_auths(self):
        """
        列出所有的权限标签.
        Args:

        Returns:
            结果列表
        """
        target = "/graph/operations/listUserAuths"
        request_headers = {'accept': 'application/json', 'Content-Type': 'text/plain'}
        result = self.client.perform_request(
            method="POST",
            target=target,
            body=None,
            headers=request_headers
        )
        return result

    def add_auths(self, label):
        """
        增加权限标签.
        Args:

        Returns:
            所有权限标签列表
        """
        target = "/graph/operations/addUserAuths"
        request_headers = {'accept': 'application/json', 'Content-Type': 'text/plain'}
        result = self.client.perform_request(
            method="POST",
            target=target,
            body=str.encode(label),
            headers=request_headers
        )
        return result

    def list_namespace(self):
        """
        列出所有命名空间.
        Args:

        Returns:
            命名空间列表
        """
        target = "/graph/operations/listNamespace"
        request_headers = {'accept': 'application/json', 'Content-Type': 'text/plain'}
        result = self.client.perform_request(
            method="POST",
            target=target,
            body=None,
            headers=request_headers
        )
        return result

    def create_namespace(self, namespace):
        """
        创建新的命名空间.
        Args:
            namespace: 命名空间名称

        Returns:
            更新后的命名空间列表
        """
        target = "/graph/operations/createNamespace"
        request_headers = {'accept': 'application/json', 'Content-Type': 'text/plain'}
        result = self.client.perform_request(
            method="POST",
            target=target,
            body=str.encode(namespace),
            headers=request_headers
        )
        return result

    def list_graph(self):
        """
        列出所有图.
        Args:

        Returns:
            图列表
        """
        target = "/graph/operations/listGraph"
        request_headers = {'accept': 'application/json', 'Content-Type': 'text/plain'}
        result = self.client.perform_request(
            method="POST",
            target=target,
            body=None,
            headers=request_headers
        )
        return result

    def clone_graph(self, old_name, new_name):
        """
        克隆图.
        Args:
            old_name: 源图名称
            new_name: 目标图名称

        Returns:
            操作结果
        """
        target = "/graph/operations/cloneGraph"
        request_headers = {'accept': 'application/json', 'Content-Type': 'application/json'}
        body = json.dumps({"oldName": old_name, "newName": new_name})
        result = self.client.perform_request(
            method="POST",
            target=target,
            body=str.encode(body),
            headers=request_headers
        )
        return result

    def delete_graph(self, graph_id):
        """
        删除图.
        Args:
            graph_id: 图ID

        Returns:
            操作结果
        """
        target = "/graph/operations/deleteGraph"
        request_headers = {'accept': 'application/json', 'Content-Type': 'text/plain'}
        result = self.client.perform_request(
            method="POST",
            target=target,
            body=str.encode(graph_id),
            headers=request_headers
        )
        return result

    def get_schema(self, graph_id):
        """
        获取图的模式.
        Args:
            graph_id: 图ID

        Returns:
            图模式信息
        """
        target = "/graph/operations/getSchema"
        request_headers = {'accept': 'application/json', 'Content-Type': 'text/plain'}
        result = self.client.perform_request(
            method="POST",
            target=target,
            body=str.encode(graph_id),
            headers=request_headers
        )
        return result


    def Graph(self, graph_id:str):
        return Graph(self, graph_id)

    def create_rag_graph(self, graph_id):
        """ "graphId": tenant_id.split("-")[0] + "." + dataset.id.split("-")[0] """
        # 创建图表
        payload = json.dumps({
            "graphId": graph_id
        })
        target = "/v2/aui/ragBase/createRagGraph"
        request_headers = {'accept': 'application/json', 'Content-Type': 'application/json'}
        result = self.client.perform_request(
            method="POST",
            target=target,
            body=str.encode(payload),
            headers=request_headers
        )
        return result
