#
# Copyright 2016-2024 Crown Copyright
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

"""
This module contains Python copies of Abution core java classes
"""

import json
import re

import inspect
import sys
from typing import Any


class ToJson:
    """
    Enables implementations to be converted to json via a to_json method
    """

    def __repr__(self):
        return json.dumps(ToJson.recursive_to_json(self))

    def to_json(self):
        """
        Converts an object to a simple json dictionary
        """
        raise NotImplementedError("Use an implementation")

    def to_json_str(self):
        return json.dumps(ToJson.recursive_to_json(self))

    def to_json_pretty_str(self):
        return json.dumps(ToJson.recursive_to_json(self), indent=4, separators=(",", ": "))

    def pretty_print(self):
        print(self.to_json_pretty_str())

    def __str__(self):
        return str(ToJson.recursive_to_json(self))

    def __eq__(self, other):
        other_json = ToJson.recursive_to_json(other)
        self_json = ToJson.recursive_to_json(self.to_json())
        return self_json == other_json

    @staticmethod
    def recursive_to_json(obj):
        if obj is None:
            return None

        if isinstance(obj, list):
            serialized_list = []

            for thing in obj:
                serialized_list.append(ToJson.recursive_to_json(thing))

            return serialized_list

        if isinstance(obj, ToJson):
            return ToJson.recursive_to_json(obj.to_json())

        if isinstance(obj, dict):
            serialized_map = {}

            for key in obj.keys():
                serialized_map[ToJson.recursive_to_json(key)] = ToJson.recursive_to_json(obj[key])

            return serialized_map

        return obj


class ToCodeString:
    """
   Enables implementations to return a string of the code used to construct the
   python object.
   """

    @staticmethod
    def obj_to_code_string(obj, indent=""):
        if obj is None:
            return ""

        new_line = " \n" + indent
        new_line_indent = new_line + "  "

        if isinstance(obj, ToCodeString):
            obj_str = obj.to_code_string(indent=indent + "  ")
        elif isinstance(obj, list):
            obj_str = "["
            for item in obj:
                obj_item_str = ToCodeString.obj_to_code_string(item,
                                                               indent=indent + "  ")
                if obj_str == "[":
                    obj_str = obj_str + new_line_indent + "  " + obj_item_str
                else:
                    obj_str = obj_str + "," + new_line_indent + "  " + obj_item_str
            obj_str = obj_str + new_line_indent + "]"
        elif isinstance(obj, str):
            obj_str = '"' + obj + '"'
        else:
            obj_str = str(obj)
        return obj_str

    def to_code_string(self, header=False, indent=""):
        new_line = " \n" + indent
        new_line_indent = new_line + "  "
        fields = dict(self.__dict__)

        field_code_str = ""

        for name, val in fields.items():
            if (not name.startswith("_")) and val is not None:
                val_str = ToCodeString.obj_to_code_string(val, indent)
                if field_code_str == "":
                    field_code_str = name + "=" + val_str
                else:
                    field_code_str = field_code_str + "," + new_line_indent + name + "=" + val_str

        if header:
            header_str = "from abutionpy import abution as g\n" + new_line
        else:
            header_str = ""

        if field_code_str == "":
            return header_str + "g." + type(self).__name__ + "()"

        return header_str + "g." + type(self).__name__ + "(" + new_line_indent \
            + field_code_str \
            + new_line + ")"


class DirectedType:
    EITHER = "EITHER"
    DIRECTED = "DIRECTED"
    UNDIRECTED = "UNDIRECTED"


class InOutType:
    EITHER = "EITHER"
    IN = "INCOMING"
    OUT = "OUTGOING"


class SeedMatchingType:
    RELATED = "RELATED"
    EQUAL = "EQUAL"


class EdgeVertices:
    NONE = "NONE"
    SOURCE = "SOURCE"
    TARGET = "TARGET"
    BOTH = "BOTH"


class UseMatchedVertex:
    IGNORE = "IGNORE"
    EQUAL = "EQUAL"
    OPPOSITE = "OPPOSITE"


class MatchKey:
    LEFT = "LEFT"
    RIGHT = "RIGHT"


class JoinType:
    FULL = "FULL"
    OUTER = "OUTER"
    INNER = "INNER"


class KnowledgeKey(ToJson, ToCodeString):
    def __repr__(self):
        return json.dumps(self.to_json())

    def to_json(self):
        raise NotImplementedError("Use either EntityKey or EdgeKey")

    def to_json_wrapped(self):
        raise NotImplementedError("Use either EntityKey or EdgeKey")


class EntityKey(KnowledgeKey):
    CLASS = "cn.thutmose.abution.graph.data.knowhow.id.EntityKey"

    def __init__(self, vertex):
        super().__init__()
        self.vertex = vertex

    def to_json(self):
        return {"class": self.CLASS,
                "vertex": self.vertex}

    def to_json_wrapped(self):
        return {
            self.CLASS: {
                "vertex": self.vertex,
                "class": self.CLASS
            }
        }


class EdgeKey(KnowledgeKey):
    CLASS = "cn.thutmose.abution.graph.data.knowhow.id.EdgeKey"

    def __init__(self, source, target, directed_type, matched_vertex=None):
        super().__init__()
        self.source = source
        self.target = target
        if isinstance(directed_type, str):
            self.directed_type = directed_type
        elif directed_type:
            self.directed_type = DirectedType.DIRECTED
        else:
            self.directed_type = DirectedType.UNDIRECTED
        self.matched_vertex = matched_vertex

    def to_json(self):
        seed = {
            "class": self.CLASS,
            "source": self.source,
            "target": self.target,
            "directedType": self.directed_type
        }

        if self.matched_vertex is not None:
            seed["matchedVertex"] = self.matched_vertex

        return seed

    def to_json_wrapped(self):
        seed = {
            "source": self.source,
            "target": self.target,
            "directedType": self.directed_type,
            "class": self.CLASS
        }

        if self.matched_vertex is not None:
            seed["matchedVertex"] = self.matched_vertex

        return {
            self.CLASS: seed
        }


class Comparator(ToJson, ToCodeString):
    def __init__(self, class_name, fields=None):
        super().__init__()

        self.class_name = class_name
        self.fields = fields

    def to_json(self):
        tmp_json = {
            "class": self.class_name
        }

        if self.fields is not None:
            for key in self.fields:
                tmp_json[key] = self.fields[key]

        return tmp_json


class KnowledgePropertyComparator(Comparator):
    CLASS = "cn.thutmose.abution.graph.data.knowhow.comparison.KnowledgePropertyComparator"

    def __init__(self, labels, property, reversed=False):
        super().__init__(class_name=None)
        self.labels = labels
        self.property = property
        self.reversed = reversed

    def to_json(self):
        tmp_json = super().to_json()
        tmp_json["class"] = self.CLASS
        tmp_json["labels"] = self.labels
        tmp_json["property"] = self.property
        tmp_json["reversed"] = self.reversed
        return tmp_json


class SeedPair(ToJson, ToCodeString):
    CLASS = "cn.thutmose.abution.graph.commonutil.pair.Pair"

    def __init__(self, first, second):
        super().__init__()

        if isinstance(first, KnowledgeKey):
            self.first = first
        elif isinstance(first, dict) and "class" in first:
            self.first = JsonConverter.from_json(first)
        elif isinstance(first, dict) and EntityKey.CLASS in first:
            self.first = first[EntityKey.CLASS]
            if isinstance(self.first, dict):
                self.first = JsonConverter.from_json(self.first, EntityKey)
        elif isinstance(first, dict) and EdgeKey.CLASS in first:
            self.first = first[EdgeKey.CLASS]
            if isinstance(self.first, dict):
                self.first = JsonConverter.from_json(self.first, EdgeKey)
        else:
            self.first = EntityKey(first)

        if isinstance(second, KnowledgeKey):
            self.second = second
        elif isinstance(second, dict) and "class" in second:
            self.second = JsonConverter.from_json(second)
        elif isinstance(second, dict) and EntityKey.CLASS in second:
            self.second = second[EntityKey.CLASS]
            if isinstance(self.second, dict):
                self.second = JsonConverter.from_json(self.second, EntityKey)
        elif isinstance(second, dict) and EdgeKey.CLASS in second:
            self.second = second[EdgeKey.CLASS]
            if isinstance(self.second, dict):
                self.second = JsonConverter.from_json(self.second, EdgeKey)
        else:
            self.second = EntityKey(second)

    def to_json(self):
        return {
            "class": self.CLASS,
            "first": self.first.to_json_wrapped(),
            "second": self.second.to_json_wrapped()
        }

class KnowledgeBuilder:
    """知识构建器基类，提供公共属性设置能力"""
    def __init__(self, label):
        self.label = label
        self.properties = {}

    def property(self, key, value):
        """设置属性键值对，支持链式调用"""
        self.properties[key] = value
        return self

    def build(self):
        """抽象方法：子类需实现具体对象构建逻辑"""
        raise NotImplementedError("子类必须实现 build() 方法")


class EntityBuilder(KnowledgeBuilder):
    """顶点(Entity)专用构建器，封装顶点特有属性"""
    def __init__(self, label):
        super().__init__(label)
        self.vertex_id = None  # 顶点唯一标识

    def vertex(self, vertex_id):
        """设置顶点ID（顶点特有属性）"""
        if not isinstance(vertex_id, (str, int)):
            raise TypeError("顶点ID必须是字符串或整数")
        self.vertex_id = vertex_id
        return self

    def build(self):
        """构建并返回Entity对象，验证必要参数"""
        if self.vertex_id is None:
            raise ValueError("构建顶点必须设置vertex()")
        return Entity(
            label=self.label,
            vertex=self.vertex_id,
            properties=self.properties or None  # 空字典转为None，兼容原始API
        )


class EdgeBuilder(KnowledgeBuilder):
    """边(Edge)专用构建器，封装边特有属性"""
    def __init__(self, label):
        super().__init__(label)
        self.source = None    # 源顶点ID
        self.target = None    # 目标顶点ID
        self.directed = None  # 是否有向
        self.matched_vertex = None  # 匹配顶点（可选）

    def edge(self, source, target, directed=True):
        """设置边的源、目标顶点和方向（边特有属性）"""
        if not isinstance(source, (str, int)) or not isinstance(target, (str, int)):
            raise TypeError("源顶点和目标顶点ID必须是字符串或整数")
        if not isinstance(directed, bool):
            raise TypeError(" directed 必须是布尔值（True/False）")
        self.source = source
        self.target = target
        self.directed = directed
        return self

    def matched_vertex(self, vertex_id):
        """设置匹配顶点（可选属性）"""
        if not isinstance(vertex_id, (str, int)):
            raise TypeError("匹配顶点ID必须是字符串或整数")
        self.matched_vertex = vertex_id
        return self

    def build(self):
        """构建并返回Edge对象，验证必要参数"""
        if self.source is None or self.target is None or self.directed is None:
            raise ValueError("构建边必须设置edge(source, target, directed)")
        return Edge(
            label=self.label,
            source=self.source,
            target=self.target,
            directed=self.directed,
            properties=self.properties or None,  # 空字典转为None，兼容原始API
            matched_vertex=self.matched_vertex
        )


class Knowledge(ToJson, ToCodeString):
    """知识入口类，提供顶点和边的构建器创建方法"""
    def __init__(self, _class_name, label, properties=None):
        super().__init__()
        if not isinstance(_class_name, str):
            raise TypeError("ClassName must be a class name string")
        if not isinstance(label, str):
            raise TypeError("Label must be a string")
        if not isinstance(properties, dict) and properties is not None:
            raise TypeError("properties must be a dictionary or None")
        self._class_name = _class_name
        self.label = label
        self.properties = properties

    @classmethod
    def labelV(cls, label):
        """创建顶点构建器，参数为顶点标签（如 "V|Paper"）"""
        if not isinstance(label, str) or not label.strip():
            raise TypeError("顶点标签必须是非空字符串")
        return EntityBuilder(
            label=label.strip()
        )

    @classmethod
    def labelE(cls, label):
        """创建边构建器，参数为边标签（如 "E|Chapter2Para"）"""
        if not isinstance(label, str) or not label.strip():
            raise TypeError("边标签必须是是非空字符串")
        return EdgeBuilder(
            label=label.strip()
        )


    def to_json(self):
        element = {"class": self._class_name, "label": self.label}
        if self.properties is not None:
            element["properties"] = self.properties
        return element


class Entity(Knowledge):
    CLASS = "cn.thutmose.abution.graph.data.knowhow.Entity"

    def __init__(self, label, vertex, properties=None):
        super().__init__(self.CLASS, label, properties)
        self.vertex = vertex

    def to_json(self):
        entity = super().to_json()
        entity["vertex"] = self.vertex
        return entity


class Edge(Knowledge):
    CLASS = "cn.thutmose.abution.graph.data.knowhow.Edge"

    def __init__(self, label, source, target, directed, properties=None, matched_vertex=None):
        super().__init__(self.CLASS, label,
                         properties)
        # Validate the arguments
        if not isinstance(directed, bool):
            raise TypeError("Directed must be a boolean")
        self.source = source
        self.target = target
        self.directed = directed
        self.matched_vertex = matched_vertex

    def to_json(self):
        edge = super().to_json()
        edge["source"] = self.source
        edge["target"] = self.target
        edge["directed"] = self.directed
        if self.matched_vertex is not None:
            edge["matchedVertex"] = self.matched_vertex

        return edge


class JsonConverter:
    GENERIC_JSON_CONVERTERS = {}
    CUSTOM_JSON_CONVERTERS = {}
    CLASS_MAP = {}

    @staticmethod
    def to_snake_case(name):
        s1 = re.sub("(.)([A-Z][a-z]+)", r"\1_\2", name)
        return re.sub("([a-z0-9])([A-Z])", r"\1_\2", s1).lower()

    @staticmethod
    def object_decoder(obj, class_name=None):
        if not isinstance(obj, dict):
            raise TypeError(
                "from_json called on object of type " + str(type(obj)) +
                ", should be a dict. obj: " + str(obj)
            )

        if class_name is None:
            if "class" in obj:
                class_name = obj.get("class")
            else:
                return obj

        if obj.get("class"):
            if class_name != obj.get("class"):
                raise TypeError(
                    "Argument " + str(obj) + " not of type " + str(class_name)
                )

        custom_json_converter = JsonConverter.CUSTOM_JSON_CONVERTERS.get(
            class_name)
        generic_json_converter = JsonConverter.GENERIC_JSON_CONVERTERS.get(
            class_name)
        if custom_json_converter is not None or generic_json_converter is not None:
            mapped_obj = {}
            for key, value in obj.items():
                mapped_obj[JsonConverter.to_snake_case(key)] = value
            if custom_json_converter is not None:
                obj = custom_json_converter(mapped_obj)
            else:
                mapped_obj.pop("class", None)
                obj = generic_json_converter(mapped_obj)

        return obj

    @staticmethod
    def from_json(json_obj, class_obj=None, class_name=None, validate=False):
        if json_obj is None:
            return None

        if class_obj is not None:
            if hasattr(class_obj, "CLASS"):
                class_name = class_obj.CLASS

        if class_name is not None:
            if isinstance(json_obj, str):
                json_obj = json.loads(json_obj)
            if isinstance(json_obj, list):
                obj = []
                for item in json_obj:
                    if class_obj is None or \
                            (not isinstance(item, class_obj)):
                        item = JsonConverter.object_decoder(
                            item, class_name)
                    obj.append(item)
            else:
                obj = JsonConverter.object_decoder(
                    json_obj, class_name)
        else:
            json_obj_str = json_obj
            if not isinstance(json_obj_str, str):
                try:
                    json_obj_str = json.dumps(json_obj_str)
                except json.JSONDecodeError:
                    json_obj_str = json_obj
            obj = json.loads(json_obj_str,
                             object_hook=JsonConverter.object_decoder)

        if validate:
            if isinstance(obj, ToJson):
                if isinstance(json_obj, str):
                    json_obj = json.loads(json_obj)
                elif isinstance(json_obj, ToJson):
                    json_obj = json_obj.to_json()

                if not isinstance(obj, ToJson):
                    if not isinstance(json_obj, str):
                        json_obj = json.dumps(json_obj)
                    raise TypeError(
                        "Json object could not be deserialised correctly: \n" + json_obj)
                if json_obj != obj.to_json():
                    raise TypeError(
                        "Json object could not be deserialised correctly: \n"
                        "Original: \n"
                        + json.dumps(json_obj)
                        + " \nConverted:\n"
                        + json.dumps(obj.to_json()))
            else:
                if not isinstance(json_obj, str):
                    json_obj = json.dumps(json_obj)
                raise TypeError(
                    "Json object could not be deserialised correctly: \n" + json_obj)

        return obj

    @staticmethod
    def validate(obj, expected_class, allow_none=True):
        if obj is None:
            if allow_none:
                return None
            raise TypeError("Argument must be of type " + str(expected_class))
        if not issubclass(expected_class, ToJson):
            raise TypeError(str(expected_class) + " must inherit ToJson")
        if not isinstance(obj, ToJson):
            obj = JsonConverter.from_json(obj, expected_class)
        if not isinstance(obj, expected_class):
            raise TypeError(str(obj) + " must be of type " +
                            str(expected_class))
        return obj


def load_core_json_map():
    for name, class_obj in inspect.getmembers(
            sys.modules[__name__], inspect.isclass):
        if hasattr(class_obj, "CLASS"):
            JsonConverter.GENERIC_JSON_CONVERTERS[class_obj.CLASS] = \
                lambda obj, class_obj=class_obj: class_obj(**obj)
            JsonConverter.CLASS_MAP[class_obj.CLASS] = class_obj


load_core_json_map()


class BinaryOperator(ToJson, ToCodeString):
    CLASS = "java.util.function.BinaryOperator"

    def __init__(self, class_name=None, fields=None):
        self.class_name = class_name
        self.fields = fields

    def to_json(self):
        if self.fields is not None:
            function_json = dict(self.fields)
        else:
            function_json = {}

        if self.class_name is not None:
            function_json["class"] = self.class_name

        return function_json


class AbstractBinaryOperator(BinaryOperator):
    CLASS = "java.util.function.BinaryOperator"

    def __init__(self, _class_name=None):
        super().__init__()
        self._class_name = _class_name

    def to_json(self):
        function_json = {}

        if self._class_name is not None:
            function_json["class"] = self._class_name

        return function_json


class Predicate(ToJson, ToCodeString):
    CLASS = "java.util.function.Predicate"

    def __init__(self, class_name=None, fields=None):
        self.class_name = class_name
        self.fields = fields

    def to_json(self):
        if self.fields is not None:
            predicate_json = dict(self.fields)
        else:
            predicate_json = {}

        if self.class_name is not None:
            predicate_json["class"] = self.class_name

        return predicate_json


class AbstractPredicate(Predicate):
    def __init__(self, _class_name=None):
        super().__init__()
        self._class_name = _class_name

    def to_json(self):
        predicate_json = {}

        if self._class_name is not None:
            predicate_json["class"] = self._class_name

        return predicate_json


class Function(ToJson, ToCodeString):
    CLASS = "java.util.function.Function"

    def __init__(self, class_name=None, fields=None):
        self.class_name = class_name
        self.fields = fields

    def to_json(self):
        if self.fields is not None:
            function_json = dict(self.fields)
        else:
            function_json = {}

        if self.class_name is not None:
            function_json["class"] = self.class_name

        return function_json


class AbstractFunction(Function):
    CLASS = "java.util.function.Function"

    def __init__(self, _class_name=None):
        super().__init__()
        self._class_name = _class_name

    def to_json(self):
        function_json = {}
        if self._class_name is not None:
            function_json["class"] = self._class_name

        return function_json
