

"""
This module contains Python copies of Abution operation java classes
"""

import abutionpy.abution_aggregator as abution_binaryoperators
import abutionpy.abution_functions as abution_functions
import abutionpy.abution_predicates as abution_predicates
from abutionpy.abution_core import *


class NamedOperationParameter(ToJson, ToCodeString):
    CLASS = "abution.NamedOperationParameter"

    def __init__(self,
                 name,
                 value_class,
                 description=None,
                 default_value=None,
                 required=False):
        self.name = name
        self.value_class = value_class
        self.description = description
        self.default_value = default_value
        self.required = required

    def get_detail(self):
        detail = {
            "valueClass": self.value_class,
            "required": self.required
        }
        if self.description is not None:
            detail["description"] = self.description
        if self.default_value is not None:
            detail["defaultValue"] = self.default_value
        return detail

    def to_json(self):
        return {
            "description": self.description,
            "defaultValue": self.default_value,
            "valueClass": self.value_class,
            "required": self.required
        }


class NamedViewParameter(ToJson, ToCodeString):
    CLASS = "abution.NamedViewParameter"

    def __init__(self,
                 name,
                 value_class,
                 description=None,
                 default_value=None,
                 required=False):
        self.name = name
        self.value_class = value_class
        self.description = description
        self.default_value = default_value
        self.required = required

    def get_detail(self):
        detail = {
            "valueClass": self.value_class,
            "required": self.required
        }
        if self.description is not None:
            detail["description"] = self.description
        if self.default_value is not None:
            detail["defaultValue"] = self.default_value
        return detail

    def to_json(self):
        return {
            "description": self.description,
            "defaultValue": self.default_value,
            "valueClass": self.value_class,
            "required": self.required
        }


class View(ToJson, ToCodeString):
    CLASS = "cn.thutmose.abution.graph.data.definition.view.View"

    def __init__(self, entities=None, edges=None, global_knowledges=None,
                 global_entities=None, global_edges=None, all_edges=False,
                 all_entities=False):
        super().__init__()
        self.entities = None
        self.edges = None
        self.global_knowledges = None
        self.global_entities = None
        self.global_edges = None
        self.all_edges = all_edges
        self.all_entities = all_entities

        if entities is not None:
            self.entities = []
            if isinstance(entities, list):
                for el_def in entities:
                    if not isinstance(el_def, KnowledgeDefinition):
                        el_def = JsonConverter.from_json(
                            el_def, KnowledgeDefinition)
                    self.entities.append(el_def)
            else:
                for group, el_def in entities.items():
                    if not isinstance(el_def, KnowledgeDefinition):
                        el_def = JsonConverter.from_json(
                            el_def, KnowledgeDefinition)
                    el_def.label = group
                    self.entities.append(el_def)

        if edges is not None:
            self.edges = []
            if isinstance(edges, list):
                for el_def in edges:
                    if not isinstance(el_def, KnowledgeDefinition):
                        el_def = JsonConverter.from_json(
                            el_def, KnowledgeDefinition)
                    self.edges.append(el_def)
            else:
                for group, el_def in edges.items():
                    if not isinstance(el_def, KnowledgeDefinition):
                        el_def = JsonConverter.from_json(
                            el_def, KnowledgeDefinition)
                    el_def.label = group
                    self.edges.append(el_def)

        if global_knowledges is not None:
            self.global_knowledges = []
            if isinstance(global_knowledges, list):
                for el_def in global_knowledges:
                    if not isinstance(el_def, GlobalKnowledgeDefinition):
                        el_def = JsonConverter.from_json(
                            el_def, GlobalKnowledgeDefinition)
                    self.global_knowledges.append(el_def)
            elif isinstance(global_knowledges, GlobalKnowledgeDefinition):
                self.global_knowledges.append(global_knowledges)
            else:
                for group, el_def in global_knowledges.items():
                    if not isinstance(el_def, GlobalKnowledgeDefinition):
                        el_def = JsonConverter.from_json(
                            el_def, GlobalKnowledgeDefinition)
                    self.global_knowledges.append(el_def)

        if global_entities is not None:
            self.global_entities = []
            if isinstance(global_entities, list):
                for el_def in global_entities:
                    if not isinstance(el_def, GlobalKnowledgeDefinition):
                        el_def = JsonConverter.from_json(
                            el_def, GlobalKnowledgeDefinition)
                    self.global_entities.append(el_def)
            elif isinstance(global_entities, GlobalKnowledgeDefinition):
                self.global_entities.append(global_entities)
            else:
                for group, el_def in global_entities.items():
                    if not isinstance(el_def, GlobalKnowledgeDefinition):
                        el_def = JsonConverter.from_json(
                            el_def, GlobalKnowledgeDefinition)
                    self.global_entities.append(el_def)

        if global_edges is not None:
            self.global_edges = []
            if isinstance(global_edges, list):
                for el_def in global_edges:
                    if not isinstance(el_def, GlobalKnowledgeDefinition):
                        el_def = JsonConverter.from_json(
                            el_def, GlobalKnowledgeDefinition)
                    self.global_edges.append(el_def)
            elif isinstance(global_edges, GlobalKnowledgeDefinition):
                self.global_edges.append(global_edges)
            else:
                for group, el_def in global_edges.items():
                    if not isinstance(el_def, GlobalKnowledgeDefinition):
                        el_def = JsonConverter.from_json(
                            el_def, GlobalKnowledgeDefinition)
                    self.global_edges.append(el_def)

    def to_json(self):
        view = {}
        if self.entities is not None:
            el_defs = {}
            for el_def in self.entities:
                el_defs[el_def.label] = el_def.to_json()
            view["entities"] = el_defs
        if self.edges is not None:
            el_defs = {}
            for el_def in self.edges:
                el_defs[el_def.label] = el_def.to_json()
            view["edges"] = el_defs

        if self.global_knowledges is not None:
            el_defs = []
            for el_def in self.global_knowledges:
                el_defs.append(el_def.to_json())
            view["globalKnowledge"] = el_defs

        if self.global_entities is not None:
            el_defs = []
            for el_def in self.global_entities:
                el_defs.append(el_def.to_json())
            view["globalEntities"] = el_defs

        if self.global_edges is not None:
            el_defs = []
            for el_def in self.global_edges:
                el_defs.append(el_def.to_json())
            view["globalEdges"] = el_defs

        if self.all_edges:
            view["allEdges"] = True

        if self.all_entities:
            view["allEntities"] = True

        return view


class KnowledgeDefinition(ToJson, ToCodeString):
    CLASS = "cn.thutmose.abution.graph.data.definition.view.ViewKnowledgeDefinition"

    def __init__(self, label="",
                 transient_properties=None,
                 group_by=None,
                 pre_agg_filter_functions=None,
                 aggregate_functions=None,
                 post_agg_filter_functions=None,
                 transform_functions=None,
                 post_transform_filter_functions=None,
                 properties=None,
                 exclude_properties=None):
        super().__init__()
        self.label = label

        if transient_properties is None:
            self.transient_properties = None
        else:
            self.transient_properties = {}
            if isinstance(transient_properties, list):
                for prop in transient_properties:
                    if not isinstance(prop, Property):
                        prop = JsonConverter.from_json(prop, Property)
                    self.transient_properties[prop.name] = prop.class_name
            else:
                for propName, propClass in transient_properties.items():
                    self.transient_properties[propName] = propClass

        self.pre_agg_filter_functions = JsonConverter.from_json(
            pre_agg_filter_functions,
            abution_predicates.PredicateContext)

        self.aggregate_functions = JsonConverter.from_json(
            aggregate_functions, abution_predicates.PredicateContext)

        self.post_agg_filter_functions = JsonConverter.from_json(
            post_agg_filter_functions,
            abution_predicates.PredicateContext)

        self.transform_functions = JsonConverter.from_json(
            transform_functions, abution_functions.FunctionContext)

        self.post_transform_filter_functions = JsonConverter.from_json(
            post_transform_filter_functions, abution_predicates.PredicateContext)

        self.group_by = group_by
        self.properties = properties
        self.exclude_properties = exclude_properties

    def to_json(self):
        element_def = {}
        if self.transient_properties is not None:
            element_def["transientProperties"] = self.transient_properties
        if self.pre_agg_filter_functions is not None:
            funcs = []
            for func in self.pre_agg_filter_functions:
                funcs.append(func.to_json())
            element_def["preAggFilterFuncs"] = funcs
        if self.post_agg_filter_functions is not None:
            funcs = []
            for func in self.post_agg_filter_functions:
                funcs.append(func.to_json())
            element_def["postAggFilterFuncs"] = funcs
        if self.transform_functions is not None:
            funcs = []
            for func in self.transform_functions:
                funcs.append(func.to_json())
            element_def["transformFuncs"] = funcs
        if self.post_transform_filter_functions is not None:
            funcs = []
            for func in self.post_transform_filter_functions:
                funcs.append(func.to_json())
            element_def["postTransformFilterFuncs"] = funcs
        if self.group_by is not None:
            element_def["groupBy"] = self.group_by
        if self.properties is not None:
            element_def["properties"] = self.properties
        if self.exclude_properties is not None:
            element_def["excludeProperties"] = self.exclude_properties
        return element_def


class KnowledgeTransformer(ToJson, ToCodeString):
    CLASS = "cn.thutmose.abution.graph.data.knowhow.function.KnowledgeTransformer"

    def __init__(self, group="",
                 functions=None):
        super().__init__()
        self.group = group
        self.functions = JsonConverter.from_json(
            functions, abution_functions.FunctionContext)

    def to_json(self):
        element_def = {}
        if self.functions is not None:
            funcs = []
            for func in self.functions:
                funcs.append(func.to_json())
            element_def["functions"] = funcs
        return element_def


class AggregatePair(ToJson, ToCodeString):
    CLASS = "cn.thutmose.abution.graph.operation.util.AggregatePair"

    def __init__(self,
                 group=None,
                 group_by=None,
                 element_aggregator=None):
        super().__init__()
        self.group = group
        if group_by is not None and not isinstance(group_by, list):
            group_by = [group_by]
        self.group_by = group_by
        if element_aggregator is not None and not isinstance(element_aggregator,
                                                             KnowledgeAggregator):
            element_aggregator = KnowledgeAggregator(
                operators=element_aggregator["operators"])
        self.element_aggregator = element_aggregator

    def to_json(self):
        element_def = {}
        if self.group_by is not None:
            element_def["groupBy"] = self.group_by
        if self.element_aggregator is not None:
            element_def["knowledgeAggregator"] = self.element_aggregator.to_json()
        return element_def


class KnowledgeAggregator(ToJson, ToCodeString):
    CLASS = "cn.thutmose.abution.graph.data.knowhow.function.KnowledgeAggregator"

    def __init__(self, operators=None):
        super().__init__()
        self.operators = JsonConverter.from_json(
            operators, abution_binaryoperators.BinaryOperatorContext)

    def to_json(self):
        element_def = {}
        if self.operators is not None:
            funcs = []
            for function in self.operators:
                funcs.append(function.to_json())
            element_def["operators"] = funcs
        return element_def


class KnowledgeFilter(ToJson, ToCodeString):
    CLASS = "cn.thutmose.abution.graph.data.knowhow.function.KnowledgeFilter"

    def __init__(self, group="",
                 predicates=None):
        super().__init__()
        self.group = group
        self.predicates = JsonConverter.from_json(
            predicates, abution_predicates.PredicateContext)

    def to_json(self):
        element_def = {}
        if self.predicates is not None:
            funcs = []
            for function in self.predicates:
                funcs.append(function.to_json())
            element_def["predicates"] = funcs
        return element_def


class GlobalKnowledgeFilter(ToJson, ToCodeString):
    CLASS = "cn.thutmose.abution.graph.operation.impl.function.GlobalKnowledgeFilter"

    def __init__(self, predicates=None):
        super().__init__()
        self.predicates = JsonConverter.from_json(
            predicates, abution_predicates.PredicateContext)

    def to_json(self):
        element_def = {}
        if self.predicates is not None:
            funcs = []
            for func in self.predicates:
                funcs.append(func.to_json())
            element_def["predicates"] = funcs
        return element_def


class GlobalKnowledgeDefinition(ToJson, ToCodeString):
    CLASS = "cn.thutmose.abution.graph.data.definition.view.GlobalViewKnowledgeDefinition"

    def __init__(self,
                 labels=None,
                 transient_properties=None,
                 group_by=None,
                 pre_agg_filter_functions=None,
                 post_agg_filter_functions=None,
                 transform_functions=None,
                 post_transform_filter_functions=None,
                 properties=None,
                 exclude_properties=None):
        super().__init__()
        # if labels is None:
        #     labels = []
        if labels is not None:
            self.labels = labels
        else:
            self.labels = None

        if transient_properties is None:
            self.transient_properties = None
        else:
            self.transient_properties = {}
            if isinstance(transient_properties, list):
                for prop in transient_properties:
                    if not isinstance(prop, Property):
                        prop = JsonConverter.from_json(prop, Property)
                    self.transient_properties[prop.name] = prop.class_name
            else:
                for propName, propClass in transient_properties.items():
                    self.transient_properties[propName] = propClass

        self.pre_agg_filter_functions = JsonConverter.from_json(
            pre_agg_filter_functions,
            abution_predicates.PredicateContext)

        self.post_agg_filter_functions = JsonConverter.from_json(
            post_agg_filter_functions,
            abution_predicates.PredicateContext)

        self.transform_functions = JsonConverter.from_json(
            transform_functions, abution_functions.FunctionContext)

        self.post_transform_filter_functions = JsonConverter.from_json(
            post_transform_filter_functions, abution_predicates.PredicateContext)

        self.group_by = group_by

        self.properties = properties
        self.exclude_properties = exclude_properties

    def to_json(self):
        element_def = {}
        if self.labels is not None:
            if not isinstance(self.labels, list):
                self.labels = [self.labels]
            else:
                self.labels = list(self.labels)
            element_def["labels"] = self.labels
        if self.transient_properties is not None:
            element_def["transientProperties"] = self.transient_properties
        if self.pre_agg_filter_functions is not None:
            funcs = []
            for func in self.pre_agg_filter_functions:
                funcs.append(func.to_json())
            element_def["preAggFilterFuncs"] = funcs
        if self.post_agg_filter_functions is not None:
            funcs = []
            for func in self.post_agg_filter_functions:
                funcs.append(func.to_json())
            element_def["postAggFilterFuncs"] = funcs
        if self.transform_functions is not None:
            funcs = []
            for func in self.transform_functions:
                funcs.append(func.to_json())
            element_def["transformFuncs"] = funcs
        if self.post_transform_filter_functions is not None:
            funcs = []
            for func in self.post_transform_filter_functions:
                funcs.append(func.to_json())
            element_def["postTransformFilterFuncs"] = funcs
        if self.group_by is not None:
            element_def["groupBy"] = self.group_by
        if self.properties is not None:
            element_def["properties"] = self.properties
        if self.exclude_properties is not None:
            element_def["excludeProperties"] = self.exclude_properties
        return element_def


class Property(ToJson, ToCodeString):
    CLASS = "cn.thutmose.abution.graph.data.knowhow.Properties" #.data.element.Property

    def __init__(self, name, class_name):
        super().__init__()
        if not isinstance(name, str):
            raise TypeError("Name must be a string")
        if not isinstance(class_name, str):
            raise TypeError("ClassName must be a class name string")
        self.name = name
        self.class_name = class_name

    def to_json(self):
        return {self.name: self.class_name}


class Operation(ToJson, ToCodeString):
    def __init__(self,
                 _class_name,
                 view=None,
                 options=None,
                 views=None):
        self._class_name = _class_name

        if view is not None and isinstance(view, list):
            views = view
            view = None

        if view is not None and isinstance(view, dict):
            view = JsonConverter.from_json(view, View)
        self.view = view

        self.views = None
        if views is not None and isinstance(views, list):
            self.views = []
            for view in views:
                if not isinstance(view, View):
                    view = JsonConverter.from_json(view, View)
                self.views.append(view)

        # Helper so that lists will be interpreted as federated graphIds
        # e.g. options = ["graph_1", "graph_2"]
        if isinstance(options, list):
            options = {
                "abution.operation.graphIds": ",".join(options)
            }
        self.options = options

    def to_json(self):
        operation = {"class": self._class_name}
        if self.options is not None:
            operation["options"] = self.options
        if self.view is not None:
            operation["view"] = ToJson.recursive_to_json(self.view)
        if self.views is not None:
            operation["views"] = []
            for view in self.views:
                operation["views"].append(ToJson.recursive_to_json(view))

        return operation

    def validate_operation_chain(self, operation_chain, allow_none=False):
        if isinstance(operation_chain, list):
            for operation in operation_chain:
                JsonConverter.validate(operation, Operation)
            return GqlChain(operation_chain)
        try:
            return JsonConverter.validate(
                operation_chain, GqlChain, allow_none
            )
        except BaseException:
            return GqlChain([
                JsonConverter.validate(
                    operation_chain, Operation, allow_none
                )
            ])


class Match(ToJson, ToCodeString):
    def __init__(self, _class_name):
        self._class_name = _class_name

    def to_json(self):
        return {
            "class": self._class_name
        }


class KnowledgeMatch(Match):

    CLASS = "cn.thutmose.abution.graph.store.operation.handler.join.match.KnowledgeMatch"

    def __init__(self, group_by_properties=None):
        super().__init__(_class_name=self.CLASS)
        self.group_by_properties = group_by_properties

    def to_json(self):
        match_json = super().to_json()
        if (self.group_by_properties is not None):
            match_json["groupByProperties"] = self.group_by_properties

        return match_json


class KeyFunctionMatch(Match):
    CLASS = "cn.thutmose.abution.graph.store.operation.handler.join.match.KeyFunctionMatch"

    def __init__(self, first_key_function=None, second_key_function=None):
        super().__init__(_class_name=self.CLASS)

        if not isinstance(first_key_function, abution_functions.Function):
            self.first_key_function = JsonConverter.from_json(
                first_key_function, class_obj=abution_functions.Function)
        else:
            self.first_key_function = first_key_function

        if not isinstance(second_key_function, abution_functions.Function):
            self.second_key_function = JsonConverter.from_json(
                second_key_function, class_obj=abution_functions.Function)
        else:
            self.second_key_function = second_key_function

    def to_json(self):
        match_json = super().to_json()
        if self.first_key_function is not None:
            match_json["firstKeyFunction"] = self.first_key_function.to_json()
        if self.second_key_function is not None:
            match_json["secondKeyFunction"] = self.second_key_function.to_json()

        return match_json


class Conditional(ToJson, ToCodeString):
    CLASS = "cn.thutmose.abution.graph.operation.util.Conditional"

    def __init__(self, predicate=None, transform=None):
        self.predicate = JsonConverter.validate(
            predicate, abution_predicates.Predicate
        )
        self.transform = JsonConverter.validate(
            transform, Operation
        )

    def to_json(self):
        conditional_json = {}
        if self.predicate is not None:
            conditional_json["predicate"] = self.predicate.to_json()

        if self.transform is not None:
            conditional_json["transform"] = self.transform.to_json()

        return conditional_json


# Import generated operation implementations from fishbowl
from abutionpy.generated_api.operations import *

# Parameters


# class AddNamedOperation(AddNamedOperation):
#     def to_json(self):
#         operation_json = super().to_json()
#         if self.parameters is not None:
#             if isinstance(self.parameters, list):
#                 operation_json["parameters"] = {}
#                 for param in self.parameters:
#                     operation_json["parameters"][param.name] = param.get_detail()
#         return operation_json
#
#
# class AddNamedView(AddNamedView):
#     def to_json(self):
#         operation_json = super().to_json()
#         if self.parameters is not None:
#             if isinstance(self.parameters, list):
#                 operation_json["parameters"] = {}
#                 for param in self.parameters:
#                     operation_json["parameters"][param.name] = param.get_detail()
#         return operation_json

# Element definitions


class Filter(Filter):
    def to_json(self):
        operation_json = super().to_json()
        if self.edges is not None:
            if isinstance(self.edges, list):
                operation_json["edges"] = {}
                for el_def in self.edges:
                    operation_json["edges"][el_def.label] = el_def.to_json()
        if self.entities is not None:
            if isinstance(self.entities, list):
                operation_json["entities"] = {}
                for el_def in self.entities:
                    operation_json["entities"][el_def.label] = el_def.to_json()
        return operation_json


class Aggregate(Aggregate):
    def to_json(self):
        operation_json = super().to_json()
        if self.edges is not None:
            if isinstance(self.edges, list):
                operation_json["edges"] = {}
                for el_def in self.edges:
                    operation_json["edges"][el_def.label] = el_def.to_json()
        if self.entities is not None:
            if isinstance(self.entities, list):
                operation_json["entities"] = {}
                for el_def in self.entities:
                    operation_json["entities"][el_def.label] = el_def.to_json()
        return operation_json


class Transform(Transform):
    def to_json(self):
        operation_json = super().to_json()
        if self.edges is not None:
            if isinstance(self.edges, list):
                operation_json["edges"] = {}
                for el_def in self.edges:
                    operation_json["edges"][el_def.label] = el_def.to_json()
        if self.entities is not None:
            if isinstance(self.entities, list):
                operation_json["entities"] = {}
                for el_def in self.entities:
                    operation_json["entities"][el_def.label] = el_def.to_json()
        return operation_json

# List Input


class If(If):
    def to_json(self):
        operation_json = super().to_json()
        if self.input is not None:
            if not isinstance(self.input, list):
                operation_json["input"] = [self.input]
        return operation_json

# Element Input


class GetOperation(Operation):
    def to_json(self):
        operation_json = super().to_json()
        # if self.input is not None:
        #     json_seeds = []
        #     if not isinstance(self.input, list):
        #         self.input = [self.input]
        #     for seed in self.input:
        #         if isinstance(seed, dict):
        #             if seed.get("class"):
        #                 seed = JsonConverter.from_json(seed)
        #         if isinstance(seed, KnowledgeKey):
        #             json_seeds.append(seed.to_json())
        #         else:
        #             json_seeds.append(EntityKey(seed).to_json())
        #     operation_json["input"] = json_seeds
        if isinstance(self.view, list):
            operation_json["views"] = operation_json.pop("view")

        return operation_json


class GetEntity(GetOperation, GetEntity):
    def to_json(self):
        return super().to_json()

class GetEdge(GetOperation, GetEdge):
    def to_json(self):
        return super().to_json()

class GetKnowledge(GetOperation, GetKnowledge):
    def to_json(self):
        return super().to_json()

# 新加
class ScanEntity(GetOperation, ScanEntity):
    def to_json(self):
        return super().to_json()

class ScanEdge(GetOperation, Edge):
    def to_json(self):
        return super().to_json()

class ScanKnowledge(GetOperation, ScanKnowledge):
    def to_json(self):
        return super().to_json()


class ToVertices(GetOperation, ToVertices):
    def to_json(self):
        return super().to_json()

# Entity Input


class GetPath(GetOperation, GetPath):
    def to_json(self):
        return super().to_json()


class GetNeighborIds(GetOperation, GetNeighborIds):
    def to_json(self):
        return super().to_json()


class GetKnowledgeWithinSet(GetOperation, GetKnowledgeWithinSet):
    def to_json(self):
        return super().to_json()


def load_operation_json_map():
    for name, class_obj in inspect.getmembers(
            sys.modules[__name__], inspect.isclass):
        if hasattr(class_obj, "CLASS"):
            JsonConverter.GENERIC_JSON_CONVERTERS[class_obj.CLASS] = \
                lambda obj, class_obj=class_obj: class_obj(**obj)
            JsonConverter.CLASS_MAP[class_obj.CLASS] = class_obj


load_operation_json_map()
