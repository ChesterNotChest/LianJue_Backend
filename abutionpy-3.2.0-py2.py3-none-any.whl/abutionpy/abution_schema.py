from typing import Dict, Any

from abutionpy.abution_aggregator import Aggregators
from abutionpy.abution_serialisation import Serialisers
from abutionpy.abution_types import Types

class T(Types):
    def __init__(self):
        super().__init__()

class S(Serialisers):
    def __init__(self):
        super().__init__()

class Agg(Aggregators):
    def __init__(self):
        super().__init__()



class Dimension:
    """维度构建器"""

    @staticmethod
    def label(label, description=None):
        """创建标签维度"""
        return Dimension(label, description)

    def __init__(self, label, description=None):
        self.label = label
        self.description = description
        self.properties = []
        self.group_by = None

    def property(self, name, prop_type, aggregate=None, description:str=None, serialiser=None):
        """添加属性"""

        # 普通维度 - 如果aggregate是字符串且description为空，说明是简单的属性定义
        if isinstance(aggregate, str) and description is None:
            description = aggregate
            aggregate = None

        if serialiser is None:
            serialiser = TSMapping.get_serialiser_for_type(prop_type)

        self.properties.append({
            "name": name,
            "type": prop_type,
            "aggregate": aggregate,
            "serialiser": serialiser,
            "description": description
        })
        return self

    def groupBy(self, *fields):
        """设置分组字段"""
        self.group_by = list(fields) if fields else []
        return self

    def build(self):
        """构建维度字典"""
        return {
            "label": self.label,
            "description": self.description,
            "properties": self.properties,
            "group_by": self.group_by
        }


class Schema:
    """Schema 构建器"""

    @staticmethod
    def entity(entity_name, dimension_dict):
        """创建实体"""
        dimension_dict["entity_name"] = entity_name
        return {"type": "entity", "data": dimension_dict}

    @staticmethod
    def edge(source, target, dimension_dict):
        """创建边"""
        dimension_dict["source"] = source
        dimension_dict["target"] = target
        return {"type": "edge", "data": dimension_dict}

    class _Builder:
        """Schema 构建器内部类"""

        def __init__(self):
            self.entities = {}
            self.edges = {}
            self.data_role_property = None

        def entity(self, entity_name, dimension_dict):
            """链式添加实体"""
            dimension_dict["entity_name"] = entity_name
            self.entities[dimension_dict["label"]] = dimension_dict
            return self

        def edge(self, source, target, dimension_dict):
            """链式添加边"""
            dimension_dict["source"] = source
            dimension_dict["target"] = target
            self.edges[dimension_dict["label"]] = dimension_dict
            return self

        def merge(self, entity_or_edge):
            """合并实体或边"""
            if entity_or_edge["type"] == "entity":
                entity = entity_or_edge["data"]
                self.entities[entity["label"]] = entity
            elif entity_or_edge["type"] == "edge":
                edge = entity_or_edge["data"]
                self.edges[edge["label"]] = edge
            return self

        def dataRoleProperty(self, property_name):
            """设置数据角色属性"""
            self.data_role_property = property_name
            return self

        def build(self):
            """构建完整 Schema 字典"""
            # 初始化结果字典
            result = {
                "entities": {},
                "edges": {},
                "types": {
                    "DIRECTED": {"class": "java.lang.Boolean"}
                },
                "dataRoleProperty": self.data_role_property,
                "vertexSerialiser": S.String
            }

            # 处理实体
            for label, entity in self.entities.items():
                result["entities"][label] = {
                    "description": entity["description"],
                    "vertex": entity["entity_name"],
                    "properties": {}
                }

                # 添加实体名称类型
                result["types"][entity["entity_name"]] = {"class": T.String}

                # 添加分组信息
                if entity["group_by"] is not None:
                    result["entities"][label]["groupBy"] = entity["group_by"]
                else:
                    result["entities"][label]["aggregate"] = False

                # 处理属性
                for prop in entity["properties"]:
                    prop_full_name = f"{label}.{prop['name']}"
                    result["entities"][label]["properties"][prop['name']] = prop_full_name

                    # 添加类型信息
                    type_info = {
                        "description": prop.get("description"),
                        "class": prop["type"]
                    }
                    if prop["aggregate"]:
                        type_info["aggregateFunction"] = prop["aggregate"]
                    if prop["serialiser"]:
                        type_info["serialiser"] = prop["serialiser"]

                    result["types"][prop_full_name] = type_info

            # 处理边
            for label, edge in self.edges.items():
                result["edges"][label] = {
                    "description": edge["description"],
                    "source": edge["source"],
                    "target": edge["target"],
                    "directed": "DIRECTED",
                    "properties": {}
                }

                # 添加分组信息
                if edge["group_by"] is not None:
                    result["edges"][label]["groupBy"] = edge["group_by"]
                else:
                    result["edges"][label]["aggregate"] = False

                # 处理属性
                for prop in edge["properties"]:
                    prop_full_name = f"{label}.{prop['name']}"
                    result["edges"][label]["properties"][prop['name']] = prop_full_name

                    # 添加类型信息
                    type_info = {
                        "description": prop.get("description"),
                        "class": prop["type"]
                    }
                    if prop["aggregate"]:
                        type_info["aggregateFunction"] = prop["aggregate"]
                    if prop["serialiser"]:
                        type_info["serialiser"] = prop["serialiser"]

                    result["types"][prop_full_name] = type_info

            # 返回Schema实例而不是直接返回字典
            return Schema._SchemaInstance(result)

    class _SchemaInstance:
        """Schema实例类，包含to_json方法"""

        def __init__(self, schema_dict):
            self.schema_dict = schema_dict

        def to_json(self, indent=None, ensure_ascii=False):
            """将schema转换为JSON字符串"""
            import json
            return json.dumps(self.schema_dict, indent=indent, ensure_ascii=ensure_ascii)

        def __str__(self):
            return self.to_json(indent=2, ensure_ascii=False)

    @staticmethod
    def Builder():
        """创建顶层构建器"""
        return Schema._Builder()

#----------------------------------------------------------------------------------------------------------------------

def get_schema_test1():
    """获取完整的 Schema 定义"""
    # 方式1：链式调用
    schema = (
        Schema.Builder()
        .entity("社区",
                Dimension.label("V|Community",
                                "通过语义相似度算法计算的社区，及不在社区的节点单独存一个实体用于下次加入计算")
                .property("title", T.String, Agg.Last, "标题")
                .property("abstract", T.String, Agg.Last, "摘要")
                .property("vec_comm", T.CustomMap, Agg.VertexSimVecMapAggregator,
                          "[更方便计算]社区向量集合(向量最后加一个元素,长度不一则语义相减,否则语义相加)-用于主题检索")
                .property("v_neighbors", T.CustomMap, Agg.VertexSimNeighborMapAggregator,
                          "存储社区成员，社区中每个节点的：List(\"邻居:相似度\")，存入邻居名前缀[del]代表删除节点")
                .groupBy()
                .build()
                )
        .entity("实体",
                Dimension.label("V|Element", "段落中的实体")
                .property("classify", T.String, Agg.Last, "子图隔离")
                .property("v_label", T.String, Agg.Last, "实体标签")
                .property("desc", T.TreeSet, Agg.CollectionConcat, S.TreeSetString,
                          "该章节某段落中实体的描述")
                .property("hll", T.DistinctCountHllp, Agg.DistinctCountHllp, "高基数统计")
                .groupBy("v_label")
                .build()
                )
        .edge("实体", "实体",
              Dimension.label("E|Contact", "段落中实体间的联系")
              .property("classify", T.String, Agg.Last, "子图隔离")
              .property("relational", T.TreeSet, Agg.CollectionConcat, S.TreeSetString,
                        "实体间的关系，格式：实体1-关系(描述)-实体2")
              .property("weight", T.Double, Agg.Max, "权重")
              .groupBy()
              .build()
              )
        .edge("实体", "实体",
              Dimension.label("E|Hyper", "语义相似性超边")
              .property("similarity", T.Double, Agg.Max, "语义相似度")
              .groupBy()
              .build()
              )
        .dataRoleProperty("classify")
        .build()
    )

    # 方式2：分步构建（保留原有方式）
    """
    schema_entity0 = Schema.entity("社区", 
        Dimension.label("V|Community", "...").build())
    schema_entity3 = Schema.entity("实体", 
        Dimension.label("V|Element", "...").build())
    schema_edge6 = Schema.edge("实体", "实体", 
        Dimension.label("E|Contact", "...").build())
    schema_edge7 = Schema.edge("实体", "实体", 
        Dimension.label("E|Hyper", "...").build())

    schema = (
        Schema.Builder()
        .merge(schema_entity0)
        .merge(schema_entity3)
        .merge(schema_edge6)
        .merge(schema_edge7)
        .dataRoleProperty("classify")
        .build()
    )
    """

    return schema

class TSMapping:
    """类型与序列化器映射"""
    # 基本类型映射
    TYPE_TO_SERIALISER = {
        # 基本数据类型
        T.String: S.String,
        T.Double: S.Double,
        T.Integer: S.Integer,
        T.Boolean: S.Boolean,
        T.Byte: S.Bytes,  # 使用Bytes序列化器
        T.Short: S.Integer,  # Short使用Integer序列化器
        T.Long: S.Long,
        T.Float: S.Float,
        T.Character: S.String,  # Character使用String序列化器
        T.BigDecimal: S.Bigdecimal,
        T.BigInteger: S.Bigdecimal,  # BigInteger使用BigDecimal序列化器

        # 时间类型
        T.Date: S.Date,
        T.LocalDateTime: S.LocalDateTime,
        T.Timestamp: S.Date,  # Timestamp使用Date序列化器

        # 集合类型
        T.List: S.List,
        T.Set: S.Set,
        T.Map: S.Map,
        T.ArrayList: S.List,  # ArrayList使用List序列化器
        T.HashMap: S.Map,  # HashMap使用Map序列化器
        T.HashSet: S.Set,  # HashSet使用Set序列化器
        T.TreeSet: S.TreeSet,
        T.TreeSetString: S.TreeSetString,

        # 自定义类型
        T.CustomMap: S.CustomMap,

        # Bitmap类型
        T.RoaringBitmap: S.RoaringBitmap,
        T.Roaring64NavigableMap: S.Roaring64NavigableMap,

        # 基数统计类型
        T.DistinctCountHll: S.DistinctCountHll,
        T.DistinctCountHllp: S.DistinctCountHllp,
        T.DistinctCountPlus: S.DistinctCountPlus,
        T.DistinctCountThetas: S.DistinctCountThetas,

        # 频率类型
        T.FreqBooleans: S.FreqBooleans,
        T.FreqDoubles: S.FreqDoubles,
        T.FreqLongs: S.FreqLongs,
        T.FreqMap: S.FreqMap,
        T.FreqStrings: S.FreqStrings,

        # 地理类型
        T.Geoshape: S.Geoshape,

        # 分位数类型
        T.QuantileDoubles: S.QuantileDoubles,
        T.QuantileFloats: S.QuantileFloats,
        T.QuantileStrings: S.QuantileStrings,

        # 采样类型
        T.SamplingLongs: S.SamplingLongs,
        T.SamplingStrings: S.SamplingStrings,

        # 时间序列类型
        T.TimeSeries: S.TimeSeries,
        T.TimestampSet: S.TimestampSet,
        T.TimestampSetBounded: S.TimestampSetBounded,

        # TopN类型
        T.TopNCounter: S.TopNCounter,

        # BM25类型
        T.BM25Index: S.BM25Index,

        # 向量索引类型
        T.VectorIndex: S.VectorIndex,

        # 元组类型
        T.LongBigdecimalTuple: S.LongBigdecimalTuple,
        T.LongIntegerTuple: S.LongIntegerTuple,
        T.TypeSubTypeValue: S.TypeSubTypeValue,
        T.TypeValue: S.TypeValue,

        # 数组类型
        T.ByteArray: S.Bytes,
        T.FloatArray: S.FloatArray,
        T.DoubleArray: S.FloatArray,  # DoubleArray使用FloatArray序列化器
        T.IntArray: S.FloatArray,  # IntArray使用FloatArray序列化器
        T.LongArray: S.FloatArray,  # LongArray使用FloatArray序列化器
        T.StringArray: S.List,  # StringArray使用List序列化器

        # Avro类型
        T.Avro: S.Avro,

        # 其他类型
        T.Null: S.Null,
        T.Bytes: S.Bytes,
    }

    @staticmethod
    def get_serialiser_for_type(type_constant):
        """
        根据类型常量获取对应的序列化器

        Args:
            type_constant (str): T类中的类型常量

        Returns:
            dict: 序列化器配置，如果未找到则返回None
        """
        return TSMapping.TYPE_TO_SERIALISER.get(type_constant, None)

# 使用示例
if __name__ == "__main__":
    schema = get_schema_test1()
    import json

    # print(json.dumps(schema, indent=2, ensure_ascii=False))
    print(schema)
    print(schema.to_json())