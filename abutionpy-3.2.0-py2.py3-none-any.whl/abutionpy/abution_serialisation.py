
class Serialisers:
    """序列化器常量"""
    String = {"class": "cn.thutmose.abution.graph.serialisation.impl.StringSerialiser"}
    Double = {"class": "cn.thutmose.abution.graph.serialisation.impl.DoubleSerialiser"}
    Integer = {"class": "cn.thutmose.abution.graph.serialisation.impl.IntegerSerialiser"}
    CustomMap = {"class": "cn.thutmose.abution.graph.serialisation.CustomMapSerialiser"}
    TreeSetString = {"class": "cn.thutmose.abution.graph.serialisation.impl.TreeSetStringSerialiser"}
    DistinctCountHllp = {
        "class": "cn.thutmose.abution.graph.type.cardinality.serialisation.DistinctCountHllpSerialiser"}

    # 基本类型
    Boolean = {"class": "cn.thutmose.abution.graph.serialisation.impl.BooleanSerialiser"}
    Bytes = {"class": "cn.thutmose.abution.graph.serialisation.impl.BytesSerialiser"}
    Date = {"class": "cn.thutmose.abution.graph.serialisation.impl.DateSerialiser"}
    LocalDateTime = {"class": "cn.thutmose.abution.graph.serialisation.impl.LocalDateTimeSerialiser"}
    Float = {"class": "cn.thutmose.abution.graph.serialisation.impl.FloatSerialiser"}
    FloatArray = {"class": "cn.thutmose.abution.graph.serialisation.impl.FloatArraySerialiser"}
    Long = {"class": "cn.thutmose.abution.graph.serialisation.impl.LongSerialiser"}
    Null = {"class": "cn.thutmose.abution.graph.serialisation.impl.NullSerialiser"}

    # 集合类型
    List = {"class": "cn.thutmose.abution.graph.serialisation.impl.ListSerialiser"}
    Set = {"class": "cn.thutmose.abution.graph.serialisation.impl.SetSerialiser"}
    TreeSet = {"class": "cn.thutmose.abution.graph.serialisation.impl.JavaSerialiser"}
    Map = {"class": "cn.thutmose.abution.graph.serialisation.impl.MapSerialiser"}

    # 元组类型
    LongBigdecimalTuple = {"class": "cn.thutmose.abution.graph.serialisation.impl.LongBigdecimalTupleSerialiser"}
    LongIntegerTuple = {"class": "cn.thutmose.abution.graph.serialisation.impl.LongIntegerTupleSerialiser"}
    TypeSubTypeValue = {"class": "cn.thutmose.abution.graph.serialisation.impl.TypeSubTypeValueSerialiser"}
    TypeValue = {"class": "cn.thutmose.abution.graph.serialisation.impl.TypeValueSerialiser"}

    # Bitmap类型
    RoaringBitmap = {"class": "cn.thutmose.abution.graph.type.bitmap.serialisation.RoaringBitmapSerialiser"}
    Roaring64NavigableMap = {
        "class": "cn.thutmose.abution.graph.type.bitmap.serialisation.Roaring64NavigableMapSerialiser"}

    # 基数统计类型
    DistinctCountHll = {"class": "cn.thutmose.abution.graph.type.cardinality.serialisation.DistinctCountHllSerialiser"}
    DistinctCountPlus = {
        "class": "cn.thutmose.abution.graph.type.cardinality.serialisation.DistinctCountPlusSerialiser"}
    DistinctCountThetas = {
        "class": "cn.thutmose.abution.graph.type.cardinality.serialisation.DistinctCountThetasSerialiser"}

    # 频率类型
    FreqBooleans = {"class": "cn.thutmose.abution.graph.type.frequency.serialisation.FreqBooleansSerialiser"}
    FreqDoubles = {"class": "cn.thutmose.abution.graph.type.frequency.serialisation.FreqDoublesSerialiser"}
    FreqLongs = {"class": "cn.thutmose.abution.graph.type.frequency.serialisation.FreqLongsSerialiser"}
    FreqMap = {"class": "cn.thutmose.abution.graph.type.frequency.serialisation.FreqMapSerialiser"}
    FreqStrings = {"class": "cn.thutmose.abution.graph.type.frequency.serialisation.FreqStringsSerialiser"}

    # 地理类型
    Geoshape = {"class": "cn.thutmose.abution.graph.type.geo.serialisation.GeoshapeSerialiser"}

    # 分位数类型
    QuantileDoubles = {"class": "cn.thutmose.abution.graph.type.quantile.serialisation.QuantileDoublesSerialiser"}
    QuantileFloats = {"class": "cn.thutmose.abution.graph.type.quantile.serialisation.QuantileFloatsSerialiser"}
    QuantileStrings = {"class": "cn.thutmose.abution.graph.type.quantile.serialisation.QuantileStringsSerialiser"}

    # 采样类型
    SamplingLongs = {"class": "cn.thutmose.abution.graph.type.sampling.serialisation.SamplingLongsSerialiser"}
    SamplingStrings = {"class": "cn.thutmose.abution.graph.type.sampling.serialisation.SamplingStringsSerialiser"}

    # 时间序列类型
    TimeSeries = {"class": "cn.thutmose.abution.graph.type.times.serialisation.TimeSeriesSerialiser"}
    TimestampSet = {"class": "cn.thutmose.abution.graph.type.times.serialisation.TimestampSetSerialiser"}
    TimestampSetBounded = {"class": "cn.thutmose.abution.graph.type.times.serialisation.TimestampSetBoundedSerialiser"}

    # TopN类型
    TopNCounter = {"class": "cn.thutmose.abution.graph.type.topn.serialisation.TopNCounterByteSerialiser"}

    # BM25类型
    BM25Index = {"class": "cn.thutmose.abution.graph.type.bm25.serialisation.BM25IndexSerialiser"}

    # 向量索引类型
    VectorIndex = {"class": "cn.thutmose.abution.graph.type.vector.serialisation.VectorIndexSerialiser"}

    # Avro类型
    Avro = {"class": "cn.thutmose.abution.graph.serialisation.impl.AvroSerialiser"}

    # BigDecimal类型
    Bigdecimal = {"class": "cn.thutmose.abution.graph.serialisation.impl.BigdecimalSerialiser"}
