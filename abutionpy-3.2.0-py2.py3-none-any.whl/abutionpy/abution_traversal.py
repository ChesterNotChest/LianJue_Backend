from typing import List, Union, Any, Tuple, Optional, Dict
from abutionpy import abution
from abutionpy import abution_predicates as p
from abutionpy.abution_operations import *

class Graph:
    def __init__(self, connector: Any, graph_id: str):
        self.connector = connector
        self.graph_id = graph_id
        self.operations = []
        self.headers = {
            "Content-Type": "application/json",
            "abution.graphId": self.graph_id
        }
        self._current_op = None

    def add_knowledge(self, input: List[Knowledge], validate: bool = True, skip_invalid_knowledge: bool = False):
        add_knowledge = abution.AddKnowledge(input=input, validate=validate,
                                             skip_invalid_knowledge=skip_invalid_knowledge)
        self.connector.execute_operation(add_knowledge, self.headers)

    def delete_knowledge(self, input: List[Knowledge], match_properties: bool = True, deleted_compact: bool = False):
        add_knowledge = abution.DeleteKnowledge(input=input, match_properties=match_properties,
                                             deleted_compact=deleted_compact)
        self.connector.execute_operation(add_knowledge, self.headers)

    def get_schema(self):
        self.connector.execute_operation(abution.GetSchema(), self.headers)

    def V(self, *vertex_ids: Union[str, List[str]]) -> 'VertexOperation':
        flattened_ids = []
        for item in vertex_ids:
            if isinstance(item, list):
                flattened_ids.extend(item)
            else:
                flattened_ids.append(item)
        op = VertexOperation(self, tuple(flattened_ids))
        self._current_op = op
        return op

    def E(self, *edge_ids: Union[str, List[str]]) -> 'EdgeOperation':
        flattened_ids = []
        for item in edge_ids:
            if isinstance(item, list):
                flattened_ids.extend(item)
            else:
                flattened_ids.append(item)
        op = EdgeOperation(self, tuple(flattened_ids))
        self._current_op = op
        return op

    def K(self, *element_ids: Union[str, List[str]]) -> 'KnowledgeOperation':
        flattened_ids = []
        for item in element_ids:
            if isinstance(item, list):
                flattened_ids.extend(item)
            else:
                flattened_ids.append(item)
        op = KnowledgeOperation(self, tuple(flattened_ids))
        self._current_op = op
        return op

    def _add_operation(self, op: 'BaseOperation'):
        # print("_add_op:")
        # print(op.to_operation())

        # 如果当前操作存在且与新操作不同
        if self._current_op and self._current_op != op:
            # 将当前操作添加到操作列表
            self.operations.append(self._current_op)
            # 更新当前操作为新操作
            self._current_op = op
        else:
            # 如果没有当前操作或操作相同，直接更新当前操作
            self._current_op = op
        return op

    def exec(self):
        # 确保最后一个操作被添加
        if self._current_op:
            self.operations.append(self._current_op)

        operation_objects = [op.to_operation() for op in self.operations]
        # print("operation_objects:")
        # print(operation_objects)
        result = self.connector.execute_operations(operation_objects, self.headers)

        self.operations = []
        self._current_op = None
        return result


class BaseOperation:
    def __init__(self, graph: Graph, ids: Tuple[str]):
        self.graph = graph
        self.ids = ids
        self.view = None
        self.in_out_type = None
        self.directed_type = None
        self._current_labels = []
        self._current_group_properties = None
        self._has_method_called = False
        self._last_transform_context = None  # 记录最后一次transform的context
        self.element_type = None  # 'vertex' 或 'edge'

    def _mark_method_called(self):
        self._has_method_called = True
        # if self.graph._current_op == self:
        #     self.graph._current_op = self

    def _ensure_view(self):
        if not self.view:
            self.view = abution.View()

    def label(self, *labels: str) -> 'BaseOperation':
        self._ensure_view()
        self._current_labels = list(labels)

        # 无标签输入的情况
        if not labels:
            if self.element_type == 'vertex':
                self.view.all_entities = True
            elif self.element_type == 'edge':
                self.view.all_edges = True
            self._mark_method_called()
            return self

        # 有标签输入的情况
        for label in labels:
            if label:  # 确保不是空字符串
                kd = abution.KnowledgeDefinition(label=label)
                if self.element_type == 'vertex':
                    if not self.view.entities:
                        self.view.entities = []
                    self.view.entities.append(kd)
                elif self.element_type == 'edge':
                    if not self.view.edges:
                        self.view.edges = []
                    self.view.edges.append(kd)

        self._mark_method_called()
        return self

    def has(self, properties: Union[str, List[str]], predicate: Optional[abution.Predicate] = None) -> 'BaseOperation':
        self._ensure_view()

        # 统一处理 properties，确保最终是 List[str]
        if isinstance(properties, str):
            properties = [properties]  # 单个字符串转为列表
        elif not isinstance(properties, list):
            raise TypeError(f"Expected str or List[str], got {type(properties)}")

        context = abution.PredicateContext(
            selection=properties,  # 已经是 List[str]
            predicate=predicate
        )

        # 处理分组后过滤
        if self._current_group_properties:
            self._add_context_to_label_group(context, "post_agg_filter_functions")
            self._current_group_properties = None
        else:
            # 处理普通过滤
            self._add_context_to_label_group(context, "pre_agg_filter_functions")

        self._mark_method_called()
        return self

    def groupBy(self, *properties: str) -> 'BaseOperation':
        self._current_group_properties = properties
        self._mark_method_called()
        return self

    def transform(
            self,
            properties: Union[str, List[str]],  # 支持 str 或 List[str]
            function: Optional[abution.Function] = None,
    ) -> 'BaseOperation':  # 移除了alias参数
        self._ensure_view()

        # 统一处理 properties（确保是 List[str]）
        if isinstance(properties, str):
            properties = [properties]
        elif not isinstance(properties, list):
            raise TypeError(f"properties must be str or List[str], got {type(properties)}")

        context = abution.FunctionContext(
            selection=properties,  # List[str]
            function=function,
            projection=None  # 先不设置别名，等alias方法设置
        )

        # 保存最后一次transform的context
        self._last_transform_context = context

        self._add_context_to_label_group(context, "transform_functions")
        self._mark_method_called()
        return self

    def alias(self, name: str, data_type: str) -> 'BaseOperation':
        """新增alias方法，用于设置临时属性的别名和类型"""
        self._ensure_view()

        if not self._last_transform_context:
            raise RuntimeError("alias must be called immediately after a transform")

        # 设置最后一次transform的projection（别名）
        self._last_transform_context.projection = [name]

        # 添加临时属性到当前标签组
        self._add_transient_property(name, data_type)

        # 重置记录
        self._last_transform_context = None
        self._mark_method_called()
        return self

    def _add_transient_property(self, property_name: str, data_type: str):
        """添加临时属性到当前标签组（使用字典格式）"""
        # 无标签时的全局定义
        if not self._current_labels:
            if self.element_type == 'vertex':
                if not self.view.global_entities:
                    self.view.global_entities = [abution.GlobalKnowledgeDefinition()]
                target = self.view.global_entities[0]
            elif self.element_type == 'edge':
                if not self.view.global_edges:
                    self.view.global_edges = [abution.GlobalKnowledgeDefinition()]
                target = self.view.global_edges[0]
            elif isinstance(self, KnowledgeOperation) and self.view.global_knowledges:
                target = self.view.global_knowledges[0]
            else:
                return

            # 使用字典格式存储临时属性
            if not target.transient_properties:
                target.transient_properties = {}
            target.transient_properties[property_name] = data_type
            return

        # 有标签时的定义
        for label in self._current_labels:
            if self.element_type == 'vertex' and self.view.entities:
                for kd in self.view.entities:
                    if kd.label == label:
                        if not kd.transient_properties:
                            kd.transient_properties = {}
                        kd.transient_properties[property_name] = data_type
            elif self.element_type == 'edge' and self.view.edges:
                for kd in self.view.edges:
                    if kd.label == label:
                        if not kd.transient_properties:
                            kd.transient_properties = {}
                        kd.transient_properties[property_name] = data_type
            elif isinstance(self, KnowledgeOperation):
                if self.view.entities:
                    for kd in self.view.entities:
                        if kd.label == label:
                            if not kd.transient_properties:
                                kd.transient_properties = {}
                            kd.transient_properties[property_name] = data_type
                if self.view.edges:
                    for kd in self.view.edges:
                        if kd.label == label:
                            if not kd.transient_properties:
                                kd.transient_properties = {}
                            kd.transient_properties[property_name] = data_type

    def _add_context_to_label_group(self, context, field_name):
        # 无标签时的全局过滤
        if not self._current_labels:
            gkd = abution.GlobalKnowledgeDefinition()
            if self.element_type == 'vertex':
                if not self.view.global_entities:
                    self.view.global_entities = []
                self.view.global_entities.append(gkd)
                target = gkd
            elif self.element_type == 'edge':
                if not self.view.global_edges:
                    self.view.global_edges = []
                self.view.global_edges.append(gkd)
                target = gkd
            else:
                return
            if not getattr(target, field_name):
                setattr(target, field_name, [])
            getattr(target, field_name).append(context)
            return

        # 有标签时的过滤
        for label in self._current_labels:
            if label:  # 确保不是空字符串
                if self.element_type == 'vertex' and self.view.entities:
                    for kd in self.view.entities:
                        if kd.label == label:
                            if not getattr(kd, field_name):
                                setattr(kd, field_name, [])
                            getattr(kd, field_name).append(context)
                elif self.element_type == 'edge' and self.view.edges:
                    for kd in self.view.edges:
                        if kd.label == label:
                            if not getattr(kd, field_name):
                                setattr(kd, field_name, [])
                            getattr(kd, field_name).append(context)

    def selectProps(self, *properties: str) -> 'BaseOperation':
        self._ensure_view()
        # 无标签时的属性选择
        if not self._current_labels:
            if self.element_type == 'vertex':
                if not self.view.global_entities:
                    self.view.global_entities = [abution.GlobalKnowledgeDefinition()]
                self.view.global_entities[0].properties = list(properties)
            elif self.element_type == 'edge':
                if not self.view.global_edges:
                    self.view.global_edges = [abution.GlobalKnowledgeDefinition()]
                self.view.global_edges[0].properties = list(properties)
        # 有标签时的属性选择
        else:
            for label in self._current_labels:
                if label:  # 确保不是空字符串
                    if self.element_type == 'vertex' and self.view.entities:
                        for kd in self.view.entities:
                            if kd.label == label:
                                kd.properties = list(properties)
                    elif self.element_type == 'edge' and self.view.edges:
                        for kd in self.view.edges:
                            if kd.label == label:
                                kd.properties = list(properties)
        self._mark_method_called()
        return self

    def excludeProps(self, *properties: str) -> 'BaseOperation':
        self._ensure_view()
        # 无标签时的属性排除
        if not self._current_labels:
            if self.element_type == 'vertex':
                if not self.view.global_entities:
                    self.view.global_entities = [abution.GlobalKnowledgeDefinition()]
                self.view.global_entities[0].exclude_properties = list(properties)
            elif self.element_type == 'edge':
                if not self.view.global_edges:
                    self.view.global_edges = [abution.GlobalKnowledgeDefinition()]
                self.view.global_edges[0].exclude_properties = list(properties)
        # 有标签时的属性排除
        else:
            for label in self._current_labels:
                if label:  # 确保不是空字符串
                    if self.element_type == 'vertex' and self.view.entities:
                        for kd in self.view.entities:
                            if kd.label == label:
                                kd.exclude_properties = list(properties)
                    elif self.element_type == 'edge' and self.view.edges:
                        for kd in self.view.edges:
                            if kd.label == label:
                                kd.exclude_properties = list(properties)
        self._mark_method_called()
        return self

    def dirIsOut(self) -> 'BaseOperation':
        self.in_out_type = abution.InOutType.OUT
        self._mark_method_called()
        return self

    def dirIsIn(self) -> 'BaseOperation':
        self.in_out_type = abution.InOutType.IN
        self._mark_method_called()
        return self

    def dirIsBoth(self) -> 'BaseOperation':
        self.in_out_type = abution.InOutType.EITHER
        self._mark_method_called()
        return self

    def isDirected(self) -> 'BaseOperation':
        self.directed_type = abution.DirectedType.DIRECTED
        self._mark_method_called()
        return self

    def unDirected(self) -> 'BaseOperation':
        self.directed_type = abution.DirectedType.UNDIRECTED
        self._mark_method_called()
        return self

    def ToList(self) -> 'BaseOperation':
        op = ToListOperation(self.graph)
        return self.graph._add_operation(op)

    def ToSet(self) -> 'BaseOperation':
        op = ToSetOperation(self.graph)
        return self.graph._add_operation(op)

    def V(self) -> 'BaseOperation':
        self.graph._add_operation(ToVerticesOperation(self.graph).hitSelectEqual())
        self.graph._add_operation(ToEntityIdsOperation(self.graph))
        op = VOperation(self.graph)
        return self.graph._add_operation(op)

    def V_input(self, *vertex_ids: Union[str, List[str]]) -> 'BaseOperation':
        flattened_ids = []
        for item in vertex_ids:
            if isinstance(item, list):
                flattened_ids.extend(item)
            else:
                flattened_ids.append(item)
        op = VertexOperation(self.graph, tuple(flattened_ids))
        return self.graph._add_operation(op)

    def E(self) -> 'BaseOperation':
        self.graph._add_operation(ToVerticesOperation(self.graph).hitSelectEqual())
        self.graph._add_operation(ToEntityIdsOperation(self.graph))
        op = EOperation(self.graph)
        return self.graph._add_operation(op)

    def E_input(self, *edge_ids: Union[str, List[str]]) -> 'EdgeOperation':
        flattened_ids = []
        for item in edge_ids:
            if isinstance(item, list):
                flattened_ids.extend(item)
            else:
                flattened_ids.append(item)
        op = EdgeOperation(self.graph, tuple(flattened_ids))
        return op

    def Out(self) -> 'BaseOperation':
        self.graph._add_operation(ToVerticesOperation(self.graph).hitSelectEqual())
        self.graph._add_operation(ToEntityIdsOperation(self.graph))
        op = OutOperation(self.graph)
        return self.graph._add_operation(op)

    def In(self) -> 'BaseOperation':
        self.graph._add_operation(ToVerticesOperation(self.graph).hitSelectEqual())
        self.graph._add_operation(ToEntityIdsOperation(self.graph))
        op = InOperation(self.graph)
        return self.graph._add_operation(op)

    def Both(self) -> 'BaseOperation':
        self.graph._add_operation(ToVerticesOperation(self.graph).hitSelectEqual())
        self.graph._add_operation(ToEntityIdsOperation(self.graph))
        op = BothOperation(self.graph)
        return self.graph._add_operation(op)

    def OutE(self) -> 'BaseOperation':
        self.graph._add_operation(ToVerticesOperation(self.graph).hitSelectEqual())
        self.graph._add_operation(ToEntityIdsOperation(self.graph))
        self.graph._add_operation(OutOperation(self.graph))
        op = OutEOperation(self.graph)
        return self.graph._add_operation(op)

    def InE(self) -> 'BaseOperation':
        self.graph._add_operation(ToVerticesOperation(self.graph).hitSelectEqual())
        self.graph._add_operation(ToEntityIdsOperation(self.graph))
        self.graph._add_operation(InOperation(self.graph))
        op = InEOperation(self.graph)
        return self.graph._add_operation(op)

    def BothE(self) -> 'BaseOperation':
        self.graph._add_operation(ToVerticesOperation(self.graph).hitSelectEqual())
        self.graph._add_operation(ToEntityIdsOperation(self.graph))
        self.graph._add_operation(BothOperation(self.graph))
        op = BothEOperation(self.graph)
        return self.graph._add_operation(op)

    def OutV(self) -> 'BaseOperation':
        self.graph._add_operation(ToVerticesOperation(self.graph).hitSelectEqual())
        self.graph._add_operation(ToEntityIdsOperation(self.graph))
        self.graph._add_operation(OutOperation(self.graph))
        op = OutVOperation(self.graph)
        return self.graph._add_operation(op)

    def InV(self) -> 'BaseOperation':
        self.graph._add_operation(ToVerticesOperation(self.graph).hitSelectEqual())
        self.graph._add_operation(ToEntityIdsOperation(self.graph))
        self.graph._add_operation(InOperation(self.graph))
        op = InVOperation(self.graph)
        return self.graph._add_operation(op)

    def BothV(self) -> 'BaseOperation':
        self.graph._add_operation(ToVerticesOperation(self.graph).hitSelectEqual())
        self.graph._add_operation(ToEntityIdsOperation(self.graph))
        self.graph._add_operation(BothOperation(self.graph))
        op = BothVOperation(self.graph)
        return self.graph._add_operation(op)

    def WithinK(self) -> 'BaseOperation':
        op = WithinKOperation(self.graph)
        return self.graph._add_operation(op)

    def WithinE(self) -> 'BaseOperation':
        op = WithinEOperation(self.graph)
        return self.graph._add_operation(op)

    def BetweenK(self) -> 'BaseOperation':
        op = BetweenKOperation(self.graph)
        return self.graph._add_operation(op)

    def BetweenE(self) -> 'BaseOperation':
        op = BetweenEOperation(self.graph)
        return self.graph._add_operation(op)

    def Path(self) -> 'BaseOperation':
        op = PathOperation(self.graph)
        return self.graph._add_operation(op)

    def SimplePath(self) -> 'BaseOperation':
        op = SimplePathOperation(self.graph)
        return self.graph._add_operation(op)

    def CyclicPath(self) -> 'BaseOperation':
        op = CyclicPathOperation(self.graph)
        return self.graph._add_operation(op)

    def While(self) -> 'BaseOperation':
        op = WhileOperation(self.graph)
        return self.graph._add_operation(op)

    def Store(self, key: str) -> 'BaseOperation':
        op = StoreOperation(self.graph, key)
        return self.graph._add_operation(op)

    def Select(self, key: str) -> 'BaseOperation':
        self.graph._add_operation(RestartOperation(self.graph))
        op = SelectOperation(self.graph, key)
        return self.graph._add_operation(op)

    def Selects(self, key: list[str]) -> 'BaseOperation':
        self.graph._add_operation(RestartOperation(self.graph))
        op = SelectsOperation(self.graph, key)
        return self.graph._add_operation(op)

    def ToVertices(self) -> 'BaseOperation':
        op = ToVerticesOperation(self.graph)
        return self.graph._add_operation(op)

    def ToEntityIds(self) -> 'BaseOperation':
        op = ToEntityIdsOperation(self.graph)
        return self.graph._add_operation(op)

    def ToKnowIds(self) -> 'BaseOperation':
        op = ToKnowIdsOperation(self.graph)
        return self.graph._add_operation(op)

    def Count(self) -> 'BaseOperation':
        op = CountOperation(self.graph)
        return self.graph._add_operation(op)

    def Limit(self, limit: int) -> 'BaseOperation':
        op = LimitOperation(self.graph, limit)
        return self.graph._add_operation(op)

    def Restart(self) -> 'BaseOperation':
        op = RestartOperation(self.graph)
        return self.graph._add_operation(op)

    def Map(self, funcs: list[abution.Function]) -> 'BaseOperation':
        op = MapOperation(self.graph, funcs)
        return self.graph._add_operation(op)

    def Reduce(self, agg_func: abution.BinaryOperator) -> 'BaseOperation':
        op = ReduceOperation(self.graph, agg_func)
        return self.graph._add_operation(op)

    def If(self, condition: abution.Predicate) -> 'BaseOperation':
        op = IfOperation(self.graph, condition)
        return self.graph._add_operation(op)

    def ForEach(self) -> 'BaseOperation':
        op = ForEachOperation(self.graph)
        return self.graph._add_operation(op)

    def Join(self) -> 'BaseOperation':
        op = JoinOperation(self.graph)
        return self.graph._add_operation(op)

    def SetVariable(self, key: str) -> 'BaseOperation':
        op = SetVariableOperation(self.graph, key)
        return self.graph._add_operation(op)

    def exec(self, auths:list[str]=None):
        if auths and len(auths) > 0:
            self.graph.headers["Graph-DataAuths"] = "-".join(auths)
        return self.graph.exec()

    def get_operations(self):
        # 确保最后一个操作被添加
        if self.graph._current_op:
            self.graph.operations.append(self.graph._current_op)
        operation_objects = [op.to_operation() for op in self.graph.operations]

        self.graph.operations = []
        self.graph._current_op = None
        return operation_objects

    def to_operation(self) -> abution.Operation:
        raise NotImplementedError()


class VertexOperation(BaseOperation):
    def __init__(self, graph: Graph, ids: Tuple[str]):
        super().__init__(graph, ids)
        self.element_type = 'vertex'
    def to_operation(self) -> abution.Operation:
        if self.ids:
            return abution.GetEntity(
                input=list(self.ids),
                view=self.view
            )
        else:
            return abution.ScanEntity(view=self.view)


class EdgeOperation(BaseOperation):
    def __init__(self, graph: Graph, ids: Tuple[str]):
        super().__init__(graph, ids)
        self.element_type = 'edge'
    def to_operation(self) -> abution.Operation:
        print(self.view)
        if self.ids:
            return abution.GetEdge(
                input=list(self.ids),
                view=self.view,
                in_out_type=self.in_out_type
            )
        else:
            return abution.ScanKnowledge(
                view=self.view
                # in_out_type=self.in_out_type
            )


class KnowledgeOperation(BaseOperation):
    def labelV(self, *labels: str) -> 'KnowledgeOperation':
        self._ensure_view()
        self._current_labels = list(labels)

        # 无标签输入
        if not labels:
            self.view.all_entities = True
            self._mark_method_called()
            return self

        # 有标签输入
        for label in labels:
            if label:  # 确保不是空字符串
                kd = abution.KnowledgeDefinition(label=label)
                if not self.view.entities:
                    self.view.entities = []
                self.view.entities.append(kd)

        self._mark_method_called()
        return self

    def labelE(self, *labels: str) -> 'KnowledgeOperation':
        self._ensure_view()
        self._current_labels = list(labels)

        # 无标签输入
        if not labels:
            self.view.all_edges = True
            self._mark_method_called()
            return self

        # 有标签输入
        for label in labels:
            if label:  # 确保不是空字符串
                kd = abution.KnowledgeDefinition(label=label)
                if not self.view.edges:
                    self.view.edges = []
                self.view.edges.append(kd)

        self._mark_method_called()
        return self

    def glob(self, *labels: str) -> 'KnowledgeOperation':
        self._ensure_view()
        self.view.global_knowledges = [
            abution.GlobalKnowledgeDefinition(labels=list(labels))
        ]
        self._mark_method_called()
        return self

    def to_operation(self) -> abution.Operation:
        if self.ids:
            return abution.GetKnowledge(
                input=list(self.ids),
                view=self.view,
                directed_type=self.directed_type
            )
        else:
            return abution.ScanKnowledge(
                view=self.view,
                directed_type=self.directed_type
            )


class VOperation(BaseOperation):
    def __init__(self, graph: Graph):
        super().__init__(graph, ())
        self.element_type = 'vertex'

    def to_operation(self) -> abution.Operation:
        return abution.GetEntity(
            view=self.view
        )


class EOperation(BaseOperation):
    def __init__(self, graph: Graph):
        super().__init__(graph, ())
        self.element_type = 'edge'

    def to_operation(self) -> abution.Operation:
        return abution.GetEdge(
            view=self.view,
            in_out_type=self.in_out_type
        )


class OutOperation(BaseOperation):
    def __init__(self, graph: Graph):
        super().__init__(graph, ())
        self.in_out_type = abution.InOutType.OUT
        self.element_type = 'edge'

    def to_operation(self) -> abution.Operation:
        return abution.GetNeighborIds(
            view=self.view,
            in_out_type=self.in_out_type
        )


class InOperation(BaseOperation):
    def __init__(self, graph: Graph):
        super().__init__(graph, ())
        self.in_out_type = abution.InOutType.IN
        self.element_type = 'edge'

    def to_operation(self) -> abution.Operation:
        return abution.GetNeighborIds(
            view=self.view,
            in_out_type=self.in_out_type
        )


class BothOperation(BaseOperation):
    def __init__(self, graph: Graph):
        super().__init__(graph, ())
        self.in_out_type = abution.InOutType.EITHER
        self.element_type = 'edge'

    def to_operation(self) -> abution.Operation:
        return abution.GetNeighborIds(
            view=self.view,
            in_out_type=self.in_out_type
        )


class OutEOperation(BaseOperation):
    def __init__(self, graph: Graph):
        super().__init__(graph, ())
        self.in_out_type = abution.InOutType.OUT
        self.element_type = 'edge'

    def to_operation(self) -> abution.Operation:
        return abution.GetEdge(
            view=self.view,
            in_out_type=self.in_out_type
        )


class InEOperation(BaseOperation):
    def __init__(self, graph: Graph):
        super().__init__(graph, ())
        self.in_out_type = abution.InOutType.IN
        self.element_type = 'edge'

    def to_operation(self) -> abution.Operation:
        return abution.GetEdge(
            view=self.view,
            in_out_type=self.in_out_type
        )


class BothEOperation(BaseOperation):
    def __init__(self, graph: Graph):
        super().__init__(graph, ())
        self.in_out_type = abution.InOutType.EITHER
        self.element_type = 'edge'

    def to_operation(self) -> abution.Operation:
        return abution.GetEdge(
            view=self.view,
            in_out_type=self.in_out_type
        )


class OutVOperation(BaseOperation):
    def __init__(self, graph: Graph):
        super().__init__(graph, ())
        self.in_out_type = abution.InOutType.OUT
        self.element_type = 'vertex'

    def to_operation(self) -> abution.Operation:
        return abution.GetEntity(
            view=self.view,
            in_out_type=self.in_out_type
        )


class InVOperation(BaseOperation):
    def __init__(self, graph: Graph):
        super().__init__(graph, ())
        self.in_out_type = abution.InOutType.IN
        self.element_type = 'vertex'

    def to_operation(self) -> abution.Operation:
        return abution.GetEntity(
            view=self.view,
            in_out_type=self.in_out_type
        )


class BothVOperation(BaseOperation):
    def __init__(self, graph: Graph):
        super().__init__(graph, ())
        self.in_out_type = abution.InOutType.EITHER
        self.element_type = 'vertex'

    def to_operation(self) -> abution.Operation:
        return abution.GetEntity(
            view=self.view,
            in_out_type=self.in_out_type
        )


class WithinKOperation(KnowledgeOperation):
    def __init__(self, graph: Graph):
        super().__init__(graph, ())

    def to_operation(self) -> abution.Operation:
        return abution.GetKnowledgeWithinSet(
            input=list(self.ids) if self.ids else None,
            view=self.view,
            directed_type=self.directed_type
        )


class WithinEOperation(BaseOperation):
    def __init__(self, graph: Graph):
        super().__init__(graph, ())

    def to_operation(self) -> abution.Operation:
        return abution.GetKnowledgeWithinSet(
            input=list(self.ids) if self.ids else None,
            view=self.view,
            directed_type=self.directed_type
        )


class BetweenKOperation(KnowledgeOperation):
    def __init__(self, graph: Graph):
        super().__init__(graph, ())

    def to_operation(self) -> abution.Operation:
        return abution.GetKnowledgeBetweenSets(
            input=list(self.ids) if self.ids else None,
            view=self.view,
            directed_type=self.directed_type
        )


class BetweenEOperation(BaseOperation):
    def __init__(self, graph: Graph):
        super().__init__(graph, ())

    def to_operation(self) -> abution.Operation:
        return abution.GetKnowledgeBetweenSets(
            input=list(self.ids) if self.ids else None,
            view=self.view,
            directed_type=self.directed_type
        )


class PathOperation(BaseOperation):
    def __init__(self, graph: Graph):
        super().__init__(graph, ())

    def to_operation(self) -> abution.Operation:
        return abution.GetPath()


class SimplePathOperation(BaseOperation):
    def __init__(self, graph: Graph):
        super().__init__(graph, ())

    def to_operation(self) -> abution.Operation:
        return abution.GetSimplePath()


class CyclicPathOperation(BaseOperation):
    def __init__(self, graph: Graph):
        super().__init__(graph, ())

    def to_operation(self) -> abution.Operation:
        return abution.GetCyclicPath()


class WhileOperation(BaseOperation):
    def __init__(self, graph: Graph):
        super().__init__(graph, ())

    def to_operation(self) -> abution.Operation:
        return abution.While()


class StoreOperation(BaseOperation):
    def __init__(self, graph: Graph, key: str):
        super().__init__(graph, ())
        self.key = key

    def to_operation(self) -> abution.Operation:
        return abution.ExportToSet(key=self.key)

class SelectOperation(BaseOperation):
    def __init__(self, graph: Graph, key: str):
        super().__init__(graph, ())
        self.key = key

    def to_operation(self) -> abution.Operation:
        return abution.GetSetExport(key=self.key)

class SelectsOperation(BaseOperation):
    def __init__(self, graph: Graph, keys: list[str]):
        super().__init__(graph, ())
        self.keys = keys

    def to_operation(self) -> abution.Operation:
        get_exports = [abution.GetSetExport(key=key) for key in self.keys]
        return abution.GetExportsToMap(get_exports)


class ToVerticesOperation(BaseOperation):
    def __init__(self, graph: Graph):
        super().__init__(graph, ())
        self.edge_extract_mode = None
        self.use_matched_vertex = None

    def extSource(self) -> 'ToVerticesOperation':
        self.edge_extract_mode = abution.EdgeVertices.SOURCE
        self._mark_method_called()
        return self

    def extTarget(self) -> 'ToVerticesOperation':
        self.edge_extract_mode = abution.EdgeVertices.TARGET
        self._mark_method_called()
        return self

    def extBothE(self) -> 'ToVerticesOperation':
        self.edge_extract_mode = abution.EdgeVertices.BOTH
        self._mark_method_called()
        return self

    def extNoneE(self) -> 'ToVerticesOperation':
        self.edge_extract_mode = abution.EdgeVertices.NONE
        self._mark_method_called()
        return self

    def hitSelectIgnore(self) -> 'ToVerticesOperation':
        self.use_matched_vertex = abution.UseMatchedVertex.IGNORE
        self._mark_method_called()
        return self

    def hitSelectEqual(self) -> 'ToVerticesOperation':
        self.use_matched_vertex = abution.UseMatchedVertex.EQUAL
        self._mark_method_called()
        return self

    def hitSelectOpposite(self) -> 'ToVerticesOperation':
        self.use_matched_vertex = abution.UseMatchedVertex.OPPOSITE
        self._mark_method_called()
        return self

    def to_operation(self) -> abution.Operation:
        return abution.ToVertices(
            use_matched_vertex=self.use_matched_vertex,
            edge_vertices=self.edge_extract_mode
        )


class ToEntityIdsOperation(BaseOperation):
    def __init__(self, graph: Graph):
        super().__init__(graph, ())

    def to_operation(self) -> abution.Operation:
        return abution.ToEntityIds()


class ToKnowIdsOperation(BaseOperation):
    def __init__(self, graph: Graph):
        super().__init__(graph, ())

    def to_operation(self) -> abution.Operation:
        return abution.ToKnowledgeId()


class ToListOperation(BaseOperation):
    def __init__(self, graph: Graph):
        super().__init__(graph, ())

    def to_operation(self) -> abution.Operation:
        return abution.ToList()


class ToSetOperation(BaseOperation):
    def __init__(self, graph: Graph):
        super().__init__(graph, ())

    def to_operation(self) -> abution.Operation:
        return abution.ToSet()


class ToJsonOperation(BaseOperation):
    def __init__(self, graph: Graph):
        super().__init__(graph, ())

    def to_operation(self) -> abution.Operation:
        return abution.ToJson()


class CountOperation(BaseOperation):
    def __init__(self, graph: Graph):
        super().__init__(graph, ())

    def to_operation(self) -> abution.Operation:
        return abution.Count()


class LimitOperation(BaseOperation):
    def __init__(self, graph: Graph, limit: int):
        super().__init__(graph, ())
        self.limit = limit

    def to_operation(self) -> abution.Operation:
        return abution.Limit(num=self.limit)


class RestartOperation(BaseOperation):
    def __init__(self, graph: Graph):
        super().__init__(graph, ())

    def to_operation(self) -> abution.Operation:
        return abution.RestartChain()


class MapOperation(BaseOperation):
    def __init__(self, graph: Graph, funcs: list[abution.Function]):
        super().__init__(graph, ())
        self.funcs = funcs

    def to_operation(self) -> abution.Operation:
        return abution.Map(functions=self.funcs)


class ReduceOperation(BaseOperation):
    def __init__(self, graph: Graph, agg_func: abution.BinaryOperator):
        super().__init__(graph, ())
        self.agg_func = agg_func

    def to_operation(self) -> abution.Operation:
        return abution.Reduce(agg_func=self.agg_func)


class IfOperation(BaseOperation):
    def __init__(self, graph: Graph, condition: abution.Predicate):
        super().__init__(graph, ())
        self.condition = condition

    def to_operation(self) -> abution.Operation:
        return abution.If(condition=self.condition)


class ForEachOperation(BaseOperation):
    def __init__(self, graph: Graph):
        super().__init__(graph, ())

    def to_operation(self) -> abution.Operation:
        return abution.ForEach()


class JoinOperation(BaseOperation):
    def __init__(self, graph: Graph):
        super().__init__(graph, ())

    def to_operation(self) -> abution.Operation:
        return abution.Join()


class SetVariableOperation(BaseOperation):
    def __init__(self, graph: Graph, key: str):
        super().__init__(graph, ())
        self.key = key

    def to_operation(self) -> abution.Operation:
        return abution.SetVariable(key=self.key)