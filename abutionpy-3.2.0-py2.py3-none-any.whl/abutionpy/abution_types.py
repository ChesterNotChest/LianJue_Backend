#
# Copyright 2016-2024 Crown Copyright
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#


"""
This module contains Python copies of common Abution java types.
"""

from typing import Any, Dict, List, Optional, Set, Tuple
import logging
import re

from abutionpy.abution_core import KnowledgeKey, EntityKey, EdgeKey, Knowledge, JsonConverter, Function, BinaryOperator, Predicate
from abutionpy.abution_operations import Operation

logging.basicConfig(level=logging.WARNING)
logger = logging.getLogger(__name__)

anys = (
    "T", "Object", "Object[]", "?", "OBJ", "java.lang.Object", "I", "I_ITEM",
    "java.lang.Class", "cn.thutmose.abution.graph.access.predicate.AccessPredicate"
)
lists = "java.lang.Iterable", "java.util.List", "java.util.Collection"
dicts = "java.util.Map", "java.util.LinkedHashMap", "java.util.Properties", "cn.thutmose.abution.graph.store.schema.Schema"
strings = "java.lang.String", "char"
ints = "java.lang.Integer", "java.lang.Long", "int"

class Types:
    """属性类型常量"""
    String = "java.lang.String"
    Double = "java.lang.Double"
    Integer = "java.lang.Integer"
    Boolean = "java.lang.Boolean"
    CustomMap = "cn.thutmose.abution.graph.type.CustomMap"
    TreeSet = "java.util.TreeSet"
    TreeSetString = "java.util.TreeSet"
    DistinctCountHllp = "cn.thutmose.abution.graph.type.cardinality.DistinctCountHllp"

    # 基本类型
    Byte = "java.lang.Byte"
    Short = "java.lang.Short"
    Long = "java.lang.Long"
    Float = "java.lang.Float"
    Character = "java.lang.Character"
    BigDecimal = "java.math.BigDecimal"
    BigInteger = "java.math.BigInteger"

    # 时间类型
    Date = "java.util.Date"
    LocalDateTime = "java.time.LocalDateTime"
    Timestamp = "java.sql.Timestamp"

    # 集合类型
    List = "java.util.List"
    Set = "java.util.Set"
    Map = "java.util.Map"
    ArrayList = "java.util.ArrayList"
    HashMap = "java.util.HashMap"
    HashSet = "java.util.HashSet"

    # Bitmap类型
    RoaringBitmap = "cn.thutmose.abution.graph.type.bitmap.RoaringBitmap"
    Roaring64NavigableMap = "cn.thutmose.abution.graph.type.bitmap.Roaring64NavigableMap"

    # 基数统计类型
    DistinctCountHll = "cn.thutmose.abution.graph.type.cardinality.DistinctCountHll"
    DistinctCountPlus = "cn.thutmose.abution.graph.type.cardinality.DistinctCountPlus"
    DistinctCountThetas = "cn.thutmose.abution.graph.type.cardinality.DistinctCountThetas"

    # 频率类型
    FreqBooleans = "cn.thutmose.abution.graph.type.frequency.FreqBooleans"
    FreqDoubles = "cn.thutmose.abution.graph.type.frequency.FreqDoubles"
    FreqLongs = "cn.thutmose.abution.graph.type.frequency.FreqLongs"
    FreqMap = "cn.thutmose.abution.graph.type.frequency.FreqMap"
    FreqStrings = "cn.thutmose.abution.graph.type.frequency.FreqStrings"

    # 地理类型
    Geoshape = "cn.thutmose.abution.graph.type.geo.Geoshape"

    # 分位数类型
    QuantileDoubles = "cn.thutmose.abution.graph.type.quantile.QuantileDoubles"
    QuantileFloats = "cn.thutmose.abution.graph.type.quantile.QuantileFloats"
    QuantileStrings = "cn.thutmose.abution.graph.type.quantile.QuantileStrings"

    # 采样类型
    SamplingLongs = "cn.thutmose.abution.graph.type.sampling.SamplingLongs"
    SamplingStrings = "cn.thutmose.abution.graph.type.sampling.SamplingStrings"

    # 时间序列类型
    TimeSeries = "cn.thutmose.abution.graph.type.times.TimeSeries"
    TimestampSet = "cn.thutmose.abution.graph.type.times.TimestampSet"
    TimestampSetBounded = "cn.thutmose.abution.graph.type.times.TimestampSetBounded"

    # TopN类型
    TopNCounter = "cn.thutmose.abution.graph.type.topn.TopNCounter"

    # BM25类型
    BM25Index = "cn.thutmose.abution.graph.type.bm25.BM25Index"

    # 向量索引类型
    VectorIndex = "cn.thutmose.abution.graph.type.vector.VectorIndex"

    # 元组类型
    LongBigdecimalTuple = "cn.thutmose.abution.graph.type.tuple.LongBigdecimalTuple"
    LongIntegerTuple = "cn.thutmose.abution.graph.type.tuple.LongIntegerTuple"
    TypeSubTypeValue = "cn.thutmose.abution.graph.type.tuple.TypeSubTypeValue"
    TypeValue = "cn.thutmose.abution.graph.type.tuple.TypeValue"

    # 数组类型
    ByteArray = "byte[]"
    FloatArray = "[F"
    # FloatArray = "float[]"
    DoubleArray = "[D"
    IntArray = "int[]"
    LongArray = "[L"
    StringArray = "java.lang.String[]"

    # Avro类型
    Avro = "org.apache.avro.Schema"

    # 其他类型
    Null = "java.lang.Void"
    Bytes = "byte[]"


def parse_java_type_to_string(java_type: str, return_full_path: bool = True) -> str:
    """
    Parse a Java type into a Python type and return as a string.

    Args:
        java_type: String of a Java type
        return_full_path: Whether to return the full `abutionpy` path to a class i.e.
            `abutionpy.abution_core.Function`, or just the class i.e. `Function`

    Returns:
        String of Python type
    """

    python_type = parse_java_type(java_type)
    if isinstance(python_type, type):
        if python_type.__module__ == "builtins":
            return python_type.__name__
        type_name = f"{python_type.__module__}.{python_type.__name__}"
    else:
        type_name = str(python_type)

    if return_full_path is False and "abutionpy" in type_name:
        abutionpy_class = re.findall("abutionpy[\\w+ \\.]*", type_name)[0]
        # replace the full abutionpy path with just class name
        type_name = type_name.replace(abutionpy_class, abutionpy_class.split(".")[-1])

    return type_name


def parse_java_type(java_type: str) -> type:
    """
    Parse a Java type into a Python type object.

    Args:
        java_type: String of a Java type

    Returns:
        Python type
    """
    if "[]" in java_type:
        array_type = java_type.split("[]")[0]
        return List[parse_java_type(array_type)]
    if "<" in java_type:
        split = java_type.split("<")
        outter_type = split[0]
        inner_type = ">".join(split[1].split(">")[:-1])
        if outter_type in anys:
            return Any
        if inner_type in anys:
            return parse_java_type(outter_type)
        try:
            return parse_java_type(outter_type)[parse_java_type(inner_type)]
        except BaseException:
            if "java.util.function.BinaryOperator" in java_type:
                return BinaryOperator
            if "java.util.function.Function" in java_type:
                return Function
            if "java.util.function.Predicate" in java_type:
                return Predicate
            logger.warning(
                f"Unable to determine Python type for Java type {java_type}, using typing.Any")
            return Any
    if "," in java_type:
        split = java_type.split(",")
        first_type = split[0]
        remaining_types = ",".join(split[1:])
        return parse_java_type(first_type), parse_java_type(remaining_types)
    if java_type in anys:
        return Any
    if java_type in lists:
        return List
    if java_type in dicts:
        return Dict
    if java_type in strings:
        return str
    if java_type in ints:
        return int
    if java_type == "java.lang.Float":
        return float
    if java_type == "java.lang.Boolean":
        return bool
    if java_type == "java.util.Set":
        return Set
    if java_type == "cn.thutmose.abution.graph.commonutil.pair.Pair":
        return Tuple
    if java_type == "cn.thutmose.abution.graph.data.knowhow.id.KnowledgeKey":
        return KnowledgeKey
    if java_type == "cn.thutmose.abution.graph.data.knowhow.id.EntityKey":
        return EntityKey
    if java_type == "cn.thutmose.abution.graph.data.knowhow.id.EdgeKey":
        return EdgeKey
    if java_type == "cn.thutmose.abution.graph.data.knowhow.Knowledge":
        return Knowledge
    if java_type == "cn.thutmose.abution.graph.operation.Operation":
        return Operation

    if java_type in JsonConverter.CLASS_MAP:
        return JsonConverter.CLASS_MAP[java_type]
    return Any


def long(value: int) -> Dict[str, int]:
    """
    Convert integer value to an object that Abution can serialise into a Java Long type.

    Args:
        value: Integer value to convert

    Returns:
        Dictionary that can be serialised to a Java Long.
    """
    return {"java.lang.Long": value}


def float_(value: float) -> Dict[str, float]:
    """
    Convert float value to an object that Abution can serialise into a Java Float type.

    Args:
        value: Float value to convert

    Returns:
        Dictionary that can be serialised to a Java Float.
    """
    return {"java.lang.Float": value}

def float_array(values: List[float]) -> Dict[str, List[float]]:
    """
    Convert list of float values to an object that Abution can serialise into a Java Float[] type.

    Args:
        values: List of float values to convert

    Returns:
        Dictionary that can be serialised to a Java Float[].
    """
    return {"[F": values}


def double(value: float) -> Dict[str, float]:
    """
    Convert float value to an object that Abution can serialise into a Java Double type.

    Args:
        value: Float value to convert

    Returns:
        Dictionary that can be serialised to a Java Double.
    """
    return {"java.lang.Double": value}


def date(value: int) -> Dict[str, int]:
    """
    Convert integer value to an object that Abution can serialise into a Java Date type.

    Args:
        value: Integer value to convert

    Returns:
        Dictionary that can be serialised to a Java Date.
    """
    return {"java.util.Date": value}


def freq_map(map_value: Dict[Any, int]) -> Dict[str, Dict[Any, int]]:
    """
    Convert {k:v} dict to an object that Abution can serialise into a Abution FreqMap type.

    Args:
        value: Dictionary to convert

    Returns:
        Dictionary that can be serialised to a Abution FreqMap.
    """
    return {"cn.thutmose.abution.graph.type.frequency.FreqMap": map_value}


def tree_set(set: Set[Any]) -> Dict[str, List[Any]]:
    """
    Convert set to an object that Abution can serialise into a Java TreeSet type.

    Args:
        set: Set to convert

    Returns:
        Dictionary that can be serialised to a Java TreeSet.
    """
    return {"java.util.TreeSet": list(set)}
# def tree_set_(set: Set[Any]) -> Dict[str, Set[Any]]:
#     """
#     Convert set to an object that Abution can serialise into a Java TreeSet type.
#
#     Args:
#         set: Set to convert
#
#     Returns:
#         Dictionary that can be serialised to a Java TreeSet.
#     """
#     return {"java.util.TreeSet": set}


def type_value(
    type: Optional[Any] = None,
    value: Optional[Any] = None
) -> Dict[str, Dict[str, Any]]:
    """
    Convert a type and value to an object that Abution can serialise into a Abution TypeSubTypeValue type.

    Args:
        type: Populates `type` field in a Abution TypeSubTypeValue object
        value: Populates `value` field in a Abution TypeSubTypeValue object

    Returns:
        Dictionary that can be serialised to a Abution TypeSubTypeValue.
    """
    map = {}
    if type is not None:
        map["type"] = type
    if value is not None:
        map["value"] = value
    return {"TypeSubTypeValue": map}


def type_subtype_value(
    type: Optional[Any] = None,
    subType: Optional[Any] = None,
    value: Optional[Any] = None
) -> Dict[str, Dict[str, Any]]:
    """
    Convert a type, subType and value to an object that Abution can serialise into a Abution TypeSubTypeValue type.

    Args:
        type: Populates `type` field in a Abution TypeSubTypeValue object
        subType: Populates `subType` field in a Abution TypeSubTypeValue object
        value: Populates `value` field in a Abution TypeSubTypeValue object

    Returns:
        Dictionary that can be serialised to a Abution TypeSubTypeValue.
    """
    map = {}
    if type is not None:
        map["type"] = type
    if subType is not None:
        map["subType"] = subType
    if value is not None:
        map["value"] = value
    return {"TypeSubTypeValue": map}

def hyper_log_log_plus(
    offers: List[Any],
    p: int = 5,
    sp: int = 5,
    bytes: str = None
) -> dict[str, dict[str, int | str | list[Any]]] | dict[str, dict[str, int | list[Any]]]:
    """
    Convert a list of objects to an object that Abution can serialise into a HyperLogLogPlus Sketch.

    Args:
        offers: Objects to add to the Sketch
        p: Defines the accuracy and ultimately the size of Sketch.
        sp: Defines the error properties of the Sketch sparse mode.

    Returns:
        Dictionary that can be serialised to cn.thutmose.abution.graph.type.cardinality.DistinctCountHllp.
    """
    if bytes is not None:
        return {"cn.thutmose.abution.graph.type.cardinality.DistinctCountHllp":{"p":p,"sp":sp,"bytes":bytes,"offers":offers}}
    return {"cn.thutmose.abution.graph.type.cardinality.DistinctCountHllp":{"p":p,"sp":sp,"offers":offers}}

# def hyper_log_log_plus_old(
#     offers: List[Any],
#     p: int = 5,
#     sp: int = 5
# ) -> Dict[str, Dict[str, Dict[str, Any]]]:
#     """
#     Convert a list of objects to an object that Abution can serialise into a HyperLogLogPlus Sketch.
#
#     Args:
#         offers: Objects to add to the Sketch
#         p: Defines the accuracy and ultimately the size of Sketch.
#         sp: Defines the error properties of the Sketch sparse mode.
#
#     Returns:
#         Dictionary that can be serialised to a clearspring HyperLogLogPlus Sketch.
#     """
#     return {"com.clearspring.analytics.stream.cardinality.HyperLogLogPlus": {
#         "hyperLogLogPlus": {"p": p, "sp": sp, "offers": offers}}}


def hll_sketch(
    values: List[Any],
    log_k: int = 10
) -> Dict[str, Dict[str, Any]]:
    """
    Convert a list of objects to an object that Abution can serialise into a HyperLogLog Sketch.

    Args:
        values: Objects to add to the Sketch
        log_k: Defines the accuracy and ultimately the size of Sketch.

    Returns:
        Dictionary that can be serialised to a clearspring HyperLogLog Sketch.
    """
    return {
        "org.apache.datasketches.hll.HllSketch": {
            "logK": log_k,
            "values": values
        }
    }

def custom_map_str_float_array(map: Dict[str, list[float]]) -> dict[
    str, str | list[dict[str, dict[str, str | dict[str, list[float]]]]] | Any]:
    """
    Convert a map to an object that Abution can serialise into a Java Map.

    Args:
        map: Map to convert

    Returns:
        Dictionary that can be serialised to a Java Map.
    """
    jsonStorage = [{"cn.thutmose.abution.graph.commonutil.pair.Pair":{"first":key,"second":{"[F":value}}} for key, value in map.items()]
    # [{"cn.thutmose.abution.graph.commonutil.pair.Pair": {"first": "a", "second": {"[F": [1.0, 2.0, 3.0]}}}]

    return {
        "cn.thutmose.abution.graph.type.CustomMap": {
            "keySerialiser": {"class":"cn.thutmose.abution.graph.serialisation.impl.StringSerialiser"},
            "valueSerialiser": {"class":"cn.thutmose.abution.graph.serialisation.impl.FloatArraySerialiser"},
            "jsonStorage": jsonStorage
        }
    }
    # return {"class":"cn.thutmose.abution.graph.type.CustomMap","keySerialiser":{"class":"cn.thutmose.abution.graph.serialisation.impl.StringSerialiser"},"valueSerialiser":{"class":"cn.thutmose.abution.graph.serialisation.impl.FloatArraySerialiser"},"jsonStorage":[{"cn.thutmose.abution.graph.commonutil.pair.Pair":{"first":"a","second":{"[F":[1.0,2.0,3.0]}}}]}

def custom_map_str_list_str(map: Dict[str, list[str]]) -> dict[
    str, str | list[dict[str, dict[str, str | dict[str, list[str]]]]] | Any]:
    """
    Convert a map to an object that Abution can serialise into a Java Map<String, List<String>>.

    Args:
        map: Map to convert

    Returns:
        Dictionary that can be serialised to a Java Map.
    """
    jsonStorage = [
        {"cn.thutmose.abution.graph.commonutil.pair.Pair":
            {"first": key,
             "second": {"java.util.ArrayList": value}}
        }
        for key, value in map.items()
    ]

    return {
        "cn.thutmose.abution.graph.type.CustomMap": {
            "keySerialiser": {"class":"cn.thutmose.abution.graph.serialisation.impl.StringSerialiser"},
            "valueSerialiser": {"class": "cn.thutmose.abution.graph.serialisation.impl.ListSerialiser"},
            "jsonStorage": jsonStorage
        }
    }

def custom_map_str_str(map: Dict[str, str]) -> dict[
    str, str | list[dict[str, dict[str, str | dict[str, str]]]] | Any]:
    """
    Convert a map to an object that Abution can serialise into a Java Map<String, List<String>>.

    Args:
        map: Map to convert

    Returns:
        Dictionary that can be serialised to a Java Map.
    """
    jsonStorage = [
        {"cn.thutmose.abution.graph.commonutil.pair.Pair":
            {"first": key,
             "second": value}
        }
        for key, value in map.items()
    ]

    return {
        "cn.thutmose.abution.graph.type.CustomMap": {
            "keySerialiser": {"class":"cn.thutmose.abution.graph.serialisation.impl.StringSerialiser"},
            "valueSerialiser": {"class": "cn.thutmose.abution.graph.serialisation.impl.StringSerialiser"},
            "jsonStorage": jsonStorage
        }
    }


def bm25_index(doc_entities: Dict[str, Dict[str, int]], k1: float=1.5, b: float=0.75) -> Dict[str, Any]:
    """
    Convert parameters to an object that Abution can serialise into a BM25Entity.

    Args:
        k1: BM25 k1 parameter
        b: BM25 b parameter
        doc_entities: Documents with term frequencies

    Returns:
        Dictionary that can be serialised to a cn.thutmose.abution.graph.type.bm25.BM25Entity.
    """
    # Convert documents to the required format
    document_storage = {}
    for doc_id, terms in doc_entities.items():
        document_storage[doc_id] = terms

    return {
        "cn.thutmose.abution.graph.type.bm25.BM25Index":{
            "k1": k1,
            "b": b,
            "documents": document_storage
        }
    }

def vector_index(
        name_vector: Dict[str, List[float]],
        num_elements: int = None
) -> Dict[str, Any]:
    """
    Convert parameters to an object that Abution can serialise into a VectorIndex.

    Args:
        name_vector: Mapping of names to vector values
        num_elements: Number of elements in vectors

    Returns:
        Dictionary that can be serialised to a cn.thutmose.abution.graph.type.vector.VectorIndex.
    """
    # 获取向量维度数（取第一个向量的长度）
    if num_elements is None and name_vector:
        first_vector = next(iter(name_vector.values()))
        num_elements = len(first_vector)

    # Convert name_vector to the required format
    vector_storage = {}
    for name, vector in name_vector.items():
        vector_storage[name] = vector

    return {
        "cn.thutmose.abution.graph.type.vector.VectorIndex": {
            "numElements": num_elements,
            "nameVector": vector_storage
        }
    }

def quantile_doubles(
    values: list[float],
) -> Dict[str, Dict[str, Any]]:
    """
    Convert parameters to an object that Abution can serialise into a QuantileDoubles type.

    Args:
        minValue: Minimum value in the quantile
        maxValue: Maximum value in the quantile
        k: Configuration parameter for the quantile (default: 128)
        n: Sample count or weight (default: 1.0)
        retainedItems: Number of retained items (default: 1)
        storageBytes: Storage size in bytes (default: 64)

    Returns:
        Dictionary that can be serialised to a cn.thutmose.abution.graph.type.quantile.QuantileDoubles.
    """
    return {
        "cn.thutmose.abution.graph.type.quantile.QuantileDoubles": {
            "values": values
        }
    }

