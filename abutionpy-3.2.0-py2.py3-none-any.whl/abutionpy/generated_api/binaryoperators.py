#
# Copyright 2022-2025 Crown Copyright
#
# Licensed under the Apache License, Version 2.0 (the 'License');
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.thutmose.cn
#
# by AbutionGraph-3.x.x
#

"""
This module has been generated with fishbowl.
To make changes, either extend these classes or change fishbowl.
"""

import typing
from abutionpy.abution_core import AbstractBinaryOperator, BinaryOperator, Function


class RoaringBitmapAggregator(AbstractBinaryOperator):
    CLASS = "cn.thutmose.abution.graph.bitmap.function.aggregate.RoaringBitmapAggregator"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class ElementAggregator(AbstractBinaryOperator):
    CLASS = "cn.thutmose.abution.graph.data.knowhow.function.ElementAggregator"

    def __init__(
        self,
        operators: typing.Optional[typing.List[typing.Any]] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.operators = operators

    def to_json(self):
        function_json = super().to_json()
        if self.operators is not None:
            function_json["operators"] = self.operators
        return function_json


class DefaultResultAccumulator(AbstractBinaryOperator):
    CLASS = "cn.thutmose.abution.graph.federated.simple.merge.DefaultResultAccumulator"

    def __init__(
        self,
        schema: typing.Optional[typing.Dict] = None,
        aggregate_elements: typing.Optional[bool] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.schema = schema
        self.aggregate_elements = aggregate_elements

    def to_json(self):
        function_json = super().to_json()
        if self.schema is not None:
            function_json["schema"] = self.schema
        if self.aggregate_elements is not None:
            function_json["aggregateElements"] = self.aggregate_elements
        return function_json


class ElementAggregateOperator(AbstractBinaryOperator):
    CLASS = "cn.thutmose.abution.graph.federated.simple.merge.operator.ElementAggregateOperator"

    def __init__(
        self,
        schema: typing.Optional[typing.Dict] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.schema = schema

    def to_json(self):
        function_json = super().to_json()
        if self.schema is not None:
            function_json["schema"] = self.schema
        return function_json


class HyperLogLogPlusAggregator(AbstractBinaryOperator):
    CLASS = "cn.thutmose.abution.graph.sketches.clearspring.cardinality.binaryoperator.HyperLogLogPlusAggregator"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class HllSketchAggregator(AbstractBinaryOperator):
    CLASS = "cn.thutmose.abution.graph.sketches.datasketches.cardinality.binaryoperator.HllSketchAggregator"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class HllUnionAggregator(AbstractBinaryOperator):
    CLASS = "cn.thutmose.abution.graph.sketches.datasketches.cardinality.binaryoperator.HllUnionAggregator"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class LongsSketchAggregator(AbstractBinaryOperator):
    CLASS = "cn.thutmose.abution.graph.sketches.datasketches.frequencies.binaryoperator.LongsSketchAggregator"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class StringsSketchAggregator(AbstractBinaryOperator):
    CLASS = "cn.thutmose.abution.graph.sketches.datasketches.frequencies.binaryoperator.StringsSketchAggregator"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class DoublesSketchAggregator(AbstractBinaryOperator):
    CLASS = "cn.thutmose.abution.graph.sketches.datasketches.quantiles.binaryoperator.DoublesSketchAggregator"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class DoublesUnionAggregator(AbstractBinaryOperator):
    CLASS = "cn.thutmose.abution.graph.sketches.datasketches.quantiles.binaryoperator.DoublesUnionAggregator"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class KllFloatsSketchAggregator(AbstractBinaryOperator):
    CLASS = "cn.thutmose.abution.graph.sketches.datasketches.quantiles.binaryoperator.KllFloatsSketchAggregator"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class StringsSketchAggregator(AbstractBinaryOperator):
    CLASS = "cn.thutmose.abution.graph.sketches.datasketches.quantiles.binaryoperator.StringsSketchAggregator"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class StringsUnionAggregator(AbstractBinaryOperator):
    CLASS = "cn.thutmose.abution.graph.sketches.datasketches.quantiles.binaryoperator.StringsUnionAggregator"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class ReservoirItemsSketchAggregator(AbstractBinaryOperator):
    CLASS = "cn.thutmose.abution.graph.sketches.datasketches.sampling.binaryoperator.ReservoirItemsSketchAggregator"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class ReservoirItemsUnionAggregator(AbstractBinaryOperator):
    CLASS = "cn.thutmose.abution.graph.sketches.datasketches.sampling.binaryoperator.ReservoirItemsUnionAggregator"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class ReservoirLongsSketchAggregator(AbstractBinaryOperator):
    CLASS = "cn.thutmose.abution.graph.sketches.datasketches.sampling.binaryoperator.ReservoirLongsSketchAggregator"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class ReservoirLongsUnionAggregator(AbstractBinaryOperator):
    CLASS = "cn.thutmose.abution.graph.sketches.datasketches.sampling.binaryoperator.ReservoirLongsUnionAggregator"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class SketchAggregator(AbstractBinaryOperator):
    CLASS = "cn.thutmose.abution.graph.sketches.datasketches.theta.binaryoperator.SketchAggregator"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class UnionAggregator(AbstractBinaryOperator):
    CLASS = "cn.thutmose.abution.graph.sketches.datasketches.theta.binaryoperator.UnionAggregator"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class AggregatorUtilIngestElementBinaryOperator(AbstractBinaryOperator):
    CLASS = "cn.thutmose.abution.graph.store.util.AggregatorUtil$IngestElementBinaryOperator"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class AggregatorUtilIngestPropertiesBinaryOperator(AbstractBinaryOperator):
    CLASS = "cn.thutmose.abution.graph.store.util.AggregatorUtil$IngestPropertiesBinaryOperator"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class AggregatorUtilQueryElementBinaryOperator(AbstractBinaryOperator):
    CLASS = "cn.thutmose.abution.graph.store.util.AggregatorUtil$QueryElementBinaryOperator"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class AggregatorUtilQueryPropertiesBinaryOperator(AbstractBinaryOperator):
    CLASS = "cn.thutmose.abution.graph.store.util.AggregatorUtil$QueryPropertiesBinaryOperator"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class BoundedTimestampSetAggregator(AbstractBinaryOperator):
    CLASS = "cn.thutmose.abution.graph.time.binaryoperator.BoundedTimestampSetAggregator"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class LongTimeSeriesAggregator(AbstractBinaryOperator):
    CLASS = "cn.thutmose.abution.graph.time.binaryoperator.LongTimeSeriesAggregator"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class RBMBackedTimestampSetAggregator(AbstractBinaryOperator):
    CLASS = "cn.thutmose.abution.graph.time.binaryoperator.RBMBackedTimestampSetAggregator"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class CustomMapAggregator(AbstractBinaryOperator):
    CLASS = "cn.thutmose.abution.graph.types.binaryoperator.CustomMapAggregator"

    def __init__(
        self,
        binary_operator: typing.Optional[BinaryOperator] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.binary_operator = binary_operator

    def to_json(self):
        function_json = super().to_json()
        if self.binary_operator is not None:
            function_json["binaryOperator"] = self.binary_operator
        return function_json


class FreqMapAggregator(AbstractBinaryOperator):
    CLASS = "cn.thutmose.abution.graph.types.function.FreqMapAggregator"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class AdaptedBinaryOperator(AbstractBinaryOperator):
    CLASS = "cn.thutmose.abution.jfunc.binaryoperator.AdaptedBinaryOperator"

    def __init__(
        self,
        input_adapter: typing.Optional[Function] = None,
        binary_operator: typing.Optional[BinaryOperator] = None,
        output_adapter: typing.Optional[typing.Any] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.input_adapter = input_adapter
        self.binary_operator = binary_operator
        self.output_adapter = output_adapter

    def to_json(self):
        function_json = super().to_json()
        if self.input_adapter is not None:
            function_json["inputAdapter"] = self.input_adapter
        if self.binary_operator is not None:
            function_json["binaryOperator"] = self.binary_operator
        if self.output_adapter is not None:
            function_json["outputAdapter"] = self.output_adapter
        return function_json


class BinaryOperatorComposite(AbstractBinaryOperator):
    CLASS = "cn.thutmose.abution.jfunc.binaryoperator.BinaryOperatorComposite"

    def __init__(
        self,
        operators: typing.Optional[typing.List[typing.Any]] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.operators = operators

    def to_json(self):
        function_json = super().to_json()
        if self.operators is not None:
            function_json["operators"] = self.operators
        return function_json


class BinaryOperatorMap(AbstractBinaryOperator):
    CLASS = "cn.thutmose.abution.jfunc.binaryoperator.BinaryOperatorMap"

    def __init__(
        self,
        binary_operator: typing.Optional[BinaryOperator] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.binary_operator = binary_operator

    def to_json(self):
        function_json = super().to_json()
        if self.binary_operator is not None:
            function_json["binaryOperator"] = self.binary_operator
        return function_json


class And(AbstractBinaryOperator):
    CLASS = "cn.thutmose.abution.jfunc.impl.binaryoperator.And"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class CollectionConcat(AbstractBinaryOperator):
    CLASS = "cn.thutmose.abution.jfunc.impl.binaryoperator.CollectionConcat"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class CollectionIntersect(AbstractBinaryOperator):
    CLASS = "cn.thutmose.abution.jfunc.impl.binaryoperator.CollectionIntersect"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class First(AbstractBinaryOperator):
    CLASS = "cn.thutmose.abution.jfunc.impl.binaryoperator.First"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class IterableMerge(AbstractBinaryOperator):
    CLASS = "cn.thutmose.abution.jfunc.impl.binaryoperator.IterableMerge"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class Last(AbstractBinaryOperator):
    CLASS = "cn.thutmose.abution.jfunc.impl.binaryoperator.Last"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class Max(AbstractBinaryOperator):
    CLASS = "cn.thutmose.abution.jfunc.impl.binaryoperator.Max"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class Min(AbstractBinaryOperator):
    CLASS = "cn.thutmose.abution.jfunc.impl.binaryoperator.Min"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class Or(AbstractBinaryOperator):
    CLASS = "cn.thutmose.abution.jfunc.impl.binaryoperator.Or"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class Product(AbstractBinaryOperator):
    CLASS = "cn.thutmose.abution.jfunc.impl.binaryoperator.Product"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class StringConcat(AbstractBinaryOperator):
    CLASS = "cn.thutmose.abution.jfunc.impl.binaryoperator.StringConcat"

    def __init__(
        self,
        separator: typing.Optional[str] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.separator = separator

    def to_json(self):
        function_json = super().to_json()
        if self.separator is not None:
            function_json["separator"] = self.separator
        return function_json


class StringDeduplicateConcat(AbstractBinaryOperator):
    CLASS = "cn.thutmose.abution.jfunc.impl.binaryoperator.StringDeduplicateConcat"

    def __init__(
        self,
        separator: typing.Optional[str] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.separator = separator

    def to_json(self):
        function_json = super().to_json()
        if self.separator is not None:
            function_json["separator"] = self.separator
        return function_json


class Sum(AbstractBinaryOperator):
    CLASS = "cn.thutmose.abution.jfunc.impl.binaryoperator.Sum"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class TupleAdaptedBinaryOperator(AbstractBinaryOperator):
    CLASS = "cn.thutmose.abution.jfunc.tuple.binaryoperator.TupleAdaptedBinaryOperator"

    def __init__(
        self,
        input_adapter: typing.Optional[Function] = None,
        selection: typing.Optional[typing.List[typing.Any]] = None,
        binary_operator: typing.Optional[BinaryOperator] = None,
        output_adapter: typing.Optional[typing.Any] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.input_adapter = input_adapter
        self.selection = selection
        self.binary_operator = binary_operator
        self.output_adapter = output_adapter

    def to_json(self):
        function_json = super().to_json()
        if self.input_adapter is not None:
            function_json["inputAdapter"] = self.input_adapter
        if self.selection is not None:
            function_json["selection"] = self.selection
        if self.binary_operator is not None:
            function_json["binaryOperator"] = self.binary_operator
        if self.output_adapter is not None:
            function_json["outputAdapter"] = self.output_adapter
        return function_json


class TupleAdaptedBinaryOperatorComposite(AbstractBinaryOperator):
    CLASS = "cn.thutmose.abution.jfunc.tuple.binaryoperator.TupleAdaptedBinaryOperatorComposite"

    def __init__(
        self,
        operators: typing.Optional[typing.List[typing.Any]] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.operators = operators

    def to_json(self):
        function_json = super().to_json()
        if self.operators is not None:
            function_json["operators"] = self.operators
        return function_json


class HashMapAggregator(AbstractBinaryOperator):
    CLASS = "cn.thutmose.abution.graph.type.impl.aggregate.HashMapAggregator"

    def __init__(
        self,
        topN: int = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.topN = topN

    def to_json(self):
        function_json = super().to_json()
        if self.topN is not None:
            function_json["topN"] = self.topN
        return function_json
