#
# Copyright 2022-2025 Crown Copyright
#
# Licensed under the Apache License, Version 2.0 (the 'License');
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.thutmose.cn
#
# by AbutionGraph-3.x.x
#

"""
This module has been generated with fishbowl.
To make changes, either extend these classes or change fishbowl.
"""

import typing
from abutionpy.abution_core import AbstractFunction, BinaryOperator, Function, Predicate


class ElementTransformer(AbstractFunction):
    CLASS = "cn.thutmose.abution.graph.data.knowhow.function.ElementTransformer"

    def __init__(
        self,
        functions: typing.Optional[typing.List[typing.Any]] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.functions = functions

    def to_json(self):
        function_json = super().to_json()
        if self.functions is not None:
            function_json["functions"] = self.functions
        return function_json


class ExtractLabel(AbstractFunction):
    CLASS = "cn.thutmose.abution.graph.data.knowhow.function.ExtractLabel"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class ExtractId(AbstractFunction):
    CLASS = "cn.thutmose.abution.graph.data.knowhow.function.ExtractId"

    def __init__(
        self,
        id: typing.Optional[str] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.id = id

    def to_json(self):
        function_json = super().to_json()
        if self.id is not None:
            function_json["id"] = self.id
        return function_json


class ExtractProperty(AbstractFunction):
    CLASS = "cn.thutmose.abution.graph.data.knowhow.function.ExtractProperty"

    def __init__(
        self,
        name: typing.Optional[str] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.name = name

    def to_json(self):
        function_json = super().to_json()
        if self.name is not None:
            function_json["name"] = self.name
        return function_json


class PropertiesTransformer(AbstractFunction):
    CLASS = "cn.thutmose.abution.graph.data.knowhow.function.PropertiesTransformer"

    def __init__(
        self,
        functions: typing.Optional[typing.List[typing.Any]] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.functions = functions

    def to_json(self):
        function_json = super().to_json()
        if self.functions is not None:
            function_json["functions"] = self.functions
        return function_json


class ReduceRelatedElements(AbstractFunction):
    CLASS = "cn.thutmose.abution.graph.data.knowhow.function.ReduceRelatedElements"

    def __init__(
        self,
        visibility_aggregator: typing.Optional[BinaryOperator] = None,
        vertex_aggregator: typing.Optional[BinaryOperator] = None,
        related_vertex_groups: typing.Optional[typing.Set[str]] = None,
        visibility_property: typing.Optional[str] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.visibility_aggregator = visibility_aggregator
        self.vertex_aggregator = vertex_aggregator
        self.related_vertex_groups = related_vertex_groups
        self.visibility_property = visibility_property

    def to_json(self):
        function_json = super().to_json()
        if self.visibility_aggregator is not None:
            function_json["visibilityAggregator"] = self.visibility_aggregator
        if self.vertex_aggregator is not None:
            function_json["vertexAggregator"] = self.vertex_aggregator
        if self.related_vertex_groups is not None:
            function_json["relatedVertexGroups"] = self.related_vertex_groups
        if self.visibility_property is not None:
            function_json["visibilityProperty"] = self.visibility_property
        return function_json


class ToElementTuple(AbstractFunction):
    CLASS = "cn.thutmose.abution.graph.data.knowhow.function.ToElementTuple"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class ToPropertiesTuple(AbstractFunction):
    CLASS = "cn.thutmose.abution.graph.data.knowhow.function.ToPropertiesTuple"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class TupleToElements(AbstractFunction):
    CLASS = "cn.thutmose.abution.graph.data.knowhow.function.TupleToElements"

    def __init__(
        self,
        elements: typing.Optional[typing.List[typing.Any]] = None,
        use_group_mapping: typing.Optional[bool] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.elements = elements
        self.use_group_mapping = use_group_mapping

    def to_json(self):
        function_json = super().to_json()
        if self.elements is not None:
            function_json["elements"] = self.elements
        if self.use_group_mapping is not None:
            function_json["useGroupMapping"] = self.use_group_mapping
        return function_json


class TuplesToElements(AbstractFunction):
    CLASS = "cn.thutmose.abution.graph.data.knowhow.function.TuplesToElements"

    def __init__(
        self,
        elements: typing.Optional[typing.List[typing.Any]] = None,
        use_group_mapping: typing.Optional[bool] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.elements = elements
        self.use_group_mapping = use_group_mapping

    def to_json(self):
        function_json = super().to_json()
        if self.elements is not None:
            function_json["elements"] = self.elements
        if self.use_group_mapping is not None:
            function_json["useGroupMapping"] = self.use_group_mapping
        return function_json


class TypeSubTypeValueToTuple(AbstractFunction):
    CLASS = "cn.thutmose.abution.graph.data.knowhow.function.TypeSubTypeValueToTuple"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class TypeValueToTuple(AbstractFunction):
    CLASS = "cn.thutmose.abution.graph.data.knowhow.function.TypeValueToTuple"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class UnwrapEntityId(AbstractFunction):
    CLASS = "cn.thutmose.abution.graph.data.knowhow.function.UnwrapEntityId"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class CsvGenerator(AbstractFunction):
    CLASS = "cn.thutmose.abution.graph.data.generator.CsvGenerator"

    def __init__(
        self,
        quoted: typing.Optional[bool] = None,
        comma_replacement: typing.Optional[str] = None,
        include_default_fields: typing.Optional[bool] = None,
        include_schema_properties: typing.Optional[bool] = None,
        constants: typing.Optional[typing.Dict[str, str]] = None,
        fields: typing.Optional[typing.Dict[str, str]] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.quoted = quoted
        self.comma_replacement = comma_replacement
        self.include_default_fields = include_default_fields
        self.include_schema_properties = include_schema_properties
        self.constants = constants
        self.fields = fields

    def to_json(self):
        function_json = super().to_json()
        if self.quoted is not None:
            function_json["quoted"] = self.quoted
        if self.comma_replacement is not None:
            function_json["commaReplacement"] = self.comma_replacement
        if self.include_default_fields is not None:
            function_json["includeDefaultFields"] = self.include_default_fields
        if self.include_schema_properties is not None:
            function_json["includeSchemaProperties"] = self.include_schema_properties
        if self.constants is not None:
            function_json["constants"] = self.constants
        if self.fields is not None:
            function_json["fields"] = self.fields
        return function_json


class JsonToKnowledgeGenerator(AbstractFunction):
    CLASS = "cn.thutmose.abution.graph.data.generator.JsonToKnowledgeGenerator"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class MapGenerator(AbstractFunction):
    CLASS = "cn.thutmose.abution.graph.data.generator.MapGenerator"

    def __init__(
        self,
        constants: typing.Optional[typing.Dict[str, str]] = None,
        fields: typing.Optional[typing.Dict[str, str]] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.constants = constants
        self.fields = fields

    def to_json(self):
        function_json = super().to_json()
        if self.constants is not None:
            function_json["constants"] = self.constants
        if self.fields is not None:
            function_json["fields"] = self.fields
        return function_json


class Neo4jCsvKnowledgeGenerator(AbstractFunction):
    CLASS = "cn.thutmose.abution.graph.data.generator.Neo4jCsvKnowledgeGenerator"

    def __init__(
        self,
        first_row: typing.Optional[int] = None,
        trim: typing.Optional[bool] = None,
        delimiter: typing.Optional[str] = None,
        null_string: typing.Optional[str] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.first_row = first_row
        self.trim = trim
        self.delimiter = delimiter
        self.null_string = null_string

    def to_json(self):
        function_json = super().to_json()
        if self.first_row is not None:
            function_json["firstRow"] = self.first_row
        if self.trim is not None:
            function_json["trim"] = self.trim
        if self.delimiter is not None:
            function_json["delimiter"] = self.delimiter
        if self.null_string is not None:
            function_json["nullString"] = self.null_string
        return function_json


class Neo4jCsvGenerator(AbstractFunction):
    CLASS = "cn.thutmose.abution.graph.data.generator.Neo4jCsvGenerator"

    def __init__(
        self,
        quoted: typing.Optional[bool] = None,
        comma_replacement: typing.Optional[str] = None,
        include_default_fields: typing.Optional[bool] = None,
        include_schema_properties: typing.Optional[bool] = None,
        constants: typing.Optional[typing.Dict[str, str]] = None,
        fields: typing.Optional[typing.Dict[str, str]] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.quoted = quoted
        self.comma_replacement = comma_replacement
        self.include_default_fields = include_default_fields
        self.include_schema_properties = include_schema_properties
        self.constants = constants
        self.fields = fields

    def to_json(self):
        function_json = super().to_json()
        if self.quoted is not None:
            function_json["quoted"] = self.quoted
        if self.comma_replacement is not None:
            function_json["commaReplacement"] = self.comma_replacement
        if self.include_default_fields is not None:
            function_json["includeDefaultFields"] = self.include_default_fields
        if self.include_schema_properties is not None:
            function_json["includeSchemaProperties"] = self.include_schema_properties
        if self.constants is not None:
            function_json["constants"] = self.constants
        if self.fields is not None:
            function_json["fields"] = self.fields
        return function_json


class NeptuneCsvKnowledgeGenerator(AbstractFunction):
    CLASS = "cn.thutmose.abution.graph.data.generator.NeptuneCsvKnowledgeGenerator"

    def __init__(
        self,
        first_row: typing.Optional[int] = None,
        trim: typing.Optional[bool] = None,
        delimiter: typing.Optional[str] = None,
        null_string: typing.Optional[str] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.first_row = first_row
        self.trim = trim
        self.delimiter = delimiter
        self.null_string = null_string

    def to_json(self):
        function_json = super().to_json()
        if self.first_row is not None:
            function_json["firstRow"] = self.first_row
        if self.trim is not None:
            function_json["trim"] = self.trim
        if self.delimiter is not None:
            function_json["delimiter"] = self.delimiter
        if self.null_string is not None:
            function_json["nullString"] = self.null_string
        return function_json


class NeptuneCsvGenerator(AbstractFunction):
    CLASS = "cn.thutmose.abution.graph.data.generator.NeptuneCsvGenerator"

    def __init__(
        self,
        quoted: typing.Optional[bool] = None,
        comma_replacement: typing.Optional[str] = None,
        include_default_fields: typing.Optional[bool] = None,
        include_schema_properties: typing.Optional[bool] = None,
        constants: typing.Optional[typing.Dict[str, str]] = None,
        fields: typing.Optional[typing.Dict[str, str]] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.quoted = quoted
        self.comma_replacement = comma_replacement
        self.include_default_fields = include_default_fields
        self.include_schema_properties = include_schema_properties
        self.constants = constants
        self.fields = fields

    def to_json(self):
        function_json = super().to_json()
        if self.quoted is not None:
            function_json["quoted"] = self.quoted
        if self.comma_replacement is not None:
            function_json["commaReplacement"] = self.comma_replacement
        if self.include_default_fields is not None:
            function_json["includeDefaultFields"] = self.include_default_fields
        if self.include_schema_properties is not None:
            function_json["includeSchemaProperties"] = self.include_schema_properties
        if self.constants is not None:
            function_json["constants"] = self.constants
        if self.fields is not None:
            function_json["fields"] = self.fields
        return function_json


class ExtractWalkEdges(AbstractFunction):
    CLASS = "cn.thutmose.abution.graph.data.graph.function.walk.ExtractWalkEdges"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class ExtractWalkEdgesFromHop(AbstractFunction):
    CLASS = "cn.thutmose.abution.graph.data.graph.function.walk.ExtractWalkEdgesFromHop"

    def __init__(
        self,
        hop: typing.Optional[int] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.hop = hop

    def to_json(self):
        function_json = super().to_json()
        if self.hop is not None:
            function_json["hop"] = self.hop
        return function_json


class ExtractWalkEntities(AbstractFunction):
    CLASS = "cn.thutmose.abution.graph.data.graph.function.walk.ExtractWalkEntities"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class ExtractWalkEntitiesFromHop(AbstractFunction):
    CLASS = "cn.thutmose.abution.graph.data.graph.function.walk.ExtractWalkEntitiesFromHop"

    def __init__(
        self,
        hop: typing.Optional[int] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.hop = hop

    def to_json(self):
        function_json = super().to_json()
        if self.hop is not None:
            function_json["hop"] = self.hop
        return function_json


class ExtractWalkVertex(AbstractFunction):
    CLASS = "cn.thutmose.abution.graph.data.graph.function.walk.ExtractWalkVertex"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class EdgeIdExtractor(AbstractFunction):
    CLASS = "cn.thutmose.abution.graph.operation.data.generator.EdgeIdExtractor"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class EntityIdExtractor(AbstractFunction):
    CLASS = "cn.thutmose.abution.graph.operation.data.generator.EntityIdExtractor"

    def __init__(
        self,
        edge_identifier_to_extract: typing.Optional[str] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.edge_identifier_to_extract = edge_identifier_to_extract

    def to_json(self):
        function_json = super().to_json()
        if self.edge_identifier_to_extract is not None:
            function_json["edgeIdentifierToExtract"] = self.edge_identifier_to_extract
        return function_json


class FromElementId(AbstractFunction):
    CLASS = "cn.thutmose.abution.graph.operation.function.FromElementId"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class FromEntityId(AbstractFunction):
    CLASS = "cn.thutmose.abution.graph.operation.function.FromEntityId"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class ToKnowledgeId(AbstractFunction):
    CLASS = "cn.thutmose.abution.graph.operation.function.ToKnowledgeId"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class ToEntityId(AbstractFunction):
    CLASS = "cn.thutmose.abution.graph.operation.function.ToEntityId"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class ToTrailingWildcardPair(AbstractFunction):
    CLASS = "cn.thutmose.abution.graph.operation.function.ToTrailingWildcardPair"

    def __init__(
        self,
        end_of_range: typing.Optional[str] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.end_of_range = end_of_range

    def to_json(self):
        function_json = super().to_json()
        if self.end_of_range is not None:
            function_json["endOfRange"] = self.end_of_range
        return function_json


class ExampleDomainObjectGenerator(AbstractFunction):
    CLASS = "cn.thutmose.abution.graph.rest.example.ExampleDomainObjectGenerator"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class ExampleKnowledgeGenerator(AbstractFunction):
    CLASS = "cn.thutmose.abution.graph.rest.example.ExampleKnowledgeGenerator"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class ExampleTransformFunction(AbstractFunction):
    CLASS = "cn.thutmose.abution.graph.rest.example.ExampleTransformFunction"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class HyperLogLogPlusEntityGenerator(AbstractFunction):
    CLASS = "cn.thutmose.abution.graph.sketches.clearspring.cardinality.HyperLogLogPlusEntityGenerator"

    def __init__(
        self,
        properties_to_copy: typing.Optional[typing.List[str]] = None,
        count_property: typing.Optional[str] = None,
        cardinality_property_name: typing.Optional[str] = None,
        edge_group_property: typing.Optional[str] = None,
        vertex_value_converter: typing.Optional[Function] = None,
        group: typing.Optional[str] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.properties_to_copy = properties_to_copy
        self.count_property = count_property
        self.cardinality_property_name = cardinality_property_name
        self.edge_group_property = edge_group_property
        self.vertex_value_converter = vertex_value_converter
        self.group = group

    def to_json(self):
        function_json = super().to_json()
        if self.properties_to_copy is not None:
            function_json["propertiesToCopy"] = self.properties_to_copy
        if self.count_property is not None:
            function_json["countProperty"] = self.count_property
        if self.cardinality_property_name is not None:
            function_json["cardinalityPropertyName"] = self.cardinality_property_name
        if self.edge_group_property is not None:
            function_json["edgeGroupProperty"] = self.edge_group_property
        if self.vertex_value_converter is not None:
            function_json["vertexValueConverter"] = self.vertex_value_converter
        if self.group is not None:
            function_json["group"] = self.group
        return function_json


class ItToHyperLogLogPlus(AbstractFunction):
    CLASS = "cn.thutmose.abution.graph.sketches.clearspring.cardinality.function.ItToHyperLogLogPlus"

    def __init__(
        self,
        p: typing.Optional[int] = None,
        sp: typing.Optional[int] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.p = p
        self.sp = sp

    def to_json(self):
        function_json = super().to_json()
        if self.p is not None:
            function_json["p"] = self.p
        if self.sp is not None:
            function_json["sp"] = self.sp
        return function_json


class ToHyperLogLogPlus(AbstractFunction):
    CLASS = "cn.thutmose.abution.graph.sketches.clearspring.cardinality.function.ToHyperLogLogPlus"

    def __init__(
        self,
        p: typing.Optional[int] = None,
        sp: typing.Optional[int] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.p = p
        self.sp = sp

    def to_json(self):
        function_json = super().to_json()
        if self.p is not None:
            function_json["p"] = self.p
        if self.sp is not None:
            function_json["sp"] = self.sp
        return function_json


class HllSketchEntityGenerator(AbstractFunction):
    CLASS = "cn.thutmose.abution.graph.sketches.datasketches.cardinality.HllSketchEntityGenerator"

    def __init__(
        self,
        properties_to_copy: typing.Optional[typing.List[str]] = None,
        count_property: typing.Optional[str] = None,
        cardinality_property_name: typing.Optional[str] = None,
        edge_group_property: typing.Optional[str] = None,
        vertex_value_converter: typing.Optional[Function] = None,
        group: typing.Optional[str] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.properties_to_copy = properties_to_copy
        self.count_property = count_property
        self.cardinality_property_name = cardinality_property_name
        self.edge_group_property = edge_group_property
        self.vertex_value_converter = vertex_value_converter
        self.group = group

    def to_json(self):
        function_json = super().to_json()
        if self.properties_to_copy is not None:
            function_json["propertiesToCopy"] = self.properties_to_copy
        if self.count_property is not None:
            function_json["countProperty"] = self.count_property
        if self.cardinality_property_name is not None:
            function_json["cardinalityPropertyName"] = self.cardinality_property_name
        if self.edge_group_property is not None:
            function_json["edgeGroupProperty"] = self.edge_group_property
        if self.vertex_value_converter is not None:
            function_json["vertexValueConverter"] = self.vertex_value_converter
        if self.group is not None:
            function_json["group"] = self.group
        return function_json


class ItToHllSketch(AbstractFunction):
    CLASS = "cn.thutmose.abution.graph.sketches.datasketches.cardinality.function.ItToHllSketch"

    def __init__(
        self,
        log_k: typing.Optional[int] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.log_k = log_k

    def to_json(self):
        function_json = super().to_json()
        if self.log_k is not None:
            function_json["logK"] = self.log_k
        return function_json


class ToHllSketch(AbstractFunction):
    CLASS = "cn.thutmose.abution.graph.sketches.datasketches.cardinality.function.ToHllSketch"

    def __init__(
        self,
        log_k: typing.Optional[int] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.log_k = log_k

    def to_json(self):
        function_json = super().to_json()
        if self.log_k is not None:
            function_json["logK"] = self.log_k
        return function_json


class AggregatorUtilToElementKey(AbstractFunction):
    CLASS = "cn.thutmose.abution.graph.store.util.AggregatorUtil$ToElementKey"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class AggregatorUtilToIngestElementKey(AbstractFunction):
    CLASS = "cn.thutmose.abution.graph.store.util.AggregatorUtil$ToIngestElementKey"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class AggregatorUtilToQueryElementKey(AbstractFunction):
    CLASS = "cn.thutmose.abution.graph.store.util.AggregatorUtil$ToQueryElementKey"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class DateToTimeBucketEnd(AbstractFunction):
    CLASS = "cn.thutmose.abution.graph.time.function.DateToTimeBucketEnd"

    def __init__(
        self,
        bucket: typing.Optional[str] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.bucket = bucket

    def to_json(self):
        function_json = super().to_json()
        if self.bucket is not None:
            function_json["bucket"] = self.bucket
        return function_json


class DateToTimeBucketStart(AbstractFunction):
    CLASS = "cn.thutmose.abution.graph.time.function.DateToTimeBucketStart"

    def __init__(
        self,
        bucket: typing.Optional[str] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.bucket = bucket

    def to_json(self):
        function_json = super().to_json()
        if self.bucket is not None:
            function_json["bucket"] = self.bucket
        return function_json


class MaskTimestampSetByTimeRange(AbstractFunction):
    CLASS = "cn.thutmose.abution.graph.time.function.MaskTimestampSetByTimeRange"

    def __init__(
        self,
        start_time: typing.Optional[int] = None,
        end_time: typing.Optional[int] = None,
        time_unit: typing.Optional[str] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.start_time = start_time
        self.end_time = end_time
        self.time_unit = time_unit

    def to_json(self):
        function_json = super().to_json()
        if self.start_time is not None:
            function_json["startTime"] = self.start_time
        if self.end_time is not None:
            function_json["endTime"] = self.end_time
        if self.time_unit is not None:
            function_json["timeUnit"] = self.time_unit
        return function_json


class ToSingletonTreeSet(AbstractFunction):
    CLASS = "cn.thutmose.abution.graph.time.function.ToSingletonTreeSet"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class ToTimeBucket(AbstractFunction):
    CLASS = "cn.thutmose.abution.graph.time.function.ToTimeBucket"

    def __init__(
        self,
        bucket: typing.Optional[str] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.bucket = bucket

    def to_json(self):
        function_json = super().to_json()
        if self.bucket is not None:
            function_json["bucket"] = self.bucket
        return function_json


class ToTimeBucketEnd(AbstractFunction):
    CLASS = "cn.thutmose.abution.graph.time.function.ToTimeBucketEnd"

    def __init__(
        self,
        bucket: typing.Optional[str] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.bucket = bucket

    def to_json(self):
        function_json = super().to_json()
        if self.bucket is not None:
            function_json["bucket"] = self.bucket
        return function_json


class ToTimeBucketStart(AbstractFunction):
    CLASS = "cn.thutmose.abution.graph.time.function.ToTimeBucketStart"

    def __init__(
        self,
        bucket: typing.Optional[str] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.bucket = bucket

    def to_json(self):
        function_json = super().to_json()
        if self.bucket is not None:
            function_json["bucket"] = self.bucket
        return function_json


class ToTimestampSet(AbstractFunction):
    CLASS = "cn.thutmose.abution.graph.time.function.ToTimestampSet"

    def __init__(
        self,
        bucket: typing.Optional[str] = None,
        max_size: typing.Optional[int] = None,
        millis_correction: typing.Optional[int] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.bucket = bucket
        self.max_size = max_size
        self.millis_correction = millis_correction

    def to_json(self):
        function_json = super().to_json()
        if self.bucket is not None:
            function_json["bucket"] = self.bucket
        if self.max_size is not None:
            function_json["maxSize"] = self.max_size
        if self.millis_correction is not None:
            function_json["millisCorrection"] = self.millis_correction
        return function_json


class AbutionEdgeGenerator(AbstractFunction):
    CLASS = "cn.thutmose.abution.graph.tinkerpop.generator.AbutionEdgeGenerator"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class AbutionEntityGenerator(AbstractFunction):
    CLASS = "cn.thutmose.abution.graph.tinkerpop.generator.AbutionEntityGenerator"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class AbutionPopEdgeGenerator(AbstractFunction):
    CLASS = "cn.thutmose.abution.graph.tinkerpop.generator.AbutionPopEdgeGenerator"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class AbutionPopKnowledgeGenerator(AbstractFunction):
    CLASS = "cn.thutmose.abution.graph.tinkerpop.generator.AbutionPopKnowledgeGenerator"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class AbutionPopVertexGenerator(AbstractFunction):
    CLASS = "cn.thutmose.abution.graph.tinkerpop.generator.AbutionPopVertexGenerator"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class FreqMapExtractor(AbstractFunction):
    CLASS = "cn.thutmose.abution.graph.types.function.FreqMapExtractor"

    def __init__(
        self,
        key: typing.Optional[str] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.key = key

    def to_json(self):
        function_json = super().to_json()
        if self.key is not None:
            function_json["key"] = self.key
        return function_json


class FreqMapPredicator(AbstractFunction):
    CLASS = "cn.thutmose.abution.graph.types.function.FreqMapPredicator"

    def __init__(
        self,
        predicate: typing.Optional[typing.Any] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.predicate = predicate

    def to_json(self):
        function_json = super().to_json()
        if self.predicate is not None:
            function_json["predicate"] = self.predicate
        return function_json


class ItToFreqMap(AbstractFunction):
    CLASS = "cn.thutmose.abution.graph.types.function.ItToFreqMap"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class StringsToTypeSubTypeValue(AbstractFunction):
    CLASS = "cn.thutmose.abution.graph.types.function.StringsToTypeSubTypeValue"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class StringsToTypeValue(AbstractFunction):
    CLASS = "cn.thutmose.abution.graph.types.function.StringsToTypeValue"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class ToFreqMap(AbstractFunction):
    CLASS = "cn.thutmose.abution.graph.types.function.ToFreqMap"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class ToTypeSubTypeValue(AbstractFunction):
    CLASS = "cn.thutmose.abution.graph.types.function.ToTypeSubTypeValue"

    def __init__(
        self,
        sub_type: typing.Optional[str] = None,
        type: typing.Optional[str] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.sub_type = sub_type
        self.type = type

    def to_json(self):
        function_json = super().to_json()
        if self.sub_type is not None:
            function_json["subType"] = self.sub_type
        if self.type is not None:
            function_json["type"] = self.type
        return function_json


class ToTypeValue(AbstractFunction):
    CLASS = "cn.thutmose.abution.graph.types.function.ToTypeValue"

    def __init__(
        self,
        type: typing.Optional[str] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.type = type

    def to_json(self):
        function_json = super().to_json()
        if self.type is not None:
            function_json["type"] = self.type
        return function_json


class FunctionComposite(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.function.FunctionComposite"

    def __init__(
        self,
        functions: typing.Optional[typing.List[typing.Any]] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.functions = functions

    def to_json(self):
        function_json = super().to_json()
        if self.functions is not None:
            function_json["functions"] = self.functions
        return function_json


class FunctionMap(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.function.FunctionMap"

    def __init__(
        self,
        function: typing.Optional[Function] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.function = function

    def to_json(self):
        function_json = super().to_json()
        if self.function is not None:
            function_json["function"] = self.function
        return function_json


class ApplyBiFunction(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.ApplyBiFunction"

    def __init__(
        self,
        function: typing.Optional[typing.Any] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.function = function

    def to_json(self):
        function_json = super().to_json()
        if self.function is not None:
            function_json["function"] = self.function
        return function_json


class Base64Decode(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.Base64Decode"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class CallMethod(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.CallMethod"

    def __init__(
        self,
        method: typing.Optional[str] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.method = method

    def to_json(self):
        function_json = super().to_json()
        if self.method is not None:
            function_json["method"] = self.method
        return function_json


class Cast(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.Cast"

    def __init__(
        self,
        output_class: typing.Optional[typing.Any] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.output_class = output_class

    def to_json(self):
        function_json = super().to_json()
        if self.output_class is not None:
            function_json["outputClass"] = self.output_class
        return function_json


class Concat(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.Concat"

    def __init__(
        self,
        separator: typing.Optional[str] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.separator = separator

    def to_json(self):
        function_json = super().to_json()
        if self.separator is not None:
            function_json["separator"] = self.separator
        return function_json


class CreateObject(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.CreateObject"

    def __init__(
        self,
        object_class: typing.Optional[typing.Any] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.object_class = object_class

    def to_json(self):
        function_json = super().to_json()
        if self.object_class is not None:
            function_json["objectClass"] = self.object_class
        return function_json


class CsvLinesToMaps(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.CsvLinesToMaps"

    def __init__(
        self,
        quoted: typing.Optional[bool] = None,
        quote_char: typing.Optional[str] = None,
        first_row: typing.Optional[int] = None,
        trim: typing.Optional[bool] = None,
        delimiter: typing.Optional[str] = None,
        null_string: typing.Optional[str] = None,
        header: typing.Optional[typing.List[str]] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.quoted = quoted
        self.quote_char = quote_char
        self.first_row = first_row
        self.trim = trim
        self.delimiter = delimiter
        self.null_string = null_string
        self.header = header

    def to_json(self):
        function_json = super().to_json()
        if self.quoted is not None:
            function_json["quoted"] = self.quoted
        if self.quote_char is not None:
            function_json["quoteChar"] = self.quote_char
        if self.first_row is not None:
            function_json["firstRow"] = self.first_row
        if self.trim is not None:
            function_json["trim"] = self.trim
        if self.delimiter is not None:
            function_json["delimiter"] = self.delimiter
        if self.null_string is not None:
            function_json["nullString"] = self.null_string
        if self.header is not None:
            function_json["header"] = self.header
        return function_json


class CsvToMaps(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.CsvToMaps"

    def __init__(
        self,
        quoted: typing.Optional[bool] = None,
        quote_char: typing.Optional[str] = None,
        first_row: typing.Optional[int] = None,
        delimiter: typing.Optional[str] = None,
        header: typing.Optional[typing.List[str]] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.quoted = quoted
        self.quote_char = quote_char
        self.first_row = first_row
        self.delimiter = delimiter
        self.header = header

    def to_json(self):
        function_json = super().to_json()
        if self.quoted is not None:
            function_json["quoted"] = self.quoted
        if self.quote_char is not None:
            function_json["quoteChar"] = self.quote_char
        if self.first_row is not None:
            function_json["firstRow"] = self.first_row
        if self.delimiter is not None:
            function_json["delimiter"] = self.delimiter
        if self.header is not None:
            function_json["header"] = self.header
        return function_json


class CurrentDate(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.CurrentDate"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class CurrentTime(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.CurrentTime"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class DefaultIfEmpty(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.DefaultIfEmpty"

    def __init__(
        self,
        default_value: typing.Optional[typing.Any] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.default_value = default_value

    def to_json(self):
        function_json = super().to_json()
        if self.default_value is not None:
            function_json["defaultValue"] = self.default_value
        return function_json


class DefaultIfNull(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.DefaultIfNull"

    def __init__(
        self,
        default_value: typing.Optional[typing.Any] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.default_value = default_value

    def to_json(self):
        function_json = super().to_json()
        if self.default_value is not None:
            function_json["defaultValue"] = self.default_value
        return function_json


class DeserialiseJson(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.DeserialiseJson"

    def __init__(
        self,
        output_class: typing.Optional[typing.Any] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.output_class = output_class

    def to_json(self):
        function_json = super().to_json()
        if self.output_class is not None:
            function_json["outputClass"] = self.output_class
        return function_json


class DeserialiseXml(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.DeserialiseXml"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class DictionaryLookup(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.DictionaryLookup"

    def __init__(
        self,
        dictionary: typing.Optional[typing.Dict[typing.Any, typing.Any]] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.dictionary = dictionary

    def to_json(self):
        function_json = super().to_json()
        if self.dictionary is not None:
            function_json["dictionary"] = self.dictionary
        return function_json


class Divide(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.Divide"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class DivideBy(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.DivideBy"

    def __init__(
        self,
        by: typing.Optional[int] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.by = by

    def to_json(self):
        function_json = super().to_json()
        if self.by is not None:
            function_json["by"] = self.by
        return function_json


class DictKeys(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.DictKeys"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class DictValue(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.DictValue"

    def __init__(
        self,
        key: typing.Optional[typing.Any] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.key = key

    def to_json(self):
        function_json = super().to_json()
        if self.key is not None:
            function_json["key"] = self.key
        return function_json


class DictValues(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.DictValues"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class FirstItem(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.FirstItem"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class FirstValid(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.FirstValid"

    def __init__(
        self,
        predicate: typing.Optional[Predicate] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.predicate = predicate

    def to_json(self):
        function_json = super().to_json()
        if self.predicate is not None:
            function_json["predicate"] = self.predicate
        return function_json


class FunctionChain(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.FunctionChain"

    def __init__(
        self,
        functions: typing.Optional[typing.List[typing.Any]] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.functions = functions

    def to_json(self):
        function_json = super().to_json()
        if self.functions is not None:
            function_json["functions"] = self.functions
        return function_json


class Gunzip(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.Gunzip"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class Identity(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.Identity"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class If(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.If"

    def __init__(
        self,
        otherwise: typing.Optional[Function] = None,
        predicate: typing.Optional[Predicate] = None,
        condition: typing.Optional[bool] = None,
        then: typing.Optional[Function] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.otherwise = otherwise
        self.predicate = predicate
        self.condition = condition
        self.then = then

    def to_json(self):
        function_json = super().to_json()
        if self.otherwise is not None:
            function_json["otherwise"] = self.otherwise
        if self.predicate is not None:
            function_json["predicate"] = self.predicate
        if self.condition is not None:
            function_json["condition"] = self.condition
        if self.then is not None:
            function_json["then"] = self.then
        return function_json


class Increment(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.Increment"

    def __init__(
        self,
        increment: typing.Optional[typing.Any] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.increment = increment

    def to_json(self):
        function_json = super().to_json()
        if self.increment is not None:
            function_json["increment"] = self.increment
        return function_json


class IsEmpty(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.IsEmpty"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class ItConcat(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.ItConcat"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class ItFilter(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.ItFilter"

    def __init__(
        self,
        predicate: typing.Optional[Predicate] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.predicate = predicate

    def to_json(self):
        function_json = super().to_json()
        if self.predicate is not None:
            function_json["predicate"] = self.predicate
        return function_json


class ItFlatten(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.ItFlatten"

    def __init__(
        self,
        operator: typing.Optional[BinaryOperator] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.operator = operator

    def to_json(self):
        function_json = super().to_json()
        if self.operator is not None:
            function_json["operator"] = self.operator
        return function_json


class ItFunc(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.ItFunc"

    def __init__(
        self,
        functions: typing.Optional[typing.List[Function]] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.functions = functions

    def to_json(self):
        function_json = super().to_json()
        if self.functions is not None:
            function_json["functions"] = self.functions
        return function_json


class ItLongest(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.ItLongest"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class LastItem(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.LastItem"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class Length(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.Length"

    def __init__(
        self,
        max_length: typing.Optional[int] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.max_length = max_length

    def to_json(self):
        function_json = super().to_json()
        if self.max_length is not None:
            function_json["maxLength"] = self.max_length
        return function_json


class Longest(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.Longest"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class MapFilter(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.MapFilter"

    def __init__(
        self,
        key_predicate: typing.Optional[Predicate] = None,
        key_value_predicate: typing.Optional[typing.Any] = None,
        value_predicate: typing.Optional[Predicate] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.key_predicate = key_predicate
        self.key_value_predicate = key_value_predicate
        self.value_predicate = value_predicate

    def to_json(self):
        function_json = super().to_json()
        if self.key_predicate is not None:
            function_json["keyPredicate"] = self.key_predicate
        if self.key_value_predicate is not None:
            function_json["keyValuePredicate"] = self.key_value_predicate
        if self.value_predicate is not None:
            function_json["valuePredicate"] = self.value_predicate
        return function_json


class MapToTuple(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.MapToTuple"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class Multiply(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.Multiply"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class MultiplyBy(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.MultiplyBy"

    def __init__(
        self,
        by: typing.Optional[int] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.by = by

    def to_json(self):
        function_json = super().to_json()
        if self.by is not None:
            function_json["by"] = self.by
        return function_json


class MultiplyLongBy(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.MultiplyLongBy"

    def __init__(
        self,
        by: typing.Optional[int] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.by = by

    def to_json(self):
        function_json = super().to_json()
        if self.by is not None:
            function_json["by"] = self.by
        return function_json


class NthItem(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.NthItem"

    def __init__(
        self,
        selection: typing.Optional[int] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.selection = selection

    def to_json(self):
        function_json = super().to_json()
        if self.selection is not None:
            function_json["selection"] = self.selection
        return function_json


class ParseDate(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.ParseDate"

    def __init__(
        self,
        format: typing.Optional[str] = None,
        time_zone: typing.Optional[str] = None,
        microseconds: typing.Optional[bool] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.format = format
        self.time_zone = time_zone
        self.microseconds = microseconds

    def to_json(self):
        function_json = super().to_json()
        if self.format is not None:
            function_json["format"] = self.format
        if self.time_zone is not None:
            function_json["timeZone"] = self.time_zone
        if self.microseconds is not None:
            function_json["microseconds"] = self.microseconds
        return function_json


class ParseTime(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.ParseTime"

    def __init__(
        self,
        format: typing.Optional[str] = None,
        time_zone: typing.Optional[str] = None,
        time_unit: typing.Optional[str] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.format = format
        self.time_zone = time_zone
        self.time_unit = time_unit

    def to_json(self):
        function_json = super().to_json()
        if self.format is not None:
            function_json["format"] = self.format
        if self.time_zone is not None:
            function_json["timeZone"] = self.time_zone
        if self.time_unit is not None:
            function_json["timeUnit"] = self.time_unit
        return function_json


class ReverseString(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.ReverseString"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class SetValue(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.SetValue"

    def __init__(
        self,
        value: typing.Optional[typing.Any] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.value = value

    def to_json(self):
        function_json = super().to_json()
        if self.value is not None:
            function_json["value"] = self.value
        return function_json


class Size(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.Size"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class StringAppend(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.StringAppend"

    def __init__(
        self,
        suffix: typing.Optional[str] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.suffix = suffix

    def to_json(self):
        function_json = super().to_json()
        if self.suffix is not None:
            function_json["suffix"] = self.suffix
        return function_json


class StringJoin(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.StringJoin"

    def __init__(
        self,
        delimiter: typing.Optional[str] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.delimiter = delimiter

    def to_json(self):
        function_json = super().to_json()
        if self.delimiter is not None:
            function_json["delimiter"] = self.delimiter
        return function_json


class StringPrepend(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.StringPrepend"

    def __init__(
        self,
        prefix: typing.Optional[str] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.prefix = prefix

    def to_json(self):
        function_json = super().to_json()
        if self.prefix is not None:
            function_json["prefix"] = self.prefix
        return function_json


class StringRegexReplace(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.StringRegexReplace"

    def __init__(
        self,
        regex: typing.Optional[str] = None,
        replacement: typing.Optional[str] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.regex = regex
        self.replacement = replacement

    def to_json(self):
        function_json = super().to_json()
        if self.regex is not None:
            function_json["regex"] = self.regex
        if self.replacement is not None:
            function_json["replacement"] = self.replacement
        return function_json


class StringRegexSplit(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.StringRegexSplit"

    def __init__(
        self,
        regex: typing.Optional[str] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.regex = regex

    def to_json(self):
        function_json = super().to_json()
        if self.regex is not None:
            function_json["regex"] = self.regex
        return function_json


class StringReplace(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.StringReplace"

    def __init__(
        self,
        search_string: typing.Optional[str] = None,
        replacement: typing.Optional[str] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.search_string = search_string
        self.replacement = replacement

    def to_json(self):
        function_json = super().to_json()
        if self.search_string is not None:
            function_json["searchString"] = self.search_string
        if self.replacement is not None:
            function_json["replacement"] = self.replacement
        return function_json


class StringSplit(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.StringSplit"

    def __init__(
        self,
        delimiter: typing.Optional[str] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.delimiter = delimiter

    def to_json(self):
        function_json = super().to_json()
        if self.delimiter is not None:
            function_json["delimiter"] = self.delimiter
        return function_json


class StringTrim(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.StringTrim"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class StringTruncate(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.StringTruncate"

    def __init__(
        self,
        length: typing.Optional[int] = None,
        ellipses: typing.Optional[bool] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.length = length
        self.ellipses = ellipses

    def to_json(self):
        function_json = super().to_json()
        if self.length is not None:
            function_json["length"] = self.length
        if self.ellipses is not None:
            function_json["ellipses"] = self.ellipses
        return function_json


class ToArray(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.ToArray"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class ToBoolean(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.ToBoolean"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class ToBytes(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.ToBytes"

    def __init__(
        self,
        charset: typing.Optional[str] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.charset = charset

    def to_json(self):
        function_json = super().to_json()
        if self.charset is not None:
            function_json["charset"] = self.charset
        return function_json


class ToDateString(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.ToDateString"

    def __init__(
        self,
        format: typing.Optional[str] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.format = format

    def to_json(self):
        function_json = super().to_json()
        if self.format is not None:
            function_json["format"] = self.format
        return function_json


class ToDouble(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.ToDouble"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class ToFloat(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.ToFloat"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class ToInteger(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.ToInteger"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class ToList(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.ToList"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class ToLong(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.ToLong"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class ToLowerCase(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.ToLowerCase"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class ToNull(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.ToNull"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class ToSet(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.ToSet"

    def __init__(
        self,
        implementation: typing.Optional[str] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.implementation = implementation

    def to_json(self):
        function_json = super().to_json()
        if self.implementation is not None:
            function_json["implementation"] = self.implementation
        return function_json


class ToString(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.ToString"

    def __init__(
        self,
        charset: typing.Optional[str] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.charset = charset

    def to_json(self):
        function_json = super().to_json()
        if self.charset is not None:
            function_json["charset"] = self.charset
        return function_json


class ToTuple(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.ToTuple"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class ToUpperCase(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.impl.function.ToUpperCase"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class TupleInputAdapter(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.tuple.TupleInputAdapter"

    def __init__(
        self,
        selection: typing.Optional[typing.List[typing.Any]] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.selection = selection

    def to_json(self):
        function_json = super().to_json()
        if self.selection is not None:
            function_json["selection"] = self.selection
        return function_json


class TupleAdaptedFunction(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.tuple.function.TupleAdaptedFunction"

    def __init__(
        self,
        input_adapter: typing.Optional[Function] = None,
        selection: typing.Optional[typing.List[typing.Any]] = None,
        function: typing.Optional[Function] = None,
        output_adapter: typing.Optional[typing.Any] = None,
        projection: typing.Optional[typing.List[typing.Any]] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.input_adapter = input_adapter
        self.selection = selection
        self.function = function
        self.output_adapter = output_adapter
        self.projection = projection

    def to_json(self):
        function_json = super().to_json()
        if self.input_adapter is not None:
            function_json["inputAdapter"] = self.input_adapter
        if self.selection is not None:
            function_json["selection"] = self.selection
        if self.function is not None:
            function_json["function"] = self.function
        if self.output_adapter is not None:
            function_json["outputAdapter"] = self.output_adapter
        if self.projection is not None:
            function_json["projection"] = self.projection
        return function_json


class TupleAdaptedFunctionComposite(AbstractFunction):
    CLASS = "cn.thutmose.abution.jfunc.tuple.function.TupleAdaptedFunctionComposite"

    def __init__(
        self,
        functions: typing.Optional[typing.List[typing.Any]] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.functions = functions

    def to_json(self):
        function_json = super().to_json()
        if self.functions is not None:
            function_json["functions"] = self.functions
        return function_json


class FloatArraySimilarity(AbstractFunction):
    CLASS = "cn.thutmose.abution.knowlion.FloatArraySimilarity"

    def __init__(
        self,
        query_vector: typing.Optional[typing.List[float]] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.query_vector = query_vector

    def to_json(self):
        function_json = super().to_json()
        if self.query_vector is not None:
            function_json["queryVector"] = self.query_vector
        return function_json

# class FloatArraySimilarity(AbstractFunction):
#     CLASS = "cn.thutmose.abution.knowlion.FloatArraySimilarity"
#
#     def __init__(
#         self,
#         vector: typing.Optional[typing.List[float]] = None,
#     ):
#         super().__init__(_class_name=self.CLASS)
#         self.vector = vector
#
#     def to_json(self):
#         function_json = super().to_json()
#         if self.vector is not None:
#             # 使用与 VectorIndexForSim 相同的格式序列化向量
#             function_json["queryVector"] = {"[F": self.vector}
#         return function_json


class ParaContextTopK(AbstractFunction):
    CLASS = "cn.thutmose.abution.knowlion.ParaContextTopK"

    def __init__(
        self,
        top_k: typing.Optional[int] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.top_k = top_k

    def to_json(self):
        function_json = super().to_json()
        if self.top_k is not None:
            function_json["topK"] = self.top_k
        return function_json

class ParaContextTopScore(AbstractFunction):
    CLASS = "cn.thutmose.abution.knowlion.ParaContextTopScore"

    def __init__(
        self,
        top_k: typing.Optional[int] = None,
        similarity_score_weight: typing.Optional[float] = 0.7,
        entity_count_score_weight: typing.Optional[float] = 0.3,
    ):
        super().__init__(_class_name=self.CLASS)
        self.top_k = top_k
        self.similarity_score_weight = similarity_score_weight
        self.entity_count_score_weight = entity_count_score_weight

    def to_json(self):
        function_json = super().to_json()
        if self.top_k is not None:
            function_json["topK"] = self.top_k
        if self.similarity_score_weight is not None:
            function_json["similarityScoreWeight"] = self.similarity_score_weight
        if self.entity_count_score_weight is not None:
            function_json["entityCountScoreWeight"] = self.entity_count_score_weight
        return function_json


class EntityScoreTopK(AbstractFunction):
    # 将4个属性("occur_count", "importance", "neighbors", "vector_sim_score")按权重比例计算得分后融合排序，保留top_entity
    CLASS = "cn.thutmose.abution.knowlion.EntityScoreTopK"

    def __init__(
        self,
        top_k: typing.Optional[int] = None,
        vector_sim_weight: typing.Optional[float] = 0.4,
        importance_weight: typing.Optional[float] = 0.3,
        occur_count_weight: typing.Optional[float] = 0.2,
        neighbors_weight: typing.Optional[float] = 0.1,
    ):
        super().__init__(_class_name=self.CLASS)
        self.top_k = top_k
        self.vector_sim_weight = vector_sim_weight
        self.importance_weight = importance_weight
        self.occur_count_weight = occur_count_weight
        self.neighbors_weight = neighbors_weight

    def to_json(self):
        function_json = super().to_json()
        if self.top_k is not None:
            function_json["topK"] = self.top_k
        if self.vector_sim_weight is not None:
            function_json["vectorSimWeight"] = self.vector_sim_weight
        if self.importance_weight is not None:
            function_json["importanceWeight"] = self.importance_weight
        if self.occur_count_weight is not None:
            function_json["occurCountWeight"] = self.occur_count_weight
        if self.neighbors_weight is not None:
            function_json["neighborsWeight"] = self.neighbors_weight
        return function_json


class ReasoningPathTop(AbstractFunction):
    # 将推理路径中的Entity和Edge对象解析为格式化字符串，分别组织到entities和edges列表中
    CLASS = "cn.thutmose.abution.knowlion.ReasoningPathTop"

    def __init__(
        self,
        top_k: typing.Optional[int] = None,
        vector_sim_weight: typing.Optional[float] = 0.4,
        importance_weight: typing.Optional[float] = 0.3,
        occur_count_weight: typing.Optional[float] = 0.2,
        neighbors_weight: typing.Optional[float] = 0.1,
    ):
        super().__init__(_class_name=self.CLASS)
        self.top_k = top_k
        self.vector_sim_weight = vector_sim_weight
        self.importance_weight = importance_weight
        self.occur_count_weight = occur_count_weight
        self.neighbors_weight = neighbors_weight

    def to_json(self):
        function_json = super().to_json()
        if self.top_k is not None:
            function_json["topK"] = self.top_k
        if self.vector_sim_weight is not None:
            function_json["vectorSimWeight"] = self.vector_sim_weight
        if self.importance_weight is not None:
            function_json["importanceWeight"] = self.importance_weight
        if self.occur_count_weight is not None:
            function_json["occurCountWeight"] = self.occur_count_weight
        if self.neighbors_weight is not None:
            function_json["neighborsWeight"] = self.neighbors_weight
        return function_json



