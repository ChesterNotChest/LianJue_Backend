#
# Copyright 2022-2025 Crown Copyright
#
# Licensed under the Apache License, Version 2.0 (the 'License');
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.thutmose.cn
#
# by AbutionGraph-3.x.x
#

"""
This module has been generated with fishbowl.
To make changes, either extend these classes or change fishbowl.
"""

import typing
from abutionpy.abution_core import AbstractPredicate, Function, Predicate
from abutionpy.abution_functions import ElementTransformer


class DefaultUserPredicate(AbstractPredicate):
    CLASS = "cn.thutmose.abution.graph.access.predicate.user.DefaultUserPredicate"

    def __init__(
        self,
        auths: typing.Optional[typing.List[str]] = None,
        creating_user_id: typing.Optional[str] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.auths = auths
        self.creating_user_id = creating_user_id

    def to_json(self):
        function_json = super().to_json()
        if self.auths is not None:
            function_json["auths"] = self.auths
        if self.creating_user_id is not None:
            function_json["creatingUserId"] = self.creating_user_id
        return function_json


class NoAccessUserPredicate(AbstractPredicate):
    CLASS = "cn.thutmose.abution.graph.access.predicate.user.NoAccessUserPredicate"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class UnrestrictedAccessUserPredicate(AbstractPredicate):
    CLASS = "cn.thutmose.abution.graph.access.predicate.user.UnrestrictedAccessUserPredicate"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class ElementJoinComparator(AbstractPredicate):
    CLASS = "cn.thutmose.abution.graph.data.element.comparison.ElementJoinComparator"

    def __init__(
        self,
        group_by_properties: typing.Optional[typing.Set[str]] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.group_by_properties = group_by_properties

    def to_json(self):
        function_json = super().to_json()
        if self.group_by_properties is not None:
            function_json["groupByProperties"] = self.group_by_properties
        return function_json


class KnowledgeFilter(AbstractPredicate):
    CLASS = "cn.thutmose.abution.graph.data.knowhow.function.KnowledgeFilter"

    def __init__(
        self,
        predicates: typing.Optional[typing.List[typing.Any]] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.predicates = predicates

    def to_json(self):
        function_json = super().to_json()
        if self.predicates is not None:
            function_json["predicates"] = self.predicates
        return function_json


class PropertiesFilter(AbstractPredicate):
    CLASS = "cn.thutmose.abution.graph.data.knowhow.function.PropertiesFilter"

    def __init__(
        self,
        predicates: typing.Optional[typing.List[typing.Any]] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.predicates = predicates

    def to_json(self):
        function_json = super().to_json()
        if self.predicates is not None:
            function_json["predicates"] = self.predicates
        return function_json


# class NamedViewWriteUserPredicate(AbstractPredicate):
#     CLASS = "cn.thutmose.abution.graph.data.elementdefinition.view.access.predicate.user.NamedViewWriteUserPredicate"
#
#     def __init__(
#         self,
#         auths: typing.Optional[typing.List[str]] = None,
#         creating_user_id: typing.Optional[str] = None,
#     ):
#         super().__init__(_class_name=self.CLASS)
#         self.auths = auths
#         self.creating_user_id = creating_user_id
#
#     def to_json(self):
#         function_json = super().to_json()
#         if self.auths is not None:
#             function_json["auths"] = self.auths
#         if self.creating_user_id is not None:
#             function_json["creatingUserId"] = self.creating_user_id
#         return function_json


class FederatedGraphReadUserPredicate(AbstractPredicate):
    CLASS = "cn.thutmose.abution.graph.federatedstore.access.predicate.user.FederatedGraphReadUserPredicate"

    def __init__(
        self,
        public: typing.Optional[bool] = None,
        auths: typing.Optional[typing.List[str]] = None,
        creating_user_id: typing.Optional[str] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.public = public
        self.auths = auths
        self.creating_user_id = creating_user_id

    def to_json(self):
        function_json = super().to_json()
        if self.public is not None:
            function_json["public"] = self.public
        if self.auths is not None:
            function_json["auths"] = self.auths
        if self.creating_user_id is not None:
            function_json["creatingUserId"] = self.creating_user_id
        return function_json


class FederatedGraphWriteUserPredicate(AbstractPredicate):
    CLASS = "cn.thutmose.abution.graph.federatedstore.access.predicate.user.FederatedGraphWriteUserPredicate"

    def __init__(
        self,
        creating_user_id: typing.Optional[str] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.creating_user_id = creating_user_id

    def to_json(self):
        function_json = super().to_json()
        if self.creating_user_id is not None:
            function_json["creatingUserId"] = self.creating_user_id
        return function_json


class TransformAndFilter(AbstractPredicate):
    CLASS = "cn.thutmose.abution.graph.graph.hook.migrate.predicate.TransformAndFilter"

    def __init__(
        self,
        filter: typing.Optional[KnowledgeFilter] = None,
        transformer: typing.Optional[ElementTransformer] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.filter = filter
        self.transformer = transformer

    def to_json(self):
        function_json = super().to_json()
        if self.filter is not None:
            function_json["filter"] = self.filter
        if self.transformer is not None:
            function_json["transformer"] = self.transformer
        return function_json


class ExampleFilterFunction(AbstractPredicate):
    CLASS = "cn.thutmose.abution.graph.rest.example.ExampleFilterFunction"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class HyperLogLogPlusLessThan(AbstractPredicate):
    CLASS = "cn.thutmose.abution.graph.sketches.clearspring.cardinality.predicate.HyperLogLogPlusLessThan"

    def __init__(
        self,
        value: typing.Optional[int] = None,
        or_equal_to: typing.Optional[bool] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.value = value
        self.or_equal_to = or_equal_to

    def to_json(self):
        function_json = super().to_json()
        if self.value is not None:
            function_json["value"] = self.value
        if self.or_equal_to is not None:
            function_json["orEqualTo"] = self.or_equal_to
        return function_json


class HllSketchLessThan(AbstractPredicate):
    CLASS = "cn.thutmose.abution.graph.sketches.datasketches.cardinality.predicate.HllSketchLessThan"

    def __init__(
        self,
        value: typing.Optional[int] = None,
        or_equal_to: typing.Optional[bool] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.value = value
        self.or_equal_to = or_equal_to

    def to_json(self):
        function_json = super().to_json()
        if self.value is not None:
            function_json["value"] = self.value
        if self.or_equal_to is not None:
            function_json["orEqualTo"] = self.or_equal_to
        return function_json


class AggregatorUtilIsElementAggregated(AbstractPredicate):
    CLASS = "cn.thutmose.abution.graph.store.util.AggregatorUtil$IsElementAggregated"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class RBMBackedTimestampSetInRange(AbstractPredicate):
    CLASS = "cn.thutmose.abution.graph.time.predicate.RBMBackedTimestampSetInRange"

    def __init__(
        self,
        start_time: typing.Optional[typing.Any] = None,
        end_time: typing.Optional[typing.Any] = None,
        include_all_timestamps: typing.Optional[bool] = None,
        time_unit: typing.Optional[str] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.start_time = start_time
        self.end_time = end_time
        self.include_all_timestamps = include_all_timestamps
        self.time_unit = time_unit

    def to_json(self):
        function_json = super().to_json()
        if self.start_time is not None:
            function_json["startTime"] = self.start_time
        if self.end_time is not None:
            function_json["endTime"] = self.end_time
        if self.include_all_timestamps is not None:
            function_json["includeAllTimestamps"] = self.include_all_timestamps
        if self.time_unit is not None:
            function_json["timeUnit"] = self.time_unit
        return function_json


class AgeOff(AbstractPredicate):
    CLASS = "cn.thutmose.abution.jfunc.impl.predicate.AgeOff"

    def __init__(
        self,
        age_off_hours: typing.Optional[int] = None,
        age_off_days: typing.Optional[int] = None,
        age_off_time: typing.Optional[int] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.age_off_hours = age_off_hours
        self.age_off_days = age_off_days
        self.age_off_time = age_off_time

    def to_json(self):
        function_json = super().to_json()
        if self.age_off_hours is not None:
            function_json["ageOffHours"] = self.age_off_hours
        if self.age_off_days is not None:
            function_json["ageOffDays"] = self.age_off_days
        if self.age_off_time is not None:
            function_json["ageOffTime"] = self.age_off_time
        return function_json


class AgeOffFromDays(AbstractPredicate):
    CLASS = "cn.thutmose.abution.jfunc.impl.predicate.AgeOffFromDays"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class And(AbstractPredicate):
    CLASS = "cn.thutmose.abution.jfunc.impl.predicate.And"

    def __init__(
        self,
        predicates: typing.Optional[typing.List[typing.Any]] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.predicates = predicates

    def to_json(self):
        function_json = super().to_json()
        if self.predicates is not None:
            function_json["predicates"] = self.predicates
        return function_json


class AreEqual(AbstractPredicate):
    CLASS = "cn.thutmose.abution.jfunc.impl.predicate.AreEqual"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class ArrayIn(AbstractPredicate):
    CLASS = "cn.thutmose.abution.jfunc.impl.predicate.ArrayIn"

    def __init__(
        self,
        values: typing.Optional[typing.List[typing.Any]] = None,
        # null_or_empty_values_accepted: typing.Optional[bool] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.values = values
        # self.null_or_empty_values_accepted = null_or_empty_values_accepted

    def to_json(self):
        function_json = super().to_json()
        if self.values is not None:
            function_json["values"] = self.values
        # if self.null_or_empty_values_accepted is not None:
        #     function_json["nullOrEmptyValuesAccepted"] = self.null_or_empty_values_accepted
        return function_json


class ArrayContains(AbstractPredicate):
    CLASS = "cn.thutmose.abution.jfunc.impl.predicate.ArrayContains"

    def __init__(
        self,
        value: typing.Optional[typing.Any] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.value = value

    def to_json(self):
        function_json = super().to_json()
        if self.value is not None:
            function_json["value"] = self.value
        return function_json


class Exists(AbstractPredicate):
    CLASS = "cn.thutmose.abution.jfunc.impl.predicate.Exists"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class If(AbstractPredicate):
    CLASS = "cn.thutmose.abution.jfunc.impl.predicate.If"

    def __init__(
        self,
        otherwise: typing.Optional[Predicate] = None,
        predicate: typing.Optional[Predicate] = None,
        condition: typing.Optional[bool] = None,
        then: typing.Optional[Predicate] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.otherwise = otherwise
        self.predicate = predicate
        self.condition = condition
        self.then = then

    def to_json(self):
        function_json = super().to_json()
        if self.otherwise is not None:
            function_json["otherwise"] = self.otherwise
        if self.predicate is not None:
            function_json["predicate"] = self.predicate
        if self.condition is not None:
            function_json["condition"] = self.condition
        if self.then is not None:
            function_json["then"] = self.then
        return function_json


class IsA(AbstractPredicate):
    CLASS = "cn.thutmose.abution.jfunc.impl.predicate.IsA"

    def __init__(
        self,
        type: typing.Optional[str] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.type = type

    def to_json(self):
        function_json = super().to_json()
        if self.type is not None:
            function_json["type"] = self.type
        return function_json


class Equal(AbstractPredicate):
    CLASS = "cn.thutmose.abution.jfunc.impl.predicate.Equal"

    def __init__(
        self,
        value: typing.Optional[typing.Any] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.value = value

    def to_json(self):
        function_json = super().to_json()
        if self.value is not None:
            function_json["value"] = self.value
        return function_json


class IsFalse(AbstractPredicate):
    CLASS = "cn.thutmose.abution.jfunc.impl.predicate.IsFalse"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class IsIn(AbstractPredicate):
    CLASS = "cn.thutmose.abution.jfunc.impl.predicate.IsIn"

    def __init__(
        self,
        values: typing.Optional[typing.List[typing.Any]] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.values = values

    def to_json(self):
        function_json = super().to_json()
        if self.values is not None:
            function_json["values"] = self.values
        return function_json


class LessThan(AbstractPredicate):
    CLASS = "cn.thutmose.abution.jfunc.impl.predicate.LessThan"

    def __init__(
        self,
        value: typing.Optional[typing.Any] = None,
        or_equal_to: typing.Optional[bool] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.value = value
        self.or_equal_to = or_equal_to

    def to_json(self):
        function_json = super().to_json()
        if self.value is not None:
            function_json["value"] = self.value
        if self.or_equal_to is not None:
            function_json["orEqualTo"] = self.or_equal_to
        return function_json


class IsLongerThan(AbstractPredicate):
    CLASS = "cn.thutmose.abution.jfunc.impl.predicate.IsLongerThan"

    def __init__(
        self,
        min_length: typing.Optional[int] = None,
        or_equal_to: typing.Optional[bool] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.min_length = min_length
        self.or_equal_to = or_equal_to

    def to_json(self):
        function_json = super().to_json()
        if self.min_length is not None:
            function_json["minLength"] = self.min_length
        if self.or_equal_to is not None:
            function_json["orEqualTo"] = self.or_equal_to
        return function_json


class MoreThan(AbstractPredicate):
    CLASS = "cn.thutmose.abution.jfunc.impl.predicate.MoreThan"

    def __init__(
        self,
        value: typing.Optional[typing.Any] = None,
        or_equal_to: typing.Optional[bool] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.value = value
        self.or_equal_to = or_equal_to

    def to_json(self):
        function_json = super().to_json()
        if self.value is not None:
            function_json["value"] = self.value
        if self.or_equal_to is not None:
            function_json["orEqualTo"] = self.or_equal_to
        return function_json


class IsShorterThan(AbstractPredicate):
    CLASS = "cn.thutmose.abution.jfunc.impl.predicate.IsShorterThan"

    def __init__(
        self,
        max_length: typing.Optional[int] = None,
        or_equal_to: typing.Optional[bool] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.max_length = max_length
        self.or_equal_to = or_equal_to

    def to_json(self):
        function_json = super().to_json()
        if self.max_length is not None:
            function_json["maxLength"] = self.max_length
        if self.or_equal_to is not None:
            function_json["orEqualTo"] = self.or_equal_to
        return function_json


class IsTrue(AbstractPredicate):
    CLASS = "cn.thutmose.abution.jfunc.impl.predicate.IsTrue"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class IsXLessThanY(AbstractPredicate):
    CLASS = "cn.thutmose.abution.jfunc.impl.predicate.IsXLessThanY"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class IsXMoreThanY(AbstractPredicate):
    CLASS = "cn.thutmose.abution.jfunc.impl.predicate.IsXMoreThanY"

    def __init__(self):
        super().__init__(_class_name=self.CLASS)

    def to_json(self):
        return super().to_json()


class MapContains(AbstractPredicate):
    CLASS = "cn.thutmose.abution.jfunc.impl.predicate.MapContains"

    def __init__(
        self,
        key: typing.Optional[str] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.key = key

    def to_json(self):
        function_json = super().to_json()
        if self.key is not None:
            function_json["key"] = self.key
        return function_json


class MapContainsPredicate(AbstractPredicate):
    CLASS = "cn.thutmose.abution.jfunc.impl.predicate.MapContainsPredicate"

    def __init__(
        self,
        key_predicate: typing.Optional[Predicate] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.key_predicate = key_predicate

    def to_json(self):
        function_json = super().to_json()
        if self.key_predicate is not None:
            function_json["keyPredicate"] = self.key_predicate
        return function_json


class MultiRegex(AbstractPredicate):
    CLASS = "cn.thutmose.abution.jfunc.impl.predicate.MultiRegex"

    def __init__(
        self,
        value: typing.Optional[typing.List[typing.Any]] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.value = value

    def to_json(self):
        function_json = super().to_json()
        if self.value is not None:
            function_json["value"] = self.value
        return function_json


class Not(AbstractPredicate):
    CLASS = "cn.thutmose.abution.jfunc.impl.predicate.Not"

    def __init__(
        self,
        predicate: typing.Optional[Predicate] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.predicate = predicate

    def to_json(self):
        function_json = super().to_json()
        if self.predicate is not None:
            function_json["predicate"] = self.predicate
        return function_json


class Or(AbstractPredicate):
    CLASS = "cn.thutmose.abution.jfunc.impl.predicate.Or"

    def __init__(
        self,
        predicates: typing.Optional[typing.List[typing.Any]] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.predicates = predicates

    def to_json(self):
        function_json = super().to_json()
        if self.predicates is not None:
            function_json["predicates"] = self.predicates
        return function_json


class Regex(AbstractPredicate):
    CLASS = "cn.thutmose.abution.jfunc.impl.predicate.Regex"

    def __init__(
        self,
        value: typing.Optional[typing.Any] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.value = value

    def to_json(self):
        function_json = super().to_json()
        if self.value is not None:
            function_json["value"] = self.value
        return function_json


class StringContains(AbstractPredicate):
    CLASS = "cn.thutmose.abution.jfunc.impl.predicate.StringContains"

    def __init__(
        self,
        ignore_case: typing.Optional[bool] = None,
        value: typing.Optional[str] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.ignore_case = ignore_case
        self.value = value

    def to_json(self):
        function_json = super().to_json()
        if self.ignore_case is not None:
            function_json["ignoreCase"] = self.ignore_case
        if self.value is not None:
            function_json["value"] = self.value
        return function_json


class InDateRange(AbstractPredicate):
    CLASS = "cn.thutmose.abution.jfunc.impl.predicate.range.InDateRange"

    def __init__(
        self,
        end_offset: typing.Optional[int] = None,
        offset_unit: typing.Optional[str] = None,
        start_offset: typing.Optional[int] = None,
        start_inclusive: typing.Optional[bool] = None,
        start: typing.Optional[str] = None,
        time_zone: typing.Optional[str] = None,
        end: typing.Optional[str] = None,
        end_inclusive: typing.Optional[bool] = None,
        time_unit: typing.Optional[str] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.end_offset = end_offset
        self.offset_unit = offset_unit
        self.start_offset = start_offset
        self.start_inclusive = start_inclusive
        self.start = start
        self.time_zone = time_zone
        self.end = end
        self.end_inclusive = end_inclusive
        self.time_unit = time_unit

    def to_json(self):
        function_json = super().to_json()
        if self.end_offset is not None:
            function_json["endOffset"] = self.end_offset
        if self.offset_unit is not None:
            function_json["offsetUnit"] = self.offset_unit
        if self.start_offset is not None:
            function_json["startOffset"] = self.start_offset
        if self.start_inclusive is not None:
            function_json["startInclusive"] = self.start_inclusive
        if self.start is not None:
            function_json["start"] = self.start
        if self.time_zone is not None:
            function_json["timeZone"] = self.time_zone
        if self.end is not None:
            function_json["end"] = self.end
        if self.end_inclusive is not None:
            function_json["endInclusive"] = self.end_inclusive
        if self.time_unit is not None:
            function_json["timeUnit"] = self.time_unit
        return function_json


class InDateRangeDual(AbstractPredicate):
    CLASS = "cn.thutmose.abution.jfunc.impl.predicate.range.InDateRangeDual"

    def __init__(
        self,
        end_fully_contained: typing.Optional[bool] = None,
        end_offset: typing.Optional[int] = None,
        offset_unit: typing.Optional[str] = None,
        start_offset: typing.Optional[int] = None,
        start_inclusive: typing.Optional[bool] = None,
        start: typing.Optional[str] = None,
        time_zone: typing.Optional[str] = None,
        end: typing.Optional[str] = None,
        end_inclusive: typing.Optional[bool] = None,
        start_fully_contained: typing.Optional[bool] = None,
        time_unit: typing.Optional[str] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.end_fully_contained = end_fully_contained
        self.end_offset = end_offset
        self.offset_unit = offset_unit
        self.start_offset = start_offset
        self.start_inclusive = start_inclusive
        self.start = start
        self.time_zone = time_zone
        self.end = end
        self.end_inclusive = end_inclusive
        self.start_fully_contained = start_fully_contained
        self.time_unit = time_unit

    def to_json(self):
        function_json = super().to_json()
        if self.end_fully_contained is not None:
            function_json["endFullyContained"] = self.end_fully_contained
        if self.end_offset is not None:
            function_json["endOffset"] = self.end_offset
        if self.offset_unit is not None:
            function_json["offsetUnit"] = self.offset_unit
        if self.start_offset is not None:
            function_json["startOffset"] = self.start_offset
        if self.start_inclusive is not None:
            function_json["startInclusive"] = self.start_inclusive
        if self.start is not None:
            function_json["start"] = self.start
        if self.time_zone is not None:
            function_json["timeZone"] = self.time_zone
        if self.end is not None:
            function_json["end"] = self.end
        if self.end_inclusive is not None:
            function_json["endInclusive"] = self.end_inclusive
        if self.start_fully_contained is not None:
            function_json["startFullyContained"] = self.start_fully_contained
        if self.time_unit is not None:
            function_json["timeUnit"] = self.time_unit
        return function_json


class InRange(AbstractPredicate):
    CLASS = "cn.thutmose.abution.jfunc.impl.predicate.range.InRange"

    def __init__(
        self,
        start_inclusive: typing.Optional[bool] = None,
        start: typing.Optional[typing.Any] = None,
        end: typing.Optional[typing.Any] = None,
        end_inclusive: typing.Optional[bool] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.start_inclusive = start_inclusive
        self.start = start
        self.end = end
        self.end_inclusive = end_inclusive

    def to_json(self):
        function_json = super().to_json()
        if self.start_inclusive is not None:
            function_json["startInclusive"] = self.start_inclusive
        if self.start is not None:
            function_json["start"] = self.start
        if self.end is not None:
            function_json["end"] = self.end
        if self.end_inclusive is not None:
            function_json["endInclusive"] = self.end_inclusive
        return function_json


class InRangeDual(AbstractPredicate):
    CLASS = "cn.thutmose.abution.jfunc.impl.predicate.range.InRangeDual"

    def __init__(
        self,
        end_fully_contained: typing.Optional[bool] = None,
        start_inclusive: typing.Optional[bool] = None,
        start: typing.Optional[typing.Any] = None,
        end: typing.Optional[typing.Any] = None,
        end_inclusive: typing.Optional[bool] = None,
        start_fully_contained: typing.Optional[bool] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.end_fully_contained = end_fully_contained
        self.start_inclusive = start_inclusive
        self.start = start
        self.end = end
        self.end_inclusive = end_inclusive
        self.start_fully_contained = start_fully_contained

    def to_json(self):
        function_json = super().to_json()
        if self.end_fully_contained is not None:
            function_json["endFullyContained"] = self.end_fully_contained
        if self.start_inclusive is not None:
            function_json["startInclusive"] = self.start_inclusive
        if self.start is not None:
            function_json["start"] = self.start
        if self.end is not None:
            function_json["end"] = self.end
        if self.end_inclusive is not None:
            function_json["endInclusive"] = self.end_inclusive
        if self.start_fully_contained is not None:
            function_json["startFullyContained"] = self.start_fully_contained
        return function_json


class InTimeRange(AbstractPredicate):
    CLASS = "cn.thutmose.abution.jfunc.impl.predicate.range.InTimeRange"

    def __init__(
        self,
        end_offset: typing.Optional[int] = None,
        offset_unit: typing.Optional[str] = None,
        start_offset: typing.Optional[int] = None,
        start_inclusive: typing.Optional[bool] = None,
        start: typing.Optional[str] = None,
        time_zone: typing.Optional[str] = None,
        end: typing.Optional[str] = None,
        end_inclusive: typing.Optional[bool] = None,
        time_unit: typing.Optional[str] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.end_offset = end_offset
        self.offset_unit = offset_unit
        self.start_offset = start_offset
        self.start_inclusive = start_inclusive
        self.start = start
        self.time_zone = time_zone
        self.end = end
        self.end_inclusive = end_inclusive
        self.time_unit = time_unit

    def to_json(self):
        function_json = super().to_json()
        if self.end_offset is not None:
            function_json["endOffset"] = self.end_offset
        if self.offset_unit is not None:
            function_json["offsetUnit"] = self.offset_unit
        if self.start_offset is not None:
            function_json["startOffset"] = self.start_offset
        if self.start_inclusive is not None:
            function_json["startInclusive"] = self.start_inclusive
        if self.start is not None:
            function_json["start"] = self.start
        if self.time_zone is not None:
            function_json["timeZone"] = self.time_zone
        if self.end is not None:
            function_json["end"] = self.end
        if self.end_inclusive is not None:
            function_json["endInclusive"] = self.end_inclusive
        if self.time_unit is not None:
            function_json["timeUnit"] = self.time_unit
        return function_json


class InTimeRangeDual(AbstractPredicate):
    CLASS = "cn.thutmose.abution.jfunc.impl.predicate.range.InTimeRangeDual"

    def __init__(
        self,
        end_fully_contained: typing.Optional[bool] = None,
        end_offset: typing.Optional[int] = None,
        offset_unit: typing.Optional[str] = None,
        start_offset: typing.Optional[int] = None,
        start_inclusive: typing.Optional[bool] = None,
        start: typing.Optional[str] = None,
        time_zone: typing.Optional[str] = None,
        end: typing.Optional[str] = None,
        end_inclusive: typing.Optional[bool] = None,
        start_fully_contained: typing.Optional[bool] = None,
        time_unit: typing.Optional[str] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.end_fully_contained = end_fully_contained
        self.end_offset = end_offset
        self.offset_unit = offset_unit
        self.start_offset = start_offset
        self.start_inclusive = start_inclusive
        self.start = start
        self.time_zone = time_zone
        self.end = end
        self.end_inclusive = end_inclusive
        self.start_fully_contained = start_fully_contained
        self.time_unit = time_unit

    def to_json(self):
        function_json = super().to_json()
        if self.end_fully_contained is not None:
            function_json["endFullyContained"] = self.end_fully_contained
        if self.end_offset is not None:
            function_json["endOffset"] = self.end_offset
        if self.offset_unit is not None:
            function_json["offsetUnit"] = self.offset_unit
        if self.start_offset is not None:
            function_json["startOffset"] = self.start_offset
        if self.start_inclusive is not None:
            function_json["startInclusive"] = self.start_inclusive
        if self.start is not None:
            function_json["start"] = self.start
        if self.time_zone is not None:
            function_json["timeZone"] = self.time_zone
        if self.end is not None:
            function_json["end"] = self.end
        if self.end_inclusive is not None:
            function_json["endInclusive"] = self.end_inclusive
        if self.start_fully_contained is not None:
            function_json["startFullyContained"] = self.start_fully_contained
        if self.time_unit is not None:
            function_json["timeUnit"] = self.time_unit
        return function_json


class AdaptedPredicate(AbstractPredicate):
    CLASS = "cn.thutmose.abution.jfunc.predicate.AdaptedPredicate"

    def __init__(
        self,
        predicate: typing.Optional[Predicate] = None,
        input_adapter: typing.Optional[Function] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.predicate = predicate
        self.input_adapter = input_adapter

    def to_json(self):
        function_json = super().to_json()
        if self.predicate is not None:
            function_json["predicate"] = self.predicate
        if self.input_adapter is not None:
            function_json["inputAdapter"] = self.input_adapter
        return function_json


class PredicateComposite(AbstractPredicate):
    CLASS = "cn.thutmose.abution.jfunc.predicate.PredicateComposite"

    def __init__(
        self,
        predicates: typing.Optional[typing.List[typing.Any]] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.predicates = predicates

    def to_json(self):
        function_json = super().to_json()
        if self.predicates is not None:
            function_json["predicates"] = self.predicates
        return function_json


class PredicateMap(AbstractPredicate):
    CLASS = "cn.thutmose.abution.jfunc.predicate.PredicateMap"

    def __init__(
        self,
        predicate: typing.Optional[Predicate] = None,
        key: typing.Optional[typing.Any] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.predicate = predicate
        self.key = key

    def to_json(self):
        function_json = super().to_json()
        if self.predicate is not None:
            function_json["predicate"] = self.predicate
        if self.key is not None:
            function_json["key"] = self.key
        return function_json


class IntegerTupleAdaptedPredicate(AbstractPredicate):
    CLASS = "cn.thutmose.abution.jfunc.tuple.predicate.IntegerTupleAdaptedPredicate"

    def __init__(
        self,
        predicate: typing.Optional[Predicate] = None,
        input_adapter: typing.Optional[Function] = None,
        selection: typing.Optional[typing.List[int]] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.predicate = predicate
        self.input_adapter = input_adapter
        self.selection = selection

    def to_json(self):
        function_json = super().to_json()
        if self.predicate is not None:
            function_json["predicate"] = self.predicate
        if self.input_adapter is not None:
            function_json["inputAdapter"] = self.input_adapter
        if self.selection is not None:
            function_json["selection"] = self.selection
        return function_json


class TupleAdaptedPredicate(AbstractPredicate):
    CLASS = "cn.thutmose.abution.jfunc.tuple.predicate.TupleAdaptedPredicate"

    def __init__(
        self,
        predicate: typing.Optional[Predicate] = None,
        input_adapter: typing.Optional[Function] = None,
        selection: typing.Optional[typing.List[typing.Any]] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.predicate = predicate
        self.input_adapter = input_adapter
        self.selection = selection

    def to_json(self):
        function_json = super().to_json()
        if self.predicate is not None:
            function_json["predicate"] = self.predicate
        if self.input_adapter is not None:
            function_json["inputAdapter"] = self.input_adapter
        if self.selection is not None:
            function_json["selection"] = self.selection
        return function_json


class TupleAdaptedPredicateComposite(AbstractPredicate):
    """ 向量相似度计算函数 """
    CLASS = "cn.thutmose.abution.jfunc.tuple.predicate.TupleAdaptedPredicateComposite"

    def __init__(
        self,
        predicates: typing.Optional[typing.List[typing.Any]] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.predicates = predicates

    def to_json(self):
        function_json = super().to_json()
        if self.predicates is not None:
            function_json["predicates"] = self.predicates
        return function_json


class VectorsForSim4(AbstractPredicate):
    CLASS = "cn.thutmose.abution.graph.type.impl.predicate.CustomMap4VectorsForSimilarity"

    def __init__(
        self,
        vector: typing.Optional[typing.List[float]],
        neighbors: typing.Optional[int],
        rag_types: typing.Optional[typing.List[str]] = ["实体级别"],
        space_type: typing.Optional[str] = "Cosine",
        index_m: typing.Optional[int] = 16,
        random_seed: typing.Optional[int] = 0,
        storage_data_type: typing.Optional[str] = "E4M3", #Float8,Float32,E4M3;
        threads: typing.Optional[int] = 0,
        ef: typing.Optional[int] = 20,
    ):
        super().__init__(_class_name=self.CLASS)
        self.vector = vector
        self.neighbors = neighbors
        self.rag_types = rag_types
        self.space_type = space_type
        self.index_m = index_m
        self.random_seed = random_seed
        self.storage_data_type = storage_data_type
        self.threads = threads
        self.ef = ef

    def to_json(self):
        function_json = super().to_json()
        if self.vector is not None:
            function_json["vector"] = self.vector
            function_json["numDimensions"] = len(self.vector)
        if self.neighbors is not None:
            function_json["neighbors"] = self.neighbors
        if self.rag_types is not None:
            function_json["ragTypes"] = self.rag_types
        if self.space_type is not None:
            function_json["spaceType"] = self.space_type
        if self.index_m is not None:
            function_json["indexM"] = self.index_m
        if self.random_seed is not None:
            function_json["randomSeed"] = self.random_seed
        if self.storage_data_type is not None:
            function_json["storageDataType"] = self.storage_data_type
        if self.threads is not None:
            function_json["threads"] = self.threads
        if self.ef is not None:
            function_json["ef"] = self.ef
        return function_json

class VectorIndexForSim(AbstractPredicate):
    CLASS = "cn.thutmose.abution.graph.type.vector.predicate.VectorIndexForSimilarity"

    def __init__(
        self,
        vectors: typing.Optional[typing.List[typing.List[float]]] = None,
        top_k: typing.Optional[int] = None,
        threads: typing.Optional[int] = None,
        ef: typing.Optional[int] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.vectors = vectors
        self.top_k = top_k
        self.threads = threads
        self.ef = ef

    def to_json(self):
        function_json = super().to_json()
        if self.vectors is not None:
            formatted_vectors = [{"[F": vector} for vector in self.vectors]
            function_json["vectors"] = formatted_vectors
        if self.top_k is not None:
            function_json["topK"] = self.top_k
        if self.threads is not None:
            function_json["threads"] = self.threads
        if self.ef is not None:
            function_json["ef"] = self.ef
        return function_json

class BM25IndexForSim(AbstractPredicate):
    CLASS = "cn.thutmose.abution.graph.type.bm25.predicate.BM25IndexForSimilarity"

    def __init__(
        self,
        query_text: typing.Optional[str] = None,
        query_entities: typing.Optional[typing.List[str]] = None,
        top_k: typing.Optional[int] = None,
    ):
        super().__init__(_class_name=self.CLASS)
        self.query_text = query_text
        self.query_entities = query_entities
        self.top_k = top_k

    def to_json(self):
        function_json = super().to_json()
        if self.query_text is not None:
            function_json["queryText"] = self.query_text
        if self.query_entities is not None:
            function_json["queryEntities"] = self.query_entities
        if self.top_k is not None:
            function_json["topK"] = self.top_k
        return function_json
