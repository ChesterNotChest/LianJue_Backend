import sys
from abutionpy import graphdb as g
from abutionpy import gdb_connector
from urllib.request import Request, urlopen
import jpype
import requests
import json
import urllib

# jvm_path = jpype.getDefaultJVMPath()
# jpype.startJVM(jvm_path,'-ea', '-Djava.class.path=%s'%'/thutmose/app/abution/lib/abution-start-2.1.0.jar', convertStrings=False)
# jclass = jpype.JClass('cn.thutmose.abution.jfunc.impl.predicate.MoreThan') #加载类
# #calc = jclass(10,20) #传入所需参数
# calc = jclass(20) #传入所需参数
# value = calc.add() #调用类中的add方法
# print(value)
# jpype.shutdownJVM() #关闭JAVA虚拟机


# g = graph.AbutionConnector("http://localhost:9995", "test", True)
gc = gdb_connector.AbutionConnector("http://localhost:9995", "AbutionGraphs.DocParsing", True)
#result = gc.execute_get(g.GetSchema(g.Operation("test")))
# result = gc.execute_operation(g.GetSchema())

entity = g.Entity("DIM_E", "aa", {"aa": 1})

print(entity.to_json())

print(gc.execute_get(g.GetSchema()))

gk = g.GetKnowledge()
gk.input = [
  g.EntityKey(vertex=2)
]

sys.exit(1)

# _pre_agg_filter_funcs = {}
# _pre_agg_filter_funcs.update({"aa", ["aa"]})

# dic = {}
# dic.setdefault('a',[]).append({"a":g.PredicateContext(selection="dim", predicate=g.MoreThan(3262045800000))})
# dic.setdefault('a',[]).append({"b":g.PredicateContext(selection="dim", predicate=g.MoreThan(3262045805000))})
#
# print(dic)


gc.Aremlin('').exec()
gc.Gremlin('').exec()
gc.SparQL('').exec()
gc.GraphQL('').exec()

# res = gc.V('v2').dim('Entity').has('time').by(g.MoreThan(value=3262045800000,or_equal_to=False)).exec()
res = gc.V('v2').dim('DimE')\
  .has('timestamp').by(g.MoreThan(value=222, or_equal_to=False))\
  .has('timestamp1').by(g.MoreThan(value=222, or_equal_to=False))\
  .exec()

print(res)











url = "http://localhost:9995/rest/v2/graph/operations/execute"
payload = json.dumps({
  "class": "cn.thutmose.abution.graph.GqlChain",
  "gqls": [
    {
      "class": "cn.thutmose.abution.graph.operation.impl.get.ScanEntity",
      "view": {
        "allEntities": True
      }
    }
  ],
  "options": {
    "abution.grs.operation.graphIds": "test"
  }
})
headers = {'Content-Type': 'application/json'}

# response = requests.request("POST", url, headers=headers, data=payload)
#
# print(response.text)
#
#
#
# operation = g.GetSchema()
# operation = '{"class":"cn.thutmose.abution.graph.GqlChain","gqls":[{"class":"cn.thutmose.abution.graph.operation.impl.get.ScanEntity","view":{"allEntities":true}}],"options":{"abution.grs.operation.graphIds":"test"}}'
# #operation = '{"class":"cn.thutmose.abution.graph.operation.impl.get.ScanEntity","view":{"allEntities":true},"options":{"abution.grs.operation.graphIds":"test"}}'
# headers={}
# headers['Content-Type'] = 'application/json;charset=utf-8'
#
#
# # print(json.loads(operation))
# # json_body = bytes(json.dumps(operation), 'ascii')
# json_body = json.dumps(operation)
#
# #url = urllib.quote(url, ':/=&?')
# request = urllib.request.Request('http://localhost:9995/rest/v2/graph/operations/execute', headers=headers, data=json_body)
#
# print(request.text)
# print(g.JsonConverter.from_json(json.loads(response.text)))
# print(g.JsonConverter.from_json(response.text))



# # print(result.to_json())
# print("result.to_json()")
# request = urllib.request.Request('http://localhost:9995/rest/v2/graph/operations/execute', headers=headers, data=json.dumps(json.loads(g.GetSchema())))
#
# print(response.text)
# print('Schema:')
# print()


